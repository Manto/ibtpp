<?php require("includes/header.php"); ?>

<div class="main">
	<div class="header">Registration</div>
</div>
	
<?php require("includes/footer.php"); ?>
