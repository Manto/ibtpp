<div class="footer">Copyright &copy; 2007 Infant Botulism Treatment and Prevention Program, All rights reserved.</div>
</body>
</html>