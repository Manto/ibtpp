-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost:3306
-- Generation Time: Feb 25, 2008 at 09:25 AM
-- Server version: 4.1.20
-- PHP Version: 5.0.5
-- 
-- Database: `ibrcc`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `abstracts`
-- 

CREATE TABLE `abstracts` (
  `abstract_id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(150) NOT NULL default '',
  `author` varchar(150) NOT NULL default '',
  `affiliation` varchar(150) NOT NULL default '',
  `category` varchar(60) NOT NULL default '',
  `abstract` text NOT NULL,
  `email` varchar(60) NOT NULL default '',
  `presentation` enum('Poster','Platform','Either') NOT NULL default 'Poster',
  `c_stamp` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`abstract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=86 ;

-- 
-- Dumping data for table `abstracts`
-- 
