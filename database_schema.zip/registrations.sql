-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost:3306
-- Generation Time: Feb 25, 2008 at 09:25 AM
-- Server version: 4.1.20
-- PHP Version: 5.0.5
-- 
-- Database: `ibrcc`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `registrations`
-- 

CREATE TABLE `registrations` (
  `registration_id` int(10) unsigned NOT NULL auto_increment,
  `title` varchar(25) NOT NULL default '',
  `name` varchar(50) NOT NULL default '',
  `badgename` varchar(50) NOT NULL default '',
  `institution` varchar(50) NOT NULL default '',
  `department` varchar(50) NOT NULL default '',
  `degree` set('PhD','MPH','MS','MD','DVM','Other') NOT NULL default '',
  `address` varchar(100) NOT NULL default '',
  `city` varchar(40) NOT NULL default '',
  `state` varchar(40) NOT NULL default '',
  `zip` varchar(15) NOT NULL default '',
  `country` varchar(40) NOT NULL default '',
  `businessphone` varchar(20) NOT NULL default '',
  `cellphone` varchar(20) NOT NULL default '',
  `fax` varchar(20) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `submitabstract` enum('No','Yes') NOT NULL default 'No',
  `presentation` varchar(8) NOT NULL default '',
  `trans_id` varchar(64) NOT NULL default '',
  `auth_code` varchar(6) NOT NULL default '',
  `c_stamp` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`registration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=192 ;

-- 
-- Dumping data for table `registrations`
-- 
