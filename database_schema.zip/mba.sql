-- phpMyAdmin SQL Dump
-- version 2.8.2.4
-- http://www.phpmyadmin.net
-- 
-- Host: localhost:3306
-- Generation Time: Feb 25, 2008 at 09:25 AM
-- Server version: 4.1.20
-- PHP Version: 5.0.5
-- 
-- Database: `ibrcc`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `mba`
-- 

CREATE TABLE `mba` (
  `registration_id` int(11) NOT NULL auto_increment,
  `name` varchar(60) NOT NULL default '',
  `email` varchar(60) NOT NULL default '',
  `trans_id` varchar(64) NOT NULL default '',
  `auth_code` varchar(6) NOT NULL default '',
  `c_stamp` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`registration_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

