<?php require("scripts/template-start.php"); ?>
<tr>
   <td rowspan=2 style="width: 178px; " valign=top>
	<img src="images/lindseyk.jpg" style="margin: 0px 0px 2px 0px;">
	<!-- <img src="images/callingcardbaby.jpg" style="margin: 0px 2px 2px 0px;" align="right">	-->	
   </td>
   <td style="background: #A8BFE6;" align="center">
	<img src="images/template-mission.gif"><br>
   </td>
   <td rowspan=2 style="width: 150px; background: #A8BFE6;" valign=top>
     <img src="images/floppybaby.jpg" style="margin: 0px 0px 0px 0px;" width=150>
     <img src="images/photo-baby.jpg" style="margin: 0px 0px 0px 0px;" width=150 border=0>
   </td>
</tr>
   <td valign=top>
<p style="margin: 10px 25px 20px 25px; font-family: garamond; font-size: 19px; text-align: left;">
Infant Botulism is an orphan ("rare") disease that affects infants  primarily  between one and 52 weeks of age. First recognized in 1976, infant botulism occurs globally and is the most common form of human botulism in the United States. <br><br>Infant botulism is a  novel  form of  human  botulism in which ingested spores of <i>Clostridium botulinum</i> colonize and grow in the  infant's large intestine and produce botulinum neurotoxin in it. The action of the toxin in the body produces  constipation,  weakness  (notably of gag, cry, suck and swallow), loss of muscle tone, and  ultimately, flaccid (&quot;limp&quot;) paralysis. Affected infants have difficulty feeding and often, breathing. However, in the absence of complications, patients recover completely from the disease.
</p>
   </td>

<?php require("scripts/template-end.php"); ?>
