<?php require("../scripts/template-start.php"); ?>

   <td class="title" valign=top>
		&nbsp;Contact Us
   </td>

</tr>
<tr>
<td class="main">
<!-- <img src="../images/callingcardpic.gif" border=0 align=right> -->
	<img src="../images/floppybaby.jpg" style="margin: 0px 20px 10px 0px;" width=150 align=left>
	<span class="emphasis2" style="color:#CC0000">If you have a patient suspected of having infant botulism,<br>Call (510) 231-7600 (24 hours a day, 7 days a week, including holidays).</span><br><br>
	If you have non-urgent questions or comments, please email the program at: <a href="mailto:ibtpp@infantbotulism.org">ibtpp@infantbotulism.org</a>

	</td>

<?php require("../scripts/template-end.php"); ?>
