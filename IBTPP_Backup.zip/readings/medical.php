<?php require("../scripts/template-start.php"); ?>

   <td class="title" valign=top>
		&nbsp;Medical Literature
   </td>

</tr>
<tr>
	<td class="main">
<p><span class="emphasis1">Textbook Chapters</span><br>
	<ul>
	<li><a class="readinglink" target="_blank" href="ibchap.pdf">I.B. Chapter in the <i>Textbook of Pediatric Infectious Disease, fifth edition</i></a></li>
	<li><a class="readinglink" target="_blank" href="http://www.dhs.ca.gov/ps/dcdc/InfantBot/toxemia.htm">Botulism as an Intestinal Toxemia chapter in <i>Infections of the Gastrointestinal Tract, 1995</i></a></li>
	</ul>
</p>

<p>
<span class="emphasis1">Journal Articles</span><br>
	<ul>
	<li><a class="readinglink" target="_blank" href="nejm-big.pdf">Human Botulism Immune Globulin for the Treatment of Infant Botulism</a></li>
	<li><a class="readinglink" target="_blank" href="c-difficile.pdf"><i>Clostridium difficile</i> colitis associated with Infant Botulism</a></li>
	<li><a class="readinglink" target="_blank" href="clostridium-butyricum.pdf">A case of infant botulism due to neurotoxigenic <i>Clostridium butyricum</i> Type E Associated with <i>Clostridium difficile</i> Colitis</a></li>
	</ul>
</p>

<p>
<span class="emphasis1">Medical Articles</span><br>
	<ul>
	<li><a class="readinglink" target="_blank" href="Peds_Clin_Mims_of_IB_apr07.pdf">Clinical Mimics of Infant Botulism (April '07)</a></li>
	<li><a class="readinglink" target="_blank" href="Peds_Creatn_Devlpmt_BIG_IV_apr07.pdf">Creation and Development of the Public Service Orphan Drug Human Botulism Immune Globulin (April '07)</a></li>
	</ul>
</p>

<p>
<span class="emphasis1">Official State of California Department of Public Health website</span><br>
	<ul>
	<li>For more information about infant botulism, BabyBIG<sup>&reg;</sup> and our Program, you may also visit our webpage on the official State of California, Department of Public Health website:<br>
	<a class="readinglink" target="_blank" href="http://www.cdph.ca.gov/programs/ibtpp/Pages/default.aspx">http://www.cdph.ca.gov/programs/ibtpp/Pages/default.aspx</a></li>
	</ul>
</p>

	</td>

<?php require("../scripts/template-end.php"); ?>
