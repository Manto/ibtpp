<?php require("../scripts/template-start.php"); ?>

   <td class="title" valign=top>
		&nbsp;Parent Support Group
   </td>

</tr>
<tr>
	<td class="main">
	If you are a parent of a baby hospitalized with suspected infant botulism, the Infant Botulism Treatment and Prevention Program (IBTPP) would be happy to provide you with the names and telephone numbers of other parents whose children have been through this disease and recovered, in order to provide you with peer support both during and after your child's hospitalization. Please let the IBTPP know if you are interested in this service by calling 510-231-7600 (collect) at any time.
      <br><br>
	</td>

<?php require("../scripts/template-end.php"); ?>
