<?php require("../scripts/template-start.php"); ?>

   <td class="title" valign=top>
		Preguntas frecuentes acerca del Botulismo Infantil

   </td>


</tr>
<tr>
	<td class="main">

<table border="0" cellpadding="2" cellspacing="0">
<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�Qu� es el botulismo infantil?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>El botulismo infantil es una forma de infecci�n (intestinal) del botulismo, que resulta cuando esporas engullidas de una bacteria particular (<i>Clostridium botulinum</i>) colonizan el intestino grueso del beb� y producen la toxina botulinum en el intestino.  La toxina botulinum causa debilidad y p�rdida de masa muscular porque bloquea la capacidad de las terminaciones nerviosas de mandar se�ales al m�sculo conectado para que se contraiga.  Esta enfermedad comienza con el estre�imiento pero usualmente se nota inicialmente con la dificultad de alimentarse (el aspirar y succionar), un grito d�bil y alterado y una expresi�n facial diminuida.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�C�mo difiere el botulismo infantil del botulismo transmitido por alimentos?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>En el botulismo infantil las esporas de botulismo engullidas activan y producen la toxina botulinum dentro del intestino grueso del beb�.  En el botulismo transmitido por alimentos las esporas del botulismo se activan en la comida y producen la toxina botulinum.  Los ni�os mayores y los adultos contraen el botulismo transmitido por alimentos al comer comida en el que la bacteria del botulismo ha producido la toxina botulinum en la comida.
</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�C�mo contrae el beb� botulismo infantil?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>El beb� contrae el botulismo infantil al engullir las esporas de botulismo en un momento en el que el intestino grande del beb� es vulnerable a la germinaci�n de las esporas y a la producci�n de toxina.  La ciencia m�dica a�n no entiende todos los factores que hacen a un beb� susceptible a la germinaci�n de las esporas del botulismo.  La miel ha sido 
identificada como una fuente que contiene esporas de botulismo que se debe evitar.  Por un proceso de exclusi�n (al realizar pruebas a trav�s de los a�os de comidas, bebidas y otros art�culos que se ponen en las bocas de los ni�os con resultados negativos), se concluy� que la mayor�a de los pacientes de botulismo infantil adquieren sus esporas al engullir part�culas de polvo microsc�picas que contienen esporas.
</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�C�mo se trata el botulismo infantil?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>El botulismo infantil es tratado con cuidado y apoyo meticuloso con atenci�n especial a las necesidades de alimentaci�n y respiraci�n.  En los Estados Unidos la medicina hu�rfana BabyBig<sup>&reg;</sup> se usa para reducir la estancia en el hospital y tambi�n las complicaciones.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�Qu� es BabyBIG<sup>&reg;</sup>?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>La droga hu�rfana BabyBIG<sup>&reg;</sup> es una antitoxina de botulismo derivada del ser humano que fue aprobada (con permiso) por la Administraci�n de Drogas y Alimentos de los Estados Unidos (FDA) para el tratamiento del botulismo infantil el 23 de Octubre, 2003.  El uso de BabyBIG� reduce significativamente la duraci�n de la hospitalizaci�n y los costos asociados a la hospitalizaci�n de los pacientes con botulismo infantil.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�Qu� tan pronto puede ser inmunizado mi hijo/a despu�s del tratamiento de BabyBIG<sup>&reg;</sup>?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>El ni�o deber�a haber recuperado casi por completo o completamente la fuerza y el tono de los m�sculos antes de que comiencen las inmunizaciones de nuevo. Adicionalmente, las vacunas de virus vivos (por ejemplo: rotavirus, sarampi�n, paperas, rub�ola y varicela) deben retrasarse hasta 5 meses despu�s del tratamiento con BabyBIG<sup>&reg;</sup> porque los anticuerpos en BabyBIG<sup>&reg;</sup> podr�an interferir con la eficacia de la vacuna.
<br /><br />En consecuencia, cualquiera de las 3 dosis recomendadas de la vacuna contra el rotavirus (RotaTeq<sup>&reg;</sup>) que no se haya aplicado al ni�o antes del tratamiento con BabyBIG<sup>&reg;</sup> se tendr� que retrasar. Las otras vacunas de virus vivos (por ejemplo: sarampi�n, paperas, rub�ola y varicela) se aplican habitualmente por primera vez a la edad de un a�o; por lo tanto, s�lo los pacientes con botulismo infantil, que tuvieran 7 meses de edad o m�s cuando se les trat� con BabyBIG<sup>&reg;</sup>, tendr�n que retrasar la inmunizaci�n con estas vacunas.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�Hay consecuencias a largo plazo del botulismo infantil?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>Con la ausencia de complicaciones serias contra�das en el hospital, no.  La prognosis para los pacientes de botulismo infantil es para la recuperaci�n entera y completa.  La recuperaci�n resulta con el recrecimiento de las terminaciones nerviosas que podr�n mandar se�ales para que los m�sculos se contraigan.  La toxina botulinum  no penetra en el cerebro, por lo tanto los pacientes de botulismo infantil retienen toda la inteligencia, habilidad atl�tica, habilidad musical, sentido del humor y excentricidad con las cuales nacieron.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�Mi pr�ximo hijo correr� un alto riesgo de botulismo infantil?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>No.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�C�mo se puede prevenir el botulismo infantil?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>La �nica medida de prevenci�n conocida para el botulismo infantil es la de evitar darle miel a los ni�os de 12 meses o menos.  La lactancia podr�a retardar el inicio de la enfermedad si se desarrolla.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>�C�mo puedo contactar a otras familias en mi �rea cuyos ni�os tambi�n tuvieron botulismo infantil?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>Hay dos maneras para hacer esto:  1)  Llamar a IBTPP por cobrar y pedir ayuda, o 2) ir al Forum de los Padres en nuestro sitio (<a href="http://www.infantbotulism.org">www.infantbotulism.org</a>) y seguir las instrucciones</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>

	</td>

<?php require("../scripts/template-end.php"); ?>
