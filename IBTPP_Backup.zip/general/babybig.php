<?php require("../scripts/template-start.php"); ?>

   <td class="title" valign=top>
		&nbsp;What is BabyBIG<sup>&reg;</sup>?
   </td>


</tr>
<tr>
	<td class="main">
<table cellpadding=0 cellspacing=0 border=0>
	<tr><td valign=top><img style="margin: 15px 15px 15px 15;" src="../images/vial.jpg"></td><td>
BabyBIG<sup>&reg;</sup>, Botulism Immune Globulin Intravenous (Human) (BIG-IV), is an orphan drug that consists of human-derived botulism antitoxin antibodies that is approved by the U.S. Food and Drug Administration for the treatment of infant botulism types A and
B.
<br><br>
The product is a solvent-detergent-treated, sterile, lyophilized powder of immunoglobulin G (IgG), stabilized with 5% sucrose and 1% albumin (human).  It contains no preservative.  The purified immunoglobulin is derived from pooled adult plasma from persons immunized with pentavalent botulinum toxoid who were selected for their high titers of neutralizing antibody against botulinum neurotoxins type A and B.  All donors were tested and found negative for antibodies against the human immunodeficiency virus and the hepatitis B and hepatitis C viruses.  The pooled plasma was fractionated by cold ethanol precipitation of the proteins according to the Cohn/Oncley method, modified to yield a product suitable for intravenous administration.
<br><br>
For more information, please visit the following links:<br>
<ul>
<li>"FDA Approval" found at <a href="http://www.fda.gov/cber/products/babybig.htm" target="_blank">http://www.fda.gov/cber/products/babybig.htm</a></li>
<li>"Package Insert for BabyBIG<sup>&reg;</sup>": <a target="_blank" href="http://www.infantbotulism.org/babybig_package_insert.pdf">Package Insert for BabyBIG<sup>&reg;</sup> Lot 3, Sub Lot 3.7</a></li>
<li>"FDA Product Approval Letter" found at <a href="http://www.fda.gov/cber/approvltr/igivcdhs102303L.htm" target="_blank">http://www.fda.gov/cber/approvltr/igivcdhs102303L.htm</a><br><br></li>
</ul>
</td></tr></table>
	</td>

<?php require("../scripts/template-end.php"); ?>

