<?php require("../scripts/template-start.php"); ?>

   <td class="title" valign=top>
		Frequently Asked Questions (FAQs)<br>about Infant Botulism
   </td>


</tr>
<tr>
	<td class="main">

<table border="0" cellpadding="2" cellspacing="0">
<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>What is infant botulism?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>Infant botulism is the infectious (intestinal) form of botulism, which results when swallowed spores of a particular bacterium (<i>Clostridium botulinum</i>) colonize the baby's large intestine and produce botulinum toxin in it.  Botulinum toxin causes weakness and loss of muscle tone because it blocks the nerve ending's ability to signal the linked muscle to contract.  The illness often begins with constipation but is usually first noticed as difficulty feeding (sucking and swallowing), a weak and altered cry and diminished facial expression.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>How does infant botulism differ from foodborne botulism?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>In infant botulism the swallowed botulism spores activate and produce botulinum toxin inside the baby's large intestine.  In foodborne botulism the botulism spores activate in the food and produce botulinum toxin.  Older children and adults get foodborne botulism by eating the food in which the botulism bacteria have produced botulinum toxin in the food.

</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>How does a baby get infant botulism?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>A baby contracts ("gets") infant botulism by swallowing the botulism spores at a moment in time when the baby's large intestine is vulnerable to spore germination and toxin production.  Medical science does not yet understand all the factors that make a baby susceptible to botulism spore germination.  Honey is the one identified and avoidable source of botulinum spores.  By a process of exclusion (testing over the years of hundreds of foods, beverages and other items placed in infants' mouths with negative results), it was concluded that most infant botulism patients acquired their spores by swallowing microscopic dust particles that carry the spores.
</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>How is infant botulism treated?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>Infant botulism is treated with meticulous supportive care with special attention to feeding and breathing needs.  In the United States the orphan drug BabyBIG<sup>&reg;</sup> is also used to shorten hospital stay and reduce complications.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>What is BabyBIG<sup>&reg;</sup>?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>The orphan drug BabyBIG<sup>&reg;</sup> is human-derived botulism antitoxin that was approved (licensed) by the U.S. Food and Drug Administration (FDA) for the treatment of infant botulism on October 23, 2003.  Use of BabyBIG<sup>&reg;</sup> significantly reduces the length of hospital stay and associated hospital costs in patients with infant botulism.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>How soon after BabyBIG<sup>&reg;</sup> treatment can my child be immunized?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>The infant should have good to full recovery of muscle strength and tone before immunizations resume.  In addition, most live-virus vaccines (i.e., measles, mumps, rubella and varicella) will need to be delayed until 5 months after BabyBIG� treatment because the antibodies in BabyBIG<sup>&reg;</sup> may interfere with the effectiveness of the vaccine. The live-virus vaccine for rotavirus, RotaTeq<sup>&reg;</sup> should also be delayed until 5 months after BabyBIG<sup>&reg;</sup> treatment.  Although current data suggest that administration of intravenous immunoglobulin products such as BabyBIG<sup>&reg;</sup> will not interfere with the efficacy of oral rotavirus vaccines, patients with infant botulism should not receive the rotavirus vaccine because of the slowed intestinal motility that results from infant botulism.
<br /><br />
Accordingly, any of the recommended 3 doses of the rotavirus vaccine (RotaTeq<sup>&reg;</sup>) that were not given to the infant before treatment with BabyBIG<sup>&reg;</sup> should be delayed.  Because the other live-virus vaccines (i.e., measles, mumps, rubella and varicella) are normally first given at one year of age, only those infant botulism patients who were 7 months of age or older when they were treated with BabyBIG<sup>&reg;</sup> will need delayed immunization with these vaccines.
</td>
</tr>


<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>Are there any long-term consequences of infant botulism?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>In the absence of serious hospital-acquired complications, no.  The prognosis for infant botulism patients is for full and complete recovery.  Recovery results from regrowth of the nerve endings that then are able to signal the muscles to contract.  Botulinum toxin does not penetrate into the brain, and so infant botulism patients retain all the intelligence, athletic ability, musical ability, sense of humor and orneriness with which they were born.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>Will my next child be at increased risk for infant botulism?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>No.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>How can infant botulism be prevented?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>The only known prevention measure for infant botulism is to avoid feeding honey to infants 12 months of age or less.  Breastfeeding may slow the onset of illness if it develops.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-q.gif" border=0></td>
<td>How do I contact other families in my area whose children also had infant botulism?</td>
</tr>

<tr>
<td valign="top"><img src="http://www.infantbotulism.org/images/qa-a.gif" border=0></td>
<td>There are two ways to do this:  1)  call the IBTPP collect and ask for assistance, or 2) go to the Parents' Forum on this website and follow the instructions there.</td>
</tr>

<tr><td colspan="2"><img src="http://www.infantbotulism.org/images/trans.gif" height=15></td></tr>
</table>

<br />
<a href="http://www.infantbotulism.org/readings/medical.php">Click here</a> for <b>in depth information</b> on infant botulism.
	</td>

<?php require("../scripts/template-end.php"); ?>
