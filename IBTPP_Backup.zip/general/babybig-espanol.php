<?php require("../scripts/template-start.php"); ?>

   <td class="title" valign=top>
		&nbsp;�Qu� es BabyBIG<sup>&reg;</sup>?
   </td>


</tr>
<tr>
	<td class="main">
<table cellpadding=0 cellspacing=0 border=0>
	<tr><td valign=top><img style="margin: 15px 15px 15px 15;" src="../images/vial.jpg"></td><td>
BabyBIG<sup>&reg;</sup>, (Humano) Botulismo Inmune Globulin Intravenoso (BIG-IV) es una medicina hu�rfana que consiste en anticuerpos de antitoxina botul�nica de origen humano que ha sido aprobada por la Administraci�n de Drogas y Alimentos de los Estados Unidos (FDA) para el tratamiento de botulismo infantil de tipos A y B.
<br /><br />
El producto ha sido tratado como un detergente-solvente, est�ril, polvo liofilizado de inmunoglubulin G (IgG), estabilizado con el 5% de sacarosa y el 1% de alb�mina (humana).  No contiene preservativos.  El inmunoglobulin purificado se deriva del plasma de personas inmunizadas con el toxoide pentavalente de botulinum que fueron seleccionadas por sus altos t�tulos de anticuerpos neutralizadores contra las neurotoxinas de botulinum de tipos A y B.  Todos los donadores fueron examinados y dieron resultados negativos a los anticuerpos contra el virus humano de inmunodeficiencia (HIV) y los virus de hepatitis B y hepatitis C.  El plasma acumulado fue fraccionado con una precipitaci�n de etanol fr�o de las prote�nas de acuerdo al m�todo de Cohn/Oncley, modificado para producir un producto adecuado para la administraci�n intravenosa.

</td></tr></table>
	</td>

<?php require("../scripts/template-end.php"); ?>

