<?php require("includes/header.php"); ?>

<div class="main">
	<div class="header">Contact Us</div>

	<table cellpadding="0" cellspacing="0" border="0" style="font-size: 14px;">
		<tr>
			<td style="text-align: right;">Phone:</td>
			<td>510-231-7600</td>
		</tr>
		<tr>
			<td style="text-align: right;">Fax:</td>
			<td>510-231-7609</td>
		</tr>
		<tr>
			<td style="text-align: right;">Email:</td>
			<td><a href="mailto:ibtpp@dhs.ca.gov">ibtpp@dhs.ca.gov</a></td>
		</tr>
		<tr>
			<td style="text-align: right;">Website:</td>
			<td><a href="http://infantbotulism.org">http://infantbotulism.org</a></td>
		</tr>
	</table>
	
<br />
If you have any questions regarding the IBRCC 2007 website or meeting,
please contact one of the following staff:
<br /><br />
	<table cellpadding="0" cellspacing="0" border="0" style="font-size: 13px;">
<tr><td>Jennifer Shih</td>
<td><a href="mailto:jshih@dhs.ca.gov">jshih@dhs.ca.gov</a></td></tr>

<tr><td>Yasmeen Drummond</td>
<td><a href="mailto:ydrummon@dhs.ca.gov">ydrummon@dhs.ca.gov</a></td></tr>

<tr><td>Stephen Arnon, M.D.</td>
<td><a href="mailto:sarnon@dhs.ca.gov">sarnon@dhs.ca.gov</a></td></tr>
</table>

</div>


<?php require("includes/footer.php"); ?>
