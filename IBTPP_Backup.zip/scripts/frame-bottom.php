<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<?php $homedir="../"; ?>
    <link rel=stylesheet type="text/css" href="http://www.infantbotulism.org/scripts/common.css" title="common">
	<title>Welcome to the Infant Botulism Treatment and Prevention Program</title>
</head>
<body style="background: #5278B6;">
<table cellpadding=0 cellspacing=0 border=0 width=100% style="width: 100%;">
<tr>
<td valign=middle style="font-family: Garamond; font-size: 12px; color: #FFFFFF; text-align: center; background: #5278B6; height: 34px;">For non-urgent questions and comments, please email<br><img src="../images/trans.gif" height=5><br> <a style="color: #FFFFFF;" href="mailto:ibtpp@infantbotulism.org">ibtpp@infantbotulism.org</a><br>
<img src="../images/trans.gif" height=5><br>
<span style="font-size: 10px;">(The entire contents of this website are &copy; 2004 by the California Department of Health Services)<span>
</td>
</tr>
</table>


</body>
</html>
