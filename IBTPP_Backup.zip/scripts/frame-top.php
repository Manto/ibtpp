<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<?php $homedir="../"; ?>
    <link rel=stylesheet type="text/css" href="http://www.infantbotulism.org/scripts/common.css" title="common">
	<title>Welcome to the Infant Botulism Treatment and Prevention Program</title>
</head>

<body>

<table cellpadding=0 cellspacing=0 border=0 style="width: 100%;">
<tr>
   <td style="background: #5278B6; text-align:center; height: 79px;">&nbsp;<a href="http://www.infantbotulism.org/home.php" target="main"><img border="0" src="http://www.infantbotulism.org/images/menubg.png" height=79 width=780 border=0></a>&nbsp;</td>
</tr>
<tr><td style="height: 2px;"><img src="http://www.infantbotulism.org/images/white.gif" height=2 width=200></td></tr>
<tr><td style="height: 20px; background: #EDC863;"><img src="http://www.infantbotulism.org/images/menubg.gif" height=20 width=200></td></tr>
<tr><td style="height: 2px;"><img src="http://www.infantbotulism.org/images/white.gif" height=2 width=200></td></tr>

</table>

</body>
</html>