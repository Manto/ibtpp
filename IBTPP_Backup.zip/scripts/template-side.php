   <td style="width: 152px; padding:4px;" valign=top rowspan=2>

<table cellpadding=4 cellspacing=0 border=0 style="border: 1px solid #000000; background: #EDC863;">
<tr><td>Printable version of this page<br>
<a href="http://www.walkingideas.com/ibtpp/physician/obtain.php">Checklist for physicians</a><br>
<a href="http://www.walkingideas.com/ibtpp/contact/index.php">Contact the IBTPP</a><br>
<A HREF="http://www.adobe.com/products/acrobat/readstep2.html"><IMG SRC="http://www.adobe.com/images/get_adobe_reader.gif" ALT="Get Adobe Reader" HEIGHT="31" WIDTH="88" BORDER="0"></A>
</td></tr></table>
   </td>
