<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<?php $homedir="../"; ?>
    <link rel=stylesheet type="text/css" href="http://www.infantbotulism.org/scripts/common.css" title="common">
	<title>Welcome to the Infant Botulism Treatment and Prevention Program</title>
</head>

<body>

<table cellpadding=0 cellspacing=0 border=0 style="width: 100%;">
<tr>
   <td style="background: #5278B6; text-align:center; height: 79px;"><img src="http://www.infantbotulism.org/images/template-top.gif" height=79 width=780 border=0></td>
</tr>
</table>

<table cellpadding=0 cellspacing=0 border=0 style="width: 100%;">
<tr>