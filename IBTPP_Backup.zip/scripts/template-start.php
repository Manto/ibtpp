<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<?php $homedir="../"; ?>
    <link rel=stylesheet type="text/css" href="http://www.infantbotulism.org/scripts/common.css" title="common">
	<title>Welcome to the Infant Botulism Treatment and Prevention Program</title>
</head>

<body style="margin: 0px 0px 0px 0px; padding: 0px 0px 0px 0px;">

<table cellpadding=0 cellspacing=0 border=0 style="width: 100%;">
<tr><td style="height: 22px; background: #EDC863;"><img src="http://www.infantbotulism.org/images/menubg.gif" height=22 width=200></td></tr>
<tr><td style="height: 4px;"><img src="http://www.infantbotulism.org/images/white.gif" height=2 width=200></td></tr>
</table>

<script type="text/javascript" src="http://www.infantbotulism.org/scripts/menu.js"></script>
<script type="text/javascript" src="http://www.infantbotulism.org/scripts/menu_items.js"></script>
<script type="text/javascript" src="http://www.infantbotulism.org/scripts/menu_tpl2.js"></script>
<script type="text/javascript" >
	<!--//
	// each menu gets two parameters (see demo files)
	// 1. items structure
	// 2. geometry structure
	new menu (MENU_ITEMS, MENU_POS);
	// also take a look at stylesheets loaded in header in order to set styles
	//-->
</script>

<table cellpadding=0 cellspacing=0 border=0 style="width: 100%;">
<tr>