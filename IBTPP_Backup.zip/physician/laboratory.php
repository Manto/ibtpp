<?php if ($_GET["printable"]==1)
	require("../scripts/template-start-printable.php");
	else require("../scripts/template-start.php"); ?>
	
   <td class="title" valign=top>
		&nbsp;Laboratory Diagnosis
   </td>

	<td class="title" align=right>
	<?php if ($_GET["printable"]!=1) { ?>
	<a style="text-decoration: underline" href="#" onClick='window.open("<?php echo $_SERVER['PHP_SELF']."?printable=1";?>" ,"IBTPP","toolbar=yes, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=800, height=600")'><img src="http://www.infantbotulism.org/images/file.gif" border=0>Printable Version of this Page</a>
	<?php } ?>
	</td>

</tr>
<tr>
	<td class="main" colspan=2>
The disease infant botulism is first suspected based on clinical features of the infant patient (12 months of age or younger).  Symptoms such as poor feeding, droopy eyelids, constipation and lethargy, coupled with bulbar palsies, hypotonia, weakness and loss of head control, typically prompt, with one or two very rare exceptions, physicians to consider botulinum toxin as a possible cause.  Accordingly, it is necessary for prompt laboratory analysis to be performed to establish the diagnosis.  Prompt laboratory diagnosis of infant botulism is helpful for patient management and will rule-out the possibility of fatal degenerative neuromuscular diseases.
<br><br>
The laboratory diagnosis of infant botulism is a two-step process.  The first step is to perform a direct toxin analysis.  This requires the extraction of toxin directly from the fecal specimen and the use of specialized techniques to identify and type the toxin.  The second step is to culture the feces using specialized media and techniques in order to isolate <i>Clostridium botulinum</i>.
<br><br>
For more information on specimen collection, please visit our specimen collection page for laboratory scientists at <a href="http://www.infantbotulism.org/laboratorian/collection.php">http://www.infantbotulism.org/laboratorian/collection.php</a>.
<br><br>
	<?php if ($_GET["printable"]!=1) { ?>
	<a style="text-decoration: underline" href="#" onClick='window.open("<?php echo $_SERVER['PHP_SELF']."?printable=1";?>" ,"IBTPP","toolbar=yes, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=800, height=600")'><img src="http://www.infantbotulism.org/images/file.gif" border=0>Printable Version of this Page</a>
	<?php } ?>
		</td>


<?php if ($_GET["printable"]==1)
	require("../scripts/template-end-printable.php");
	else require("../scripts/template-end.php"); ?>
