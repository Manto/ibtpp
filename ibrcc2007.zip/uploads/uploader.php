<?
	/*
	Silentum Uploader v1.2.0
	Modified March 4, 2007
	uploader.php copyright 2005-2007 "HyperSilence"
	*/

	// Begin options

	$allow_file_deletion = false; // To allow visitors to delete files, leave this at true; otherwise, change it to false

	$file_extensions = array(".pdf"); // Add or delete the file extensions you want to allow

	$file_extensions_list = ".pdf"; // Type the same as above, without the quotes separating them

	$max_length = 30; // The maximum character length for a file name

	$maximum_file_size = "5120000"; // In bytes

	$upload_log_file = "upload_log.txt"; // Change this to the log file you want to use

	// End options

	$folder_directory = "http://".$_SERVER["HTTP_HOST"].dirname($_SERVER["PHP_SELF"]);
	$message = "";
	$set_chmod = 0;
	$site_uri = "http://".$_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"];
	$upload_directory = "files/";
	$upload_uri = $folder_directory."/files/";

	if($allow_file_deletion == true) $status = "enabled";
	else $status = "disabled";

	if($_REQUEST["delete"] && $allow_file_deletion) {
	$resource = fopen($upload_log_file,"a");
	fwrite($resource,date("F d, Y / h:i:sa")." - ".$_REQUEST["delete"]." deleted by ".$_SERVER["REMOTE_ADDR"]."\n");
	fclose($resource);

	if(strpos($_REQUEST["delete"],"/.") > 0);
	elseif(strpos($_REQUEST["delete"],$upload_directory) === false);
	elseif(substr($_REQUEST["delete"],0,6) == $upload_directory) {
	unlink($_REQUEST["delete"]);
	$message = "File has been deleted.";
	header("Location: $site_uri?message=$message");
	}
	}

	elseif($_FILES["userfile"]) {
	$resource = fopen($upload_log_file,"a");
	fwrite($resource,date("F d, Y / h:i:sa")." - ".$_FILES["userfile"]["name"]." "
	.$_FILES["userfile"]["type"]." uploaded by ".$_SERVER["REMOTE_ADDR"]."\n");
	fclose($resource);

	$file_type = $_FILES["userfile"]["type"]; 
	$file_name = $_FILES["userfile"]["name"];
	$file_ext = strtolower(substr($file_name,strrpos($file_name,".")));
	chmod($upload_uri."".$file_name, 0755);
	if($_FILES["userfile"]["size"] > $maximum_file_size) {
	$message = "ERROR: File size cannot be over ".$maximum_file_size." bytes.";
	}

	elseif($file_name == "") $message = "ERROR: Please select a file to upload.";
	elseif(strlen($file_name > $max_length)) $message = "ERROR: The maximum length for a file name is ".$max_length." characters.";
	elseif(!preg_match("/^[A-Z0-9_.\- ]+$/i",$file_name)) $message = "ERROR: Your file name contains invalid characters.";
	elseif(!in_array($file_ext, $file_extensions))
	$message = "ERROR: <ins>$file_ext</ins> is not an allowed file extension.";
	else $message = upload_file($upload_directory, $upload_uri);
	header("Location: $site_uri?message=$message");
	}

	elseif(!$_FILES["userfile"]);
	else $message = "ERROR: Invalid file specified.";

	$open = opendir($upload_directory);
	$uploaded_files = "";
	while($file = readdir($open)) {
	if(!is_dir($file) && !is_link($file)) {
	$uploaded_files .= "		<tr>
				<td style=\"background: #fff; color: #000; text-align: left; width: 70%\"><a href=\"$upload_directory$file\" title=\"$file (".filesize($upload_directory."".$file)." bytes)\">".$file."</a> (".filesize($upload_directory."".$file)." bytes)</td>";
	if($allow_file_deletion)
	$uploaded_files .= "
				<td style=\"background: #fff; color: #000; text-align: right; width: 30%\"><a href=\"?delete=$upload_directory".urlencode($file)."\" title=\"Delete File\">Delete File</a></td>";
	else
	$uploaded_files .= "
				<td style=\"background: #fff; color: #000; text-align: right; width: 30%\"><del><strong>Delete File</strong></del></td>";
	$uploaded_files .= "
			</tr>
			<tr>
				<td colspan=\"2\" style=\"background: #eee; color: #000; text-align: left; text-indent: 20px\">Uploaded <strong>".date("F d, Y / h:ia", filemtime($upload_directory.$file))."</strong></td>";
	$uploaded_files .="
			</tr>
	";
	}
	}

	function upload_file($upload_directory, $upload_uri) {
	$file_name = $_FILES["userfile"]["name"];
	$file_name = str_replace(" ","_",$file_name);
	$file_path = $upload_directory.$file_name;
	$temporary = $_FILES["userfile"]["tmp_name"];

	$result = move_uploaded_file($temporary, $file_path);
	if(!chmod($file_path,0777))
	$message = "ERROR: A folder to place the files was not found, or the files need to be CHMODed to 777.";
	else $message = ($result)?"File has been uploaded." : "An error has occurred.";
	return $message;
	}
?>