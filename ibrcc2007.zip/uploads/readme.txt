<?
	include("uploader.php");
?>
		<p><strong><span style="background: #fff; color: #000"><? if($_REQUEST["message"] == "") echo "Upload a file below."; else echo $_REQUEST["message"]?></span></strong></p>
		<form action="upload.php" enctype="multipart/form-data" id="upload" method="post">
			<p><input id="userfile" name="userfile" size="45" type="file" /><input name="upload" type="submit" value="Upload File" /><br /></p>

			<p>Allowed file extensions: <strong><?=$file_extensions_list?></strong></p>

			<p>Maximum file size: <strong><?=$maximum_file_size?> bytes (~<?=round($maximum_file_size/1024)?>KB)</strong></p>

			<p>Deleting files is currently: <strong><?=$status?></strong></p>

			<p>Powered by: <a href="http://hypersilence.net" title="Silentum Uploader v1.2.0">Silentum Uploader v1.2.0</a></p>
		</form>

		<p><strong>Uploaded Files</strong></p>
		<table style="border: 2px dotted #000; width: 100%">
	<? if($uploaded_files == "") echo "		<tr>
				<td colspan=\"2\" style=\"background: #fff; color: #000; text-align: center\"><br /><strong>There are no uploaded files.</strong><br /><br /></td>
			</tr>
	"; else echo $uploaded_files ?>
	</table>