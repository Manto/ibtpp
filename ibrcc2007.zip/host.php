<?php require("includes/header.php"); ?>

<div class="main">
	<div class="header">Host of IBRCC 2007- The Infant Botulism Treatment and Prevention Program</div>
<br />
This year's IBRCC is being organized by the Infant Botulism Treatment and Prevention Program (IBTPP) of the California Department of Public Health (renamed as of July 1, 2007) , located in Richmond, California.
<br /><br />
The mission of the IBTPP is to provide and improve the treatment and prevention of infant botulism and related diseases.  IBTPP provides diagnostic and treatment consultation to physicians inside and outside of the United States who think that their patients may have infant botulism.  For treatment of suspected and confirmed cases, IBTPP provides BabyBIG<sup>&reg;</sup>, Botulism Immune Globulin Intravenous (Human) (BIG-IV), a licensed orphan drug that consists of human-derived botulism antitoxin antibodies. 
<br /><br />
Please click on the Contact Us tab to meet and view the current staff of the IBTPP.   We  look forward to seeing you at Asilomar in October.
</div>
	
<?php require("includes/footer.php"); ?>
