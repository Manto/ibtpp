<?php
$db = mysql_connect("localhost", "infantbo", "big506");
mysql_select_db("ibrcc_abstract");

require("includes/header.php");
?>


<div class="main">
	<div class="header">Registration</div>

To register for IBRCC, you need to register for both the conference and the housing at Asilomar.

<table cellpadding="0" cellspacing="0" border="0">
	
	<tr>
		<td style="width: 50%; vertical-align: top;">
	<div class="header_small">Housing</div>
	<ul>
<li>Guest rooms are assigned on first come, first served basis.</li>
<li>Rates are <b>per person</b>. One form per person or family.</li>
<li>If your choice is not available you will be assigned based on availability and the appropriate charge will apply.</li>
<li>Meals and applicable taxes are included in rates.</li>
<li><b>You can only fax or email the form in, no phone calls are allowed</b></li>
</ul>

		<div style="text-align: center; padding: 4px;">
<a class="registration" href="IBRCC_2007_Housing_Registration_Form.doc" target="_blank">Download Housing Registration Form</a>
		</div>
<br />
		<table cellpadding="0" cellspacing="0" border="0" style="margin-left: auto; margin-right: auto;">
			<tr>
				<td style="font-weight: bold;">Standard Single</td>
				<td>$737.16 each</td>
			</tr>
			<tr>
				<td style="font-weight: bold;">Standard Double</td>
				<td>$454.48 each</td>
			</tr>
			<tr>
				<td style="font-weight: bold;">Historic Single</td>
				<td>$609.56 each</td>
			</tr>
			<tr>
				<td style="font-weight: bold;">Historic  Double</td>
				<td>$407.16 each</td>
			</tr>
		</table>
		
		</td>
		<td style="width: 50%; vertical-align: top;">
		<div class="header_small">Conference</div>
		<div style="text-align: center; padding: 4px;">
			The cost of registering for the conference is $150.  You can submit your information and pay with a credit card over the Internet using our online registration form below.
			<br /><br />
There will be no on-site registration and no payments by personal or institutional check.
			<br /><br />
<a class="registration" href="https://www.ibrcc2007.org/registration_conference.php">Register For Conference Online</a>
		</div>
		</td>
	</tr>
</table>
</div>
	
<?php require("includes/footer.php"); ?>