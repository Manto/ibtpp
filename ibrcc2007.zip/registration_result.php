<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>IBRCC 2007</title>
<link rel="stylesheet" type="text/css" href="https://www.ibrcc2007.org/includes/main.css" />
</head>
<body>
<div id="sexyBG"></div>

<div style="width: 100%; background-image: url('https://www.ibrcc2007.org/images/topbg3.png'); background-repeat: repeat-x; height: 144px; text-align: center;">
	<img src="https://www.ibrcc2007.org/images/logo3.png" style="height: 48px;" />
	<div style="position: relative; top: -1px; margin-left: auto; margin-right: auto;"><a href="http://www.ibrcc2007.org/index.php"><img id="menu1" src="https://www.ibrcc2007.org/images/menu1.jpg" /></a><img src="https://www.ibrcc2007.org/images/menu_gap.png" /><a href="http://www.ibrcc2007.org/program.php"><img id="menu2" src="https://www.ibrcc2007.org/images/menu2.jpg" /></a><img src="https://www.ibrcc2007.org/images/menu_gap.png" /><a href="http://www.ibrcc2007.org/submitabstract.php"><img id="menu3" src="https://www.ibrcc2007.org/images/menu3.jpg" /></a><img src="https://www.ibrcc2007.org/images/menu_gap.png" /><a href="http://www.ibrcc2007.org/registration.php"><img id="menu4" src="https://www.ibrcc2007.org/images/menu4.jpg" /></a><img src="https://www.ibrcc2007.org/images/menu_gap.png" /><a href="http://www.ibrcc2007.org/venue.php"><img id="menu5" src="https://www.ibrcc2007.org/images/menu5.jpg" /></a><img src="https://www.ibrcc2007.org/images/menu_gap.png" /><a href="http://www.ibrcc2007.org/directions.php"><img id="menu6" src="https://www.ibrcc2007.org/images/menu6.jpg" /></a><img src="https://www.ibrcc2007.org/images/menu_gap.png" /><a href="http://www.ibrcc2007.org/contactus.php"><img id="https://www.ibrcc2007.org/menu7" src="https://www.ibrcc2007.org/images/menu7.jpg" /></a></div>
	<div style="position: relative; top: 6px;margin-left: auto; margin-right: auto; color: #000; font-size: 13px; font-family: tahoma; font-weight: bold;">
	<table cellpadding="0" cellspacing="0" border="0" style="margin-left: auto; margin-right: auto;">
		<tr>
			<td style="padding: 0px 4px 0px 4px; text-align: right;">Registration Deadline:</td>
			<td style="padding: 0px 4px 0px 4px; text-align: left;"><span style="color: #036">August 1st, 2007</span>.</td>
			<td rowspan="2">Click <a href="registration.php" style="color: #000">HERE</a> to register now. </td>
		</tr>
		<tr>
			<td style="padding: 0px 4px 0px 4px; text-align: right;">Housing Payment Deadline:</td>
			<td style="padding: 0px 4px 0px 4px; text-align: left;"><span style="color: #036">August 1st, 2007</span>.</td>
		</tr>
		</table>
	</div>
</div>

<script type="text/javascript">
	for (var i=1; i<= 7; i ++) {
		el = document.getElementById("menu"+i);
		el.onmouseover = function() { this.src = "https://www.ibrcc2007.org/images/"+this.id+"_over.jpg"; };
		el.onmouseout= function() { this.src = "https://www.ibrcc2007.org/images/"+this.id+".jpg"; };
	}
</script>

<?php
$db = mysql_connect("localhost", "ibrcc", "big506");
mysql_select_db("ibrcc");
?>

<?php
if(isset($_REQUEST["is_mba"]) && $_REQUEST["is_mba"] == "1") {
?>

<div class="main">
	<div class="header">Monterey Bay Aquarium Tour Registration</div>

<?php 

switch($_POST["x_response_code"]) {

case "1":

	foreach($_REQUEST as $key=>$val) {
		$_REQUEST[$key] = addslashes($val);
	}

	$sql = <<<EOT
INSERT INTO mba (name, email, trans_id, auth_code, c_stamp)
VALUES (
'{$_REQUEST["name"]}', '{$_REQUEST["x_email"]}','{$_REQUEST["x_trans_id"]}', '{$_REQUEST["x_auth_code"]}', NOW()
);
EOT;
echo $sql;
	$result = mysql_query($sql);
if(!$result) {
$err = mysql_error();

echo <<<EOT
<b>Your payment has been successfully processed.</b>
<br /><br />
However, there was an issue while saving your contact info.  Please contact Yasmeen Drummond at Yasmeen.Drummond@cdph.ca.gov to ensure that we have your contact info.
<br /><br />
{$err}
<br /><br />
We look forward to seeing you at Asilomar.
EOT;

}
else {

$msg = <<<EOT
Dear {$_REQUEST["name"]}:

Monterey Bay Aquarium group tour, Tuesday, October 16.
Bus leaves Asilomar at 1:30pm.

IBRCC and Organizing Committee
EOT;

$headers = 'From: IBRCC 2007 Registration <payment@ibrcc2007.org>' . "\r\n" .
    'Reply-To: payment@ibrcc2007.org' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
    
mail($_POST["x_email"], "IBRCC 2007 - Monterey Bay Aquarium Tour Confirmation", $msg, $headers);

echo <<<EOT
<b>Your payment has been successfully processed.</b>
<br /><br />
Thank you for registering for the Monterey Bay Aquarium tour.
<br /><br />
We look forward to seeing you at Asilomar.
EOT;
}
	break;
case "2":
case "3":
if ($_POST["x_response_reason_code"] == "97") {
	$_POST["x_response_reason_text"] .= " You left your registration page open for too long and the transaction could not be accepted for security reason.";
}
echo <<<EOT
<div class="error">Sorry, but there was an error when processing your payment:<br />{$_POST["x_response_reason_text"]}</div>
<br />
<b>Please <a href="#" onclick="document.location='https://www.ibrcc2007.org/registration_mba.php?'">GO BACK</a> to the payment page and try the transaction again.</b>
EOT;

mail("mantle@gmail.com, ydrummon@dhs.ca.gov","IBRCC 2007 Registration Error", print_r($_POST, true));
}

?>

<? 
}
else {
?>

<div class="main">
	<div class="header">Registration</div>

<?php 

switch($_POST["x_response_code"]) {

case "1":

	foreach($_REQUEST as $key=>$val) {
		$_REQUEST[$key] = addslashes($val);
	}

	$realdegree = array();
	$degrees = array("PhD","MPH","MS","MD","DVM","Other");
	foreach($degrees as $val) {
		if(isset($_REQUEST["degree_".$val]) && $_REQUEST["degree_".$val] == "1") {
			array_push($realdegree, $val);
		}
	}
	$degree = implode(",",$realdegree);

	$sql = <<<EOT
INSERT INTO registrations (title, name, badgename, institution, department, degree, address, city, state, zip, country, businessphone, cellphone, fax, email,
submitabstract, presentation, trans_id, auth_code, c_stamp)
VALUES (
'{$_REQUEST["title"]}', '{$_REQUEST["name"]}', '{$_REQUEST["badgename"]}', '{$_REQUEST["institution"]}', '{$_REQUEST["department"]}', '{$degree}', '{$_REQUEST["address"]}',
'{$_REQUEST["city"]}','{$_REQUEST["state"]}','{$_REQUEST["zip"]}','{$_REQUEST["country"]}','{$_REQUEST["businessphone"]}','{$_REQUEST["cellphone"]}',
'{$_REQUEST["fax"]}','{$_REQUEST["x_email"]}','{$_REQUEST["submitabstract"]}','{$_REQUEST["presentation"]}', 
'{$_REQUEST["x_trans_id"]}', '{$_REQUEST["x_auth_code"]}', NOW()
);
EOT;
	$result = mysql_query($sql);
if(!$result) {
$err = mysql_error();

echo <<<EOT
<b>Your payment has been successfully processed.</b>
<br /><br />
However, there was an issue while saving your contact info.  Please contact Yasmeen Drummond at Yasmeen.Drummond@cdph.ca.gov to ensure that we have your contact info.
<br /><br />
{$err}
<br /><br />
We look forward to seeing you at Asilomar.
EOT;

}
else {

$msg = <<<EOT
Dear {$_REQUEST["badgename"]}:
I am delighted that you will be attending the 2007 Interagency Botulism Research and Coordinating Committee Meeting at Asilomar Conference Grounds. This email confirms your registration for the conference.
Please check the conference website frequently (www.IBRCC2007.org; Login: ibrcc2007;  Password:  asilomar).  We will post updates and useful information there.  Our intent and goal is to have a paperless meeting until we convene.
Also, please note that your registration fee includes the cost of the informal "Beach Barbeque" on Monday evening, October, 15 and the traditional IBRCC Banquet on Wednesday evening, October 17.  
For Directions to Asilomar, please see the IBRCC Conference Directions web page: http://www.ibrcc2007.org/direction.php
Before the meeting, any questions about the program or presenting should be directed to Yasmeen Drummond, at ydrummon@dhs.ca.gov, or Jennifer Shih at jshih@dhs.ca.gov (July 20).  
At the meeting, please look for people with a blue and gold ribbon on their badge for help with any on-site questions or needs.  These individuals will be IBTPP staff who have been designated to be problem-solvers.  
We look forward to seeing you at Asilomar.

Cordially,

Steve Arnon
For the IBRCC and Organizing Committee
EOT;

$headers = 'From: IBRCC 2007 Registration <payment@ibrcc2007.org>' . "\r\n" .
    'Reply-To: payment@ibrcc2007.org' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();
    
mail($_POST["x_email"], "IBRCC 2007 Botulism Meeting Confirmation Email", $msg, $headers);

echo <<<EOT
<b>Your payment has been successfully processed.</b>
<br /><br />
Thank you for registering for this year's IBRCC.  You should receive a confirmation email that will also contain important information you should know prior to attending the conference.
<br /><br />
We look forward to seeing you at Asilomar.
EOT;
}
	break;
case "2":
case "3":
if ($_POST["x_response_reason_code"] == "97") {
	$_POST["x_response_reason_text"] .= " You left your registration page open for too long and the transaction could not be accepted for security reason.";
}
echo <<<EOT
<div class="error">Sorry, but there was an error when processing your payment:<br />{$_POST["x_response_reason_text"]}</div>
<br />
<b>Please <a href="#" onclick="document.location='https://www.ibrcc2007.org/registration_conference.php?'">GO BACK</a> to the payment page and try the transaction again.</b>
EOT;

mail("mantle@gmail.com, ydrummon@dhs.ca.gov","IBRCC 2007 Registration Error", print_r($_POST, true));
}

?>

<?php
}
?>

</div>
	
<div class="footer">Copyright &copy; 2007 Infant Botulism Treatment and Prevention Program, All rights reserved.</div>

</body>

</html>