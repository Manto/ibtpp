<?php require("includes/header.php"); ?>
<?php
$db = mysql_connect("localhost", "ibrcc", "big506");
mysql_select_db("ibrcc");
?>

<script src="includes/sorttable.js"></script>
<style>
td.tblheader {
	background-color: #333;
	color: #fff;
	border: 1px solid #ffffff;
}
</style>
<div class="main">
	<div class="header">Posters and Presentations</div>
<hr />

<?php
	$sql = "SELECT * FROM abstracts ORDER BY c_stamp DESC;";
	
	$result = mysql_query($sql);
	if(!$result) {
		echo $sql . "<br />".mysql_error();
	}
	else {
		$row_count = mysql_num_rows($result);
		echo <<<EOT

		<table class="sortable" name="maintable" id="maintable" cellpadding="2" cellspacing="0" border="0" style="width: 100%;">
		<tr>
			<td class="tblheader" style="cursor: pointer;"><b>Title</b></td>
			<td class="tblheader" style="cursor: pointer;"><b>Authors</b></td>
			<td class="tblheader" style="cursor: pointer;"><b>Affiliation</b></td>
			<td class="tblheader" style="cursor: pointer;"><b>Category</b></td>
			<td class="tblheader" style="cursor: pointer;"><b>Downloads</b></td>
			<!--
			<td class="tblheader" style="cursor: pointer;"><b>Abstract</b></td>
			<td class="tblheader" style="cursor: pointer;"><b>Poster</b></td>
			<td class="tblheader" style="cursor: pointer;"><b>Presentation</b></td>
			-->
		</tr>
EOT;
		$oddrow = 0;
		$color = "ffffff";
		while($row = mysql_fetch_array($result)) {
			if($oddrow%2 == 0)
				$color = "eeeeee";
			else
				$color = "ffffff";
			
			echo <<<EOT
		<tr>
			<td style="background-color: #{$color}">{$row["title"]}</td>
			<td style="background-color: #{$color}">{$row["author"]}</td>
			<td style="background-color: #{$color}">{$row["affiliation"]}</td>
			<td style="background-color: #{$color}">{$row["category"]}</td>
			<td style="background-color: #{$color}">
<table cellpadding="0" cellspacing="0" border="0">
<tr><td>Abstract:</td><td><a href="showabstract.php?id={$row["abstract_id"]}&pdf=1" target="_blank">PDF</a></td></tr>
EOT;

$hasPoster = file_exists("uploads/files/".$row["abstract_id"]."_poster.pdf");
$hasPresentation = file_exists("uploads/files/".$row["abstract_id"]."_presentation.pdf");

echo "<tr><td>Poster:</td><td>";
if($hasPoster) { ?>
<a href="uploads/files/".$row["abstract_id"]."_poster.pdf" target="_blank">PDF</a>
<?php } else { ?>
-- 
<?php }
echo "</td></tr>";

echo "<tr><td>Presentation:</td><td>";

if($hasPresentation) { ?>
<a href="uploads/files/".$row["abstract_id"]."_presentation.pdf" target="_blank">PDF</a>
<?php } else { ?>
--
<?php }
echo "</td></tr>";

			echo <<<EOT
</table>
			</td>
		</tr>
EOT;
			$oddrow++;
		}
		echo "</table>\n";
	}
?>

</div>

<script type="text/javascript" src="includes/sortTable.js"></script>
<script type="text/javascript">
initTable("maintable");
</script>

<?php require("includes/footer.php");