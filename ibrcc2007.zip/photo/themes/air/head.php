<link rel="stylesheet" href="<?php echo THEME_URL ?>gallery.css" type="text/css" media="screen" />
<script src="<?php echo THEME_URL ?>dynamics.js" type="text/javascript" ></script>
<!--[if lte IE 6]>
<link rel="stylesheet" href="<?php echo THEME_URL ?>explorer.css" type="text/css" media="screen" />
<![endif]-->
