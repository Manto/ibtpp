<?php

/* Plogger Theme Meta Template

$theme_name:  The name of your theme
$version:  Theme version
$author:  Name of the theme author
$url:  Link to the themes website or author url
$description:  Description of the look and feel of the theme

*/

$theme_name = "Air";
$version = "0.1";
$author = "Oliver Baty";
$url = "http://www.ardamis.com/";
$description = "This is a simple blue and white stand-alone theme.  It looks nearly identical in Firefox 2.0 and Internet Explorer 7, and generates a close approximation using conditional CSS for IE6.";

?>