<?php
	

	print '</div>';

	print ' <div id="pagination">
				<table style="width: 100%;">
					<tr><td>'.plogger_slideshow_link().'</td>
						<td>'.plogger_pagination_control().'</td>
						<td id="sortby-container">'.plogger_sort_control().'</td> 
					</tr>
				</table>
			</div>';

	print '</div>';
	print plogger_download_selected_form_end();
	print '</div>';
?>
