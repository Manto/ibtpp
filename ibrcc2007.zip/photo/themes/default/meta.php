<?php

/* Plogger Theme Meta Template

$theme_name:  The name of your theme
$version:  Theme version
$author:  Name of the theme author
$url:  Link to the themes website or author url
$description:  Description of the look and feel of the theme

*/

$theme_name = "Classic";
$version = "1.0";
$author = "Mike Johnson";
$url = "http://www.plogger.org/themes/";
$description = "This is the basic default theme.  Very simple layout, with descriptions placed in image tooltips.";

?>