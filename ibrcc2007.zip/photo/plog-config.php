<?php
// this is the file used to connect to your database.
// you must change these values in order to run the gallery.
define("PLOGGER_DB_HOST","localhost");
define("PLOGGER_DB_USER","ibrccphoto");
define("PLOGGER_DB_PW","big506");
define("PLOGGER_DB_NAME","ibrccphoto");
?>
