<?php require("includes/header.php"); ?>

<div class="main">
	<div class="header">IBRCC Program Summary</div>
<a href="agenda.php">[SEE DETAILED AGENDA]</a>
	
<table cellpadding="4" cellspacing="0" border="0" style="width: 780px; margin-left: auto; margin-right: auto; font-size: 14px;">

	<tr><td class="program_header" colspan="2">October 15 Monday</td></tr>
	<tr>
		<td>8:30 AM � 12:00 noon</td>
		<td><b>Human Botulism � Its Occurrence and Prevention</b></td>
	</tr>
	<tr>
		<td>1:30 PM � 4:00 PM</td>
		<td><b>Small Molecules for the Prevention and Treatment of Illness</b></td>
	</tr>
	<tr>
		<td>4:00 PM</td>
		<td>Posters open continuously</td>
	</tr>
	<tr>
		<td>6:00 PM</td>
		<td>Beach Barbecue</td>
	</tr>

	<tr><td class="program_header" colspan="2">October 16 Tuesday</td></tr>
	<tr>
		<td>8:30 AM � 9:50 AM</td>
		<td><b>Pharmacokinetics</b></td>
	</tr>
	<tr>
		<td>10:20 AM � 12:00 noon</td>
		<td><b>Botulinum Toxin � Structural and Functional Aspects</b></td>
	</tr>
	<tr>
		<td>7:30 PM � 9:30 PM</td>
		<td><b>Workshop on Pathema - <i>Clostridium</i> Bioinformatics</b></td>
	</tr>
			
	<tr><td class="program_header" colspan="2">October 17 Wednesday</td></tr>
	<tr>
		<td>8:30 AM � 12:00 noon</td>
		<td><b>Large Molecules, including Vaccines, for the Treatment or Prevention of Illness</b></td>
	</tr>
	<tr>
		<td>1:30 PM � 4:00 PM</td>
		<td><b>Detection and Diagnostic Techniques</b></td>
	</tr>
	<tr>
		<td>4:00 PM � 5:00 PM</td>
		<td>Poster Session with Authors Present</td>
	</tr>
	<tr>
		<td>6:00 PM � 7:00 PM</td>
		<td>Hors d�oeuvres and Cocktails</td>
	</tr>
	<tr>
		<td>7:00 PM � 9:30 PM</td>
		<td>Banquet and Hatheway Memorial Lecture</td>
	</tr>
	
	<tr><td class="program_header" colspan="2">October 18 Thursday</td></tr>
	<tr>
		<td>8:50 AM � 11:40 AM</td>
		<td><b>Genomics</b></td>
	</tr>
</table>
</div>
	
<?php require("includes/footer.php"); ?>
