<option class="" value="us">United States</option>
<option class="" value="af">Afghanistan</option>
<option class="" value="al">Albania</option>
<option class="" value="dz">Algeria</option>
<option class="" value="as">American Samoa</option>
<option class="" value="ad">Andorra</option>
<option class="" value="ao">Angola</option>
<option class="" value="ai">Anguilla</option>
<option class="" value="aq">Antarctica</option>

<option class="" value="ag">Antigua, Barbuda</option>
<option class="" value="ar">Argentina</option>
<option class="" value="am">Armenia</option>
<option class="" value="aw">Aruba</option>
<option class="" value="au">Australia</option>
<option class="" value="at">Austria</option>
<option class="" value="az">Azerbaijan</option>
<option class="" value="bs">Bahamas</option>
<option class="" value="bh">Bahrain</option>

<option class="" value="bd">Bangladesh</option>
<option class="" value="bb">Barbados</option>
<option class="" value="by">Belarus</option>
<option class="" value="be">Belgium</option>
<option class="" value="bz">Belize</option>
<option class="" value="bj">Benin</option>
<option class="" value="bm">Bermuda</option>
<option class="" value="bt">Bhutan</option>
<option class="" value="bo">Bolivia</option>

<option class="" value="ba">Bosnia Herzegovina</option>
<option class="" value="bw">Botswana</option>
<option class="" value="bv">Bouvet Island</option>
<option class="" value="io">Br Indian Ocean Terr</option>
<option class="" value="br">Brazil</option>
<option class="" value="bn">Brunei Darussalam</option>
<option class="" value="bg">Bulgaria</option>
<option class="" value="bf">Burkina Faso</option>
<option class="" value="bi">Burundi</option>

<option class="" value="kh">Cambodia</option>
<option class="" value="cm">Cameroon</option>
<option class="" value="ca">Canada</option>
<option class="" value="cv">Cape Verde</option>
<option class="" value="ky">Cayman Islands</option>
<option class="" value="cf">Central African Rep.</option>
<option class="" value="td">Chad</option>
<option class="" value="cl">Chile</option>
<option class="" value="cn">China</option>

<option class="" value="cx">Christmas Isl.</option>
<option class="" value="cc">Cocos Islands</option>
<option class="" value="co">Colombia</option>
<option class="" value="km">Comoros</option>
<option class="" value="cg">Congo</option>
<option class="" value="ck">Cook Islands</option>
<option class="" value="cr">Costa Rica</option>
<option class="" value="ci">Cote d'Ivoire</option>
<option class="" value="hr">Croatia (Hrvatska)</option>

<option class="" value="cu">Cuba</option>
<option class="" value="cy">Cyprus</option>
<option class="" value="cz">Czech Republic</option>
<option class="" value="cs">Czechoslovakia</option>
<option class="" value="dk">Denmark</option>
<option class="" value="dj">Djibouti</option>
<option class="" value="dm">Dominica</option>
<option class="" value="do">Dominican Republic</option>
<option class="" value="tp">East Timor</option>

<option class="" value="ec">Ecuador</option>
<option class="" value="eg">Egypt</option>
<option class="" value="sv">El Salvador</option>
<option class="" value="gq">Equatorial Guinea</option>
<option class="" value="er">Eritrea</option>
<option class="" value="ee">Estonia</option>
<option class="" value="et">Ethiopia</option>
<option class="" value="fk">Falkland Islands</option>
<option class="" value="fo">Faroe Islands</option>

<option class="" value="fj">Fiji</option>
<option class="" value="fi">Finland</option>
<option class="" value="tf">Fr Southern Terr.</option>
<option class="" value="fr">France</option>
<option class="" value="fx">France, Metropolitan</option>
<option class="" value="gf">French Guiana</option>
<option class="" value="pf">French Polynesia</option>
<option class="" value="ga">Gabon</option>
<option class="" value="gm">Gambia</option>

<option class="" value="ge">Georgia</option>
<option class="" value="de">Germany</option>
<option class="" value="gh">Ghana</option>
<option class="" value="gi">Gibraltar</option>
<option class="" value="gb">Great Britain (UK)</option>
<option class="" value="gr">Greece</option>
<option class="" value="gl">Greenland</option>
<option class="" value="gd">Grenada</option>
<option class="" value="gp">Guadeloupe</option>

<option class="" value="gu">Guam</option>
<option class="" value="gt">Guatemala</option>
<option class="" value="gn">Guinea</option>
<option class="" value="gw">Guinea-Bissau</option>
<option class="" value="gy">Guyana</option>
<option class="" value="ht">Haiti</option>
<option class="" value="hm">Heard, McDonald Is</option>
<option class="" value="hn">Honduras</option>
<option class="" value="hk">Hong Kong</option>

<option class="" value="hu">Hungary</option>
<option class="" value="is">Iceland</option>
<option class="" value="in">India</option>
<option class="" value="id">Indonesia</option>
<option class="" value="ir">Iran</option>
<option class="" value="iq">Iraq</option>
<option class="" value="ie">Ireland</option>
<option class="" value="il">Israel</option>
<option class="" value="it">Italy</option>

<option class="" value="jm">Jamaica</option>
<option class="" value="jp">Japan</option>
<option class="" value="jo">Jordan</option>
<option class="" value="kz">Kazakhstan</option>
<option class="" value="ke">Kenya</option>
<option class="" value="ki">Kiribati</option>
<option class="" value="kp">Korea (North)</option>
<option class="" value="kr">Korea (South)</option>
<option class="" value="kw">Kuwait</option>

<option class="" value="kg">Kyrgyzstan</option>
<option class="" value="la">Laos</option>
<option class="" value="lv">Latvia</option>
<option class="" value="lb">Lebanon</option>
<option class="" value="ls">Lesotho</option>
<option class="" value="lr">Liberia</option>
<option class="" value="ly">Libya</option>
<option class="" value="li">Liechtenstein</option>
<option class="" value="lt">Lithuania</option>

<option class="" value="lu">Luxembourg</option>
<option class="" value="mo">Macau</option>
<option class="" value="mk">Macedonia</option>
<option class="" value="mg">Madagascar</option>
<option class="" value="mw">Malawi</option>
<option class="" value="my">Malaysia</option>
<option class="" value="mv">Maldives</option>
<option class="" value="ml">Mali</option>
<option class="" value="mt">Malta</option>

<option class="" value="mh">Marshall Islands</option>
<option class="" value="mq">Martinique</option>
<option class="" value="mr">Mauritania</option>
<option class="" value="mu">Mauritius</option>
<option class="" value="yt">Mayotte</option>
<option class="" value="mx">Mexico</option>
<option class="" value="fm">Micronesia</option>
<option class="" value="md">Moldova</option>
<option class="" value="mc">Monaco</option>

<option class="" value="mn">Mongolia</option>
<option class="" value="ms">Montserrat</option>
<option class="" value="ma">Morocco</option>
<option class="" value="mz">Mozambique</option>
<option class="" value="mm">Myanmar</option>
<option class="" value="na">Namibia</option>
<option class="" value="nr">Nauru</option>
<option class="" value="np">Nepal</option>
<option class="" value="nl">Netherlands</option>

<option class="" value="an">Netherlands Antilles</option>
<option class="" value="nt">Neutral Zone</option>
<option class="" value="nc">New Caledonia</option>
<option class="" value="nz">New Zealand</option>
<option class="" value="ni">Nicaragua</option>
<option class="" value="ne">Niger</option>
<option class="" value="ng">Nigeria</option>
<option class="" value="nu">Niue</option>
<option class="" value="nf">Norfolk Island</option>

<option class="" value="mp">Northern Mariana Isl.</option>
<option class="" value="no">Norway</option>
<option class="" value="om">Oman</option>
<option class="" value="pk">Pakistan</option>
<option class="" value="pw">Palau</option>
<option class="" value="pa">Panama</option>
<option class="" value="pg">Papua New Guinea</option>
<option class="" value="py">Paraguay</option>
<option class="" value="pe">Peru</option>

<option class="" value="ph">Philippines</option>
<option class="" value="pn">Pitcairn</option>
<option class="" value="pl">Poland</option>
<option class="" value="pt">Portugal</option>
<option class="" value="pr">Puerto Rico</option>
<option class="" value="qa">Qatar</option>
<option class="" value="re">Reunion</option>
<option class="" value="ro">Romania</option>
<option class="" value="ru">Russian Federation</option>

<option class="" value="rw">Rwanda</option>
<option class="" value="gs">S. Georgia</option>
<option class="" value="kn">Saint Kitts and Nevis</option>
<option class="" value="lc">Saint Lucia</option>
<option class="" value="ws">Samoa</option>
<option class="" value="sm">San Marino</option>
<option class="" value="st">Sao Tome, Principe</option>
<option class="" value="sa">Saudi Arabia</option>
<option class="" value="sn">Senegal</option>

<option class="" value="sc">Seychelles</option>
<option class="" value="sl">Sierra Leone</option>
<option class="" value="sg">Singapore</option>
<option class="" value="sk">Slovak Republic</option>
<option class="" value="si">Slovenia</option>
<option class="" value="sb">Solomon Islands</option>
<option class="" value="so">Somalia</option>
<option class="" value="za">South Africa</option>
<option class="" value="es">Spain</option>

<option class="" value="lk">Sri Lanka</option>
<option class="" value="vc">St Vincent, Grenadines</option>
<option class="" value="sh">St. Helena</option>
<option class="" value="pm">St. Pierre</option>
<option class="" value="sd">Sudan</option>
<option class="" value="sr">Suriname</option>
<option class="" value="sj">Svalbard</option>
<option class="" value="sz">Swaziland</option>
<option class="" value="se">Sweden</option>

<option class="" value="ch">Switzerland</option>
<option class="" value="sy">Syria</option>
<option class="" value="tw">Taiwan</option>
<option class="" value="tj">Tajikistan</option>
<option class="" value="tz">Tanzania</option>
<option class="" value="th">Thailand</option>
<option class="" value="tg">Togo</option>
<option class="" value="tk">Tokelau</option>
<option class="" value="to">Tonga</option>

<option class="" value="tt">Trinidad, Tobago</option>
<option class="" value="tn">Tunisia</option>
<option class="" value="tr">Turkey</option>
<option class="" value="tm">Turkmenistan</option>
<option class="" value="tc">Turks, Caicos Isl.</option>
<option class="" value="tv">Tuvalu</option>
<option class="" value="um">US Minor Outlying Isl.</option>
<option class="" value="su">USSR (former)</option>
<option class="" value="ug">Uganda</option>

<option class="" value="ua">Ukraine</option>
<option class="" value="ae">United Arab Emirates</option>
<option class="" value="uk">United Kingdom</option>
<option class="" value="us" selected="selected">United States</option>
<option class="" value="uy">Uruguay</option>
<option class="" value="uz">Uzbekistan</option>
<option class="" value="vu">Vanuatu</option>
<option class="" value="va">Vatican City State</option>
<option class="" value="ve">Venezuela</option>

<option class="" value="vn">Viet Nam</option>
<option class="" value="vg">Virgin Islands (British)</option>
<option class="" value="vi">Virgin Islands (U.S.)</option>
<option class="" value="wf">Wallis, Futuna Isl.</option>
<option class="" value="eh">Western Sahara</option>
<option class="" value="ye">Yemen</option>
<option class="" value="yu">Yugoslavia</option>
<option class="" value="zr">Zaire</option>
<option class="" value="zm">Zambia</option>

<option class="" value="zw">Zimbabwe</option>
