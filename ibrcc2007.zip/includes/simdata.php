<?
// You may want to store this more securely in a DB or Registry or a Encrypted File
$loginid = "uboc3231081";
$x_tran_key = "43U4f5LKXn4wx88u";
?>
