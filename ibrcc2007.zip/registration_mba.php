<?php
$db = mysql_connect("localhost", "infantbo", "big506");
mysql_select_db("ibrcc_abstract");

require("includes/header.php");
	
// for authorize.net transaction
include ("includes/simdata.php");
include ("includes/simlib.php");

srand(time());
$sequence = rand(1, 1000);
// Insert the form elements required for SIM by calling InsertFP
$amount = 24.95;
?>

<script type="text/javascript">
function submitForm() {

	if(document.getElementById("x_country").value == "us")
		document.getElementById("x_state").value = document.getElementById("x_state_us").value;
	else
		document.getElementById("x_state").value = document.getElementById("x_state_other").value;

	document.getElementById("x_exp_date").value = document.getElementById("cc_month").value + document.getElementById("cc_year").value;

	var required = ["name","x_email","x_first_name","x_last_name","x_card_num","cc_month","cc_year","x_address","x_city","x_zip","x_country","card_type"];

	var required_2 = [{name:"x_first_name, desc:"}];
	
	err_msg = "";
	
	for(i=0; i<required.length; i++) {
		if(document.getElementById(required[i]).value == "") {
			err_msg = "Please fill in all the required fields that are marked in red.";
			document.getElementById("l_"+required[i]).className = "error";
		}
		else {
			document.getElementById("l_"+required[i]).className = "";
		}
	}

	if(err_msg != "") {
		document.getElementById("error").innerHTML = err_msg;
		window.scrollTo(0,0);
		return;
	}

	document.mainform.submit();
}
</script>

<div class="main">
	<div class="header">Monterey Bay Aquarium Tour Registration</div>

<br /><br />
The Monterey Bay Aquarium tour bus is full.

<br /><br />
Contact Haydee Dabritz after arrival at IBRCC if you are still interested in going.
<br /><br />

<!---

<form method="POST" name="mainform" action="https://secure.authorize.net/gateway/transact.dll">
<? $ret = InsertFP ($loginid, $x_tran_key, $amount, $sequence);  ?>
<input type="hidden" name="is_mba" value="1">
<input type="hidden" name="x_email_customer" value="TRUE">
<input type="hidden" name="x_email_customer" value="TRUE">
<input type="hidden" name="x_merchant_email" value="ydrummon@dhs.ca.gov">
<input type="hidden" name="x_method" value="CC">


<table cellpadding="0" cellspacing="0" border="0">
<tr><td style="vertical-align: top; font-size: 14px;">
	<div class="header_small">
		October 16, 1pm - 5:30pm<br />
		Monterey Bay Aquarium
	</div><br />
<div style="letter-spacing: 0.5px;">
	IBRCC will be organizing a trip to Monterey Bay Aquarium on October 16. We will leave Asilomar at 1:30pm and return around 5-5:30pm on the same day.
<br /><br />
The cost is $24.95, which includes bus transportation to and back from Monterey Bay Aquarium.
<br /><br />
<hr />
<br />
<div style="margin-left: 20px; margin-right: 20px; font-style: oblique;">
Imagine standing on the bottom of the ocean and looking up into a glittering kelp forest alive with darting fish, or watching five-foot-long sharks and giant tuna whiz by at arm's length, or being surrounded by elegant, lacy white jellyfish as they soar, pulsing, through the water. Visitors to the Monterey Bay Aquarium on the coast of Northern California experience all this... and more.
<br /><br />
For more than 20 years, the Monterey Bay Aquarium has entertained, educated, and fascinated its nearly 2 million annual visitors with pioneering displays of realistic undersea environments. Now NATURE gives viewers a behind-the-scenes look at one of the world's leading centers for marine research and conservation -- a marvel of engineering and biology that, literally, captures OCEANS IN GLASS.
<div style="text-align: right;">
	<br />
	- from feature program "OCEANS IN GLASS" at pbs.org [<a href="https://www.pbs.org/wnet/nature/oceansinglass/index.html">link</a>]
</div>
</div>
</div>
</td>
<td>
<div id="error" class="error"></div>

<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td colspan="2"><div class="header_small">Contact Info</div></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_name">Name</label></td>
		<td><input name="name" id="name" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_x_email">E-Mail</label></td>
		<td><input name="x_email" id="x_email" size="30" /></td>
	</tr>
	<tr>
		<td colspan="2"><div class="header_small">Credit Card Info</div></td>
	</tr>
	<tr
		<td colspan="2" style="text-align: center;">
<img alt="Merchant Account" title="Merchant Account" src="http://www.credit-card-logos.com/images/visa_credit-card-logos/visa_mastercard_2.gif" width="116" height="35" border="0" />
		</td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_card_type">Card Type</label></td>
		<td><select name="card_type" id="card_type">
			<option value="">-Select One</option>
			<option value="Visa">Visa</option>
			<option value="Mastercard">Mastercard</option>
		</select>
		</td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_first_name">First Name</label></td>
		<td><input name="x_first_name" id="x_first_name" size="15" maxlength="50" /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_last_name">Last Name</label></td>
		<td><input name="x_last_name" id="x_last_name" size="15" maxlength="50" /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_card_num">Card Number</label></td>
		<td><input name="x_card_num" id="x_card_num" size="22" maxlength="22" /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_cc_month"><label id="l_cc_year">Expiration Date</label></label></td>
		<td><input type="hidden" name="x_exp_date" id="x_exp_date" />
<script type="text/javascript">
	function ucc() {
		document.getElementById("x_exp_date").value = document.getElementById("cc_month").value + document.getElementById("cc_year").value;
	}
</script>
	
	<select id="cc_month" name="cc_month" onchange="ucc()">
    <option value="01">01</option>
    <option value="02">02</option>

    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>

    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
  </select>/
 <select id="cc_year" name="cc_year" onchange="ucc()">
<option value="2007">2007</option>
<option value="2008">2008</option>
<option value="2009">2009</option>
<option value="2010">2010</option>
<option value="2011">2011</option>
<option value="2012">2012</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
</select>
		</td>
	</tr>

	<tr>
		<td colspan="2"><div class="header_small">Billing Address</div></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_address">Address</label></td>
		<td><input name="x_address" id="x_address" size="30" maxlength="60" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_x_city">City</label></td>
		<td><input name="x_city" id="x_city" size="30" maxlength="40" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_x_state">State/Province</label></td>
		<td><input id="x_state" name="x_state" type="hidden" />
			<div id="x_state_us_div"><select name="x_state_us" id="x_state_us">
<?php include("includes/state_form.php"); ?>
</select></div>
			<div  style="display: none;" id="x_state_other_div"><input name="x_state_other" id="x_state_other" size="30" maxlength="40"></div>
		</td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_x_zip">ZIP / Postal Code</label></td>
		<td><input name="x_zip" id="x_zip" size="10" maxlength="20" /></td>
	</tr>

<script type="text/javascript">
function x_country_change() {
	if(document.getElementById("x_country").value == "us") {
		document.getElementById("x_state_us_div").style.display = "none";
		document.getElementById("x_state_other_div").style.display = "";
	}
	else {
		document.getElementById("x_state_us_div").style.display = "none";
		document.getElementById("x_state_other_div").style.display = "";
	}
}
</script>

	<tr>
		<td class="formtitle"><label id="l_x_country">Country</label></td>
		<td><select name="x_country" id="x_country" onchange="x_country_change()">
<?php include("includes/country_form.php"); ?>
</select></td>
	</tr>

	<tr>
		<td colspan="2">
			<div style="width: 230px; margin-left: auto; margin-right: auto; font-size: 13px; color: #333333;">* Please enter the same address as what's on file on your credit card.</div>
		</td>
	</tr>

	<tr>
		<td colspan="2" style="text-align: center;">
			<hr />
			<input type="button" value="Prepare and Submit" onclick="submitForm()" />
		</td>
	</tr>
</table>
</td>
</tr>
</table>

<input type="hidden" name="commit" value="1" />
<input type="hidden" name="x_login" value="<?=$loginid?>" />
<input type="hidden" name="x_amount" value="24.95" />
<INPUT TYPE=HIDDEN NAME="x_relay_response" VALUE="True">
<INPUT TYPE=HIDDEN NAME="x_relay_url" VALUE="http://www.ibrcc2007.org/registration_result.php">
<INPUT TYPE=HIDDEN NAME="x_description" VALUE="IBRCC 2007 Monterey Bay Aquarium Tour">
<input type="hidden" name="x_header_html_payment_form" value="<img src='http://ibrcc2007.org/images/logo3.png' />" />
<input type="hidden" name="x_footer_html_payment_form" value="<div style='font-family: arial; width: 100%;background-color: #333;color: #fff;text-align: center;padding: 8px 0px 8px 0px;font-size: 13px;clear:both;'>Copyright &copy; 2007 Infant Botulism Treatment and Prevention Program, All rights reserved.</div>" />
<input type="hidden" name="x_header_html_receipt" value="<img src='http://ibrcc2007.org/images/logo3.png' />" />
<input type="hidden" name="x_footer_html_receipt" value="<div style='font-family: arial; width: 100%;background-color: #333;color: #fff;text-align: center;padding: 8px 0px 8px 0px;font-size: 13px;clear:both;'>Copyright &copy; 2007 Infant Botulism Treatment and Prevention Program, All rights reserved.</div>" />
</form>

--->

</div>
	
<?php require("includes/footer.php"); ?>