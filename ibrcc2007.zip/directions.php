<?php require("includes/header.php"); ?>

<div class="main">

	<div id="c1" class="column" style="float: left; width: 65%;">

	<div class="header">Directions From The San Francisco Bay Area or San Jose</div>

Asilomar is approximately 120 miles south of downtown San Francisco (about 105 miles from San Francisco International Airport) and about 75 miles south of San Jose. Take 101 south to 156 West. Take 156 West to highway 1 South, through Monterey to the Pebble Beach / Pacific Grove exit, turn right on Holman highway / 68 West. Stay on Highway 68 West/Holman Highway for 3.5 miles until it becomes a city street called Forest Avenue. Continue on Forest Avenue for about 1 mile and make a left turn onto Sinex Avenue. In just under 1 mile, Sinex Avenue ends right at the front gates to Asilomar.

<br /><br />
 
	<div class="header">From Los Angeles, Santa Barbara, or San Luis Obispo</div>

Asilomar is approximately 325 miles from downtown Los Angeles (about 310 miles from LAX). Take 101 North though Salinas to 156 West. Take 156 West to highway 1 South, through Monterey to the Pebble Beach / Pacific Grove exit, and highway 68 West. For about 3-1/2 miles you will then be on a portion of Highway 68 West that is also called the Holman Highway. Stay on Highway 68 West/Holman Highway until it becomes a city street called Forest Avenue. Continue on Forest Avenue for about 1 mile and make a left turn onto Sinex Avenue. In just under 1 mile, Sinex Avenue ends right at the front gates to Asilomar.

<br /><br />

	<div class="header">Airport Transportation </div>

Local taxi companies service the Monterey Peninsula Airport, as does the Monterey-Salinas Transit bus system (see Public Transportation). Airport shuttle service to and from San Jose and San Francisco airports can be arranged in advance through Monterey Salinas Airbus, by calling 831-373-7777, or via their website at http://www.montereyairbus.com/ .

	</div>
	<div id="c2" class="column" style="float: left; width: 33%;">
		<div class="box1">
			<div class="header" style="color: #fff; padding:0px 0px 0px 0px;">
				For more details on getting to Asilomar, visit <a style="color: #fff;" href="http://www.visitasilomar.com/maps.aspx" target="_blank">Asilomar Map & Transportation</a> site.
			</div>
		</div>
</div> 
</div>

<?php require("includes/footer.php"); ?>
