<?php
header("Content-disposition: attachment; filename=registrations.csv");
header("Content-type: text/csv");
header("Content-Location: registration.csv");
$db = mysql_connect("localhost", "ibrcc", "big506");
mysql_select_db("ibrcc");

$sql = "SELECT * FROM registrations ORDER BY c_stamp DESC;";

	$result = mysql_query($sql);
	if(!$result) {
		echo $sql . "<br />".mysql_error();
	}
	else {
		echo "ID,Title,Name,Badge Name,First Name,Last Name,Institution,Department,Degree,Address,City,State,ZIP,Country,Business Phone,Cell Phone,FAX, Email,Submit Abstract?,Presentation Type,Transaction ID,Authentication Code,Registration Time\n";
		while($row = mysql_fetch_row($result)) {
			
			if(strpos($row[2], " ") !== false) {
				$first = strtok( $row[2], " ");
				array_splice($row, 4, 0, $first);
				$second = strtok(" ");
				if($second !== false) {
					$third = strtok(" ");
					if($third !== false) {
						array_splice($row, 5, 0, $third);
					}
					else {
						array_splice($row, 5, 0, $second);
					}
				}
			}
			else {
				$first = strtok( $row[3], " ");
				array_splice($row, 4, 0, $first);
				$second = strtok(" ");
				if($second !== false) {
					$third = strtok(" ");
					if($third !== false) {
						array_splice($row, 5, 0, $third);
					}
					else {
						array_splice($row, 5, 0, $second);
					}
				}
			}
			echo "\"".implode("\",\"", $row)."\"\n";
		}
	}
?>
