<?php require("includes/header.php"); ?>
<?php
$db = mysql_connect("localhost", "ibrcc", "big506");
mysql_select_db("ibrcc");
?>

<div class="main">
	<div class="header">Monterey Bay Aquarium Tour Signups</div>
	[<a href="mbatour_csv.php">Download Excel Format</a>]
<hr />

<?php
	$sql = "SELECT * FROM mba ORDER BY c_stamp DESC;";
	
	$result = mysql_query($sql);
	if(!$result) {
		echo $sql . "<br />".mysql_error();
	}
	else {
		$row_count = mysql_num_rows($result);
		echo <<<EOT
		<div style="font-weight: bold; color: #369; font-size: 12px;">Listing {$row_count} registrants</div>
		<table name="maintable" id="maintable" cellpadding="2" cellspacing="0" border="0">
		<tr>
			<td class="header">Name</td>
			<td class="header">Signed Up Time</td>
		</tr>
EOT;
		while($row = mysql_fetch_array($result)) {
			echo <<<EOT
		<tr>
			<td>{$row["name"]}</td>
			<td>{$row["c_stamp"]}</td>
		</tr>
EOT;
		}
		echo "</table>\n";
	}
?>

</div>

<script type="text/javascript" src="includes/sortTable.js"></script>
<script type="text/javascript">
initTable("maintable");
</script>

<?php require("includes/footer.php");