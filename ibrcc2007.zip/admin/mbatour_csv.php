<?php
header("Content-disposition: attachment; filename=registrations.csv");
header("Content-type: text/csv");
header("Content-Location: registration.csv");
$db = mysql_connect("localhost", "ibrcc", "big506");
mysql_select_db("ibrcc");

$sql = "SELECT * FROM mba ORDER BY c_stamp DESC;";

	$result = mysql_query($sql);
	if(!$result) {
		echo $sql . "<br />".mysql_error();
	}
	else {
		echo "ID,Name,Email,First Name,LastName,Transaction ID,Authentication Code,Registration Time\n";
		while($row = mysql_fetch_row($result)) {
			
			if(strpos($row[1], " ") !== false) {
				$first = strtok( $row[1], " ");
				array_splice($row, 3, 0, $first);
				$second = strtok(" ");
				if($second !== false) {
					$third = strtok(" ");
					if($third !== false) {
						array_splice($row, 4, 0, $third);
					}
					else {
						array_splice($row, 4, 0, $second);
					}
				}
			}
			echo "\"".implode("\",\"", $row)."\"\n";
		}
	}
?>
