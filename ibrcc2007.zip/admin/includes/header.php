<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>IBRCC 2007</title>
<link rel="stylesheet" type="text/css" href="includes/main.css" />
</head>
<body style="margin: 0px;">

<div style="background-image:url('../images/topbg3.png'); height: 48px;">
	<img src="../images/logo3.png" style="height: 48px;" />
	<a class="whitelink" href="abstracts.php">Abstracts</a>&nbsp;&nbsp;&nbsp;
	<a class="whitelink" href="registrations.php">Registrations</a>&nbsp;&nbsp;&nbsp;
	<a class="whitelink" href="mbatour.php">MBA Tour</a>
</div>