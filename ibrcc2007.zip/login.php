<?php
session_start();
if(isset($_POST["submit"]) && $_POST["submit"] == "1") {
	$_SESSION["username"] = $_POST["username"];
	$_SESSION["password"] = $_POST["password"];
	if(isset($_REQUEST["lp"]) && $_REQUEST["lp"] != "")
		header("location: " . $_REQUEST["lp"]);
	else
		header("location: index.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>IBRCC 2007</title>
<link rel="stylesheet" type="text/css" href="includes/main.css" />
</head>
<body>


<div style="width: 100%; background-image: url('images/topbg3.png'); background-repeat: repeat-x; height: 144px; text-align: center;">
	<img src="images/logo3.png" style="height: 48px;" />
</div>

<div class="main" style="text-align: center; margin-left: auto; margin-right: auto;">
	
<form method="POST">
	<input type="hidden" name="submit" value="1" />
	<table cellpadding="0" cellspacing="0" border="0" style="margin-left: auto; margin-right: auto;">
		<tr>
			<td>Username:</td>
			<td><input name="username" size="15" /></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input name="password" size="15" type="password" /></td>
		</tr>
		<tr>
			<td colspan="2"><input value="Submit" type="submit"</td>
		</tr>
	</table>
</form>

</div>

<div class="footer"></div>

</body>

</html>