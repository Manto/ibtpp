<?php
$db = mysql_connect("localhost", "infantbo", "big506");
mysql_select_db("ibrcc_abstract");

require("includes/header.php");
	
// for authorize.net transaction
include ("includes/simdata.php");
include ("includes/simlib.php");

srand(time());
$sequence = rand(1, 1000);
// Insert the form elements required for SIM by calling InsertFP
$amount = 150;
?>

<script type="text/javascript">
function submitForm() {

	document.getElementById("address").value = document.getElementById("address1").value + document.getElementById("address2").value;

	if(document.getElementById("country").value == "us")
		document.getElementById("state").value = document.getElementById("state_us").value;
	else
		document.getElementById("state").value = document.getElementById("state_other").value;

	if(document.getElementById("x_country").value == "us")
		document.getElementById("x_state").value = document.getElementById("x_state_us").value;
	else
		document.getElementById("x_state").value = document.getElementById("x_state_other").value;

	document.getElementById("x_exp_date").value = document.getElementById("cc_month").value + document.getElementById("cc_year").value;

	//var required = ["name","institution","address","city","state","zip","email","submitabstract"];

	var required = ["badgename","name","institution","address1","city","zip","x_email","submitabstract","x_first_name","x_last_name","x_card_num","cc_month",
									"cc_year","x_address","x_city","x_zip","x_country","card_type"];

	if(document.getElementById("submitabstract").value == "Yes")
		required.push("presentation");

	var required_2 = [{name:"badgename",desc:"Name on Badge"},{name:"institution", desc:"Institution"},{name:"address", desc:"Mailing Address"},{name:"city", desc:"Mailing City"},
									{name:"state", desc:"Mailing State"},{name:"zip",desc:"Mailing Postal Code"},{name:"email",desc:"Email"},{name:"submitabstract",desc:"Submitting Abstract"},
									{name:"x_first_name, desc:"}];
	
	err_msg = "";
	
	for(i=0; i<required.length; i++) {
		if(document.getElementById(required[i]).value == "") {
			err_msg = "Please fill in all the required fields that are marked in red.";
			document.getElementById("l_"+required[i]).className = "error";
		}
		else {
			document.getElementById("l_"+required[i]).className = "";
		}
	}

	if(err_msg != "") {
		document.getElementById("error").innerHTML = err_msg;
		window.scrollTo(0,0);
		return;
	}

	document.mainform.submit();
}
</script>

<div class="main">
	<div class="header">Registration</div>

<div id="error" class="error"></div>

<form method="POST" name="mainform" action="https://secure.authorize.net/gateway/transact.dll">
<? $ret = InsertFP ($loginid, $x_tran_key, $amount, $sequence);  ?>
<input type="hidden" name="x_email_customer" value="TRUE">
<input type="hidden" name="x_merchant_email" value="ydrummon@dhs.ca.gov">
<input type="hidden" name="x_method" value="CC">

<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td style="vertical-align: top;"><!--- left half of form -->
<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td colspan="2"><div class="header_small">Badge Info</div></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_badgename">Name on Badge</label></td>
		<td><input name="badgename" id="badgename" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_institution">Institution</label></td>
		<td><input name="institution" id="institution" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_department">Department</label></td>
		<td><input name="department" id="department" size="30" /></td>
	</tr>

	<tr>
		<td colspan="2"><div class="header_small">Contact Info</div></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_title">Title</label></td>
		<td><input name="title" id="title" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_name">Name</label></td>
		<td><input name="name" id="name" size="30" /></td>
	</tr>
	<tr>

		<td class="formtitle"><label>Degree</label></td>
		<td>
			<input type="checkbox" value="1" name="degree_PhD" id="degree_PhD">PhD
			<input type="checkbox" value="1" name="degree_MPH" id="degree_MPH">MPH
			<input type="checkbox" value="1" name="degree_MS" id="degree_MS">MS<br />
			<input type="checkbox" value="1" name="degree_MD" id="degree_MD">MD
			<input type="checkbox" value="1" name="degree_DVM" id="degree_DVM">DVM
			<input type="checkbox" value="1" name="degree_Other" id="degree_Other">Other
		</td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_address1">Mailing Address 1</label></td>
		<td><input type="hidden" name="address" id="address" /><input name="address1" id="address1" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_address2">Mailing Address 2</label></td>
		<td><input name="address2" id="address2" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_city">City</label></td>
		<td><input name="city" id="city" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_state">State/Province</label></td>
		<td><input name="state" id="state" type="hidden" />
			<div id="state_us_div"><select name="state_us" id="state_us">
<?php include("includes/state_form.php"); ?>
</select></div>
			<div style="display: none;" id="state_other_div"><input name="state_other" id="state_other" size="30" maxlength="40"></div>
		</td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_zip">ZIP / Postal Code</label></td>
		<td><input name="zip" id="zip" size="30" /></td>
	</tr>

<script type="text/javascript">
function country_change() {
	if(document.getElementById("country").value == "us") {
		document.getElementById("state_us_div").style.display = "";
		document.getElementById("state_other_div").style.display = "none";
	}
	else {
		document.getElementById("state_us_div").style.display = "none";
		document.getElementById("state_other_div").style.display = "";
	}
}
</script>

	<tr>
		<td class="formtitle"><label id="l_country">Country</label></td>
		<td><select name="country" id="country" onchange="country_change()">
<?php include("includes/country_form.php"); ?>
</select></td>
	</tr>

	<tr>
		<td colspan="2"><hr /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_businessphone">Business Phone</label></td>
		<td><input name="businessphone" id="businessphone" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_cellphone">Cell Phone</label></td>
		<td><input name="cellphone" id="cellphone" size="30" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_fax">FAX</label></td>
		<td><input name="fax" id="fax" size="30" /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_email">E-Mail</label></td>
		<td><input name="x_email" id="x_email" size="30" /></td>
	</tr>
	<script type="text/javascript">
		function sa() {
			if(document.getElementById("submitabstract").value == "Yes") {
				document.getElementById("pp").style.display = "";
			}
			else {
				document.getElementById("pp").style.display = "none";
			}
		}
		</script>
	<tr>
		<td class="formtitle"><label id="l_submitabstract">Submitting Abstract?</label></td>
		<td><select name="submitabstract" id="submitabstract" onchange="sa()">
			<option value="">-Select One</option>
			<option value="Yes">Yes</option>
			<option value="No">No</option>
		</select>
	</td>
	</tr>
	<tr id="pp" style="display: none;">
		<td class="formtitle"><label id="l_presentation">Presentation Preference</label></td>
		<td><select name="presentation" id="presentation">
			<option value="">-Select One</option>
			<option value="Poster">Poster</option>
			<option value="Platform">Platform</option>
			<option value="Either">Either</option>
		</select>
	</td>
	</tr>
</table>
	</td>

	<td style="vertical-align: top;"><!-- right half of form -->

<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td colspan="2"><div class="header_small">Credit Card Info</div></td>
	</tr>
	<tr
		<td colspan="2" style="text-align: center;">
<img alt="Merchant Account" title="Merchant Account" src="http://www.credit-card-logos.com/images/visa_credit-card-logos/visa_mastercard_2.gif" width="116" height="35" border="0" />
		</td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_card_type">Card Type</label></td>
		<td><select name="card_type" id="card_type">
			<option value="">-Select One</option>
			<option value="Visa">Visa</option>
			<option value="Mastercard">Mastercard</option>
		</select>
		</td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_first_name">First Name</label></td>
		<td><input name="x_first_name" id="x_first_name" size="15" maxlength="50" /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_last_name">Last Name</label></td>
		<td><input name="x_last_name" id="x_last_name" size="15" maxlength="50" /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_card_num">Card Number</label></td>
		<td><input name="x_card_num" id="x_card_num" size="22" maxlength="22" /></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_cc_month"><label id="l_cc_year">Expiration Date</label></label></td>
		<td><input type="hidden" name="x_exp_date" id="x_exp_date" />
<script type="text/javascript">
	function ucc() {
		document.getElementById("x_exp_date").value = document.getElementById("cc_month").value + document.getElementById("cc_year").value;
	}
</script>
	
	<select id="cc_month" name="cc_month" onchange="ucc()">
    <option value="01">01</option>
    <option value="02">02</option>

    <option value="03">03</option>
    <option value="04">04</option>
    <option value="05">05</option>
    <option value="06">06</option>
    <option value="07">07</option>
    <option value="08">08</option>

    <option value="09">09</option>
    <option value="10">10</option>
    <option value="11">11</option>
    <option value="12">12</option>
  </select>/
 <select id="cc_year" name="cc_year" onchange="ucc()">
<option value="2007">2007</option>
<option value="2008">2008</option>
<option value="2009">2009</option>
<option value="2010">2010</option>
<option value="2011">2011</option>
<option value="2012">2012</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
</select>
		</td>
	</tr>

	<tr>
		<td colspan="2"><div class="header_small">Billing Address</div></td>
	</tr>

	<tr>
		<td class="formtitle"><label id="l_x_address">Address</label></td>
		<td><input name="x_address" id="x_address" size="30" maxlength="60" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_x_city">City</label></td>
		<td><input name="x_city" id="x_city" size="30" maxlength="40" /></td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_x_state">State/Province</label></td>
		<td><input id="x_state" name="x_state" type="hidden" />
			<div id="x_state_us_div"><select name="x_state_us" id="x_state_us">
<?php include("includes/state_form.php"); ?>
</select></div>
			<div  style="display: none;" id="x_state_other_div"><input name="x_state_other" id="x_state_other" size="30" maxlength="40"></div>
		</td>
	</tr>
	<tr>
		<td class="formtitle"><label id="l_x_zip">ZIP / Postal Code</label></td>
		<td><input name="x_zip" id="x_zip" size="10" maxlength="20" /></td>
	</tr>

<script type="text/javascript">
function x_country_change() {
	if(document.getElementById("x_country").value == "us") {
		document.getElementById("x_state_us_div").style.display = "none";
		document.getElementById("x_state_other_div").style.display = "";
	}
	else {
		document.getElementById("x_state_us_div").style.display = "none";
		document.getElementById("x_state_other_div").style.display = "";
	}
}
</script>

	<tr>
		<td class="formtitle"><label id="l_x_country">Country</label></td>
		<td><select name="x_country" id="x_country" onchange="x_country_change()">
<?php include("includes/country_form.php"); ?>
</select></td>
	</tr>

	<tr>
		<td colspan="2">
			<div style="width: 230px; margin-left: auto; margin-right: auto; font-size: 13px; color: #333333;">* Please enter the same address as what's on file on your credit card.</div>
		</td>
	</tr>

</table>

	</td>
	</tr>
	<tr>
		<td colspan="2" style="text-align: center;">
			<hr />
			<input type="button" value="Prepare and Submit" onclick="submitForm()" />
		</td>
	</tr>
</table>
<input type="hidden" name="commit" value="1" />
<input type="hidden" name="x_login" value="<?=$loginid?>" />
<input type="hidden" name="x_amount" value="150" />
<INPUT TYPE=HIDDEN NAME="x_relay_response" VALUE="True">
<INPUT TYPE=HIDDEN NAME="x_relay_url" VALUE="http://www.ibrcc2007.org/registration_result.php">
<INPUT TYPE=HIDDEN NAME="x_description" VALUE="IBRCC 2007 Conference Registration">
<input type="hidden" name="x_header_html_payment_form" value="<img src='http://ibrcc2007.org/images/logo3.png' />" />
<input type="hidden" name="x_footer_html_payment_form" value="<div style='font-family: arial; width: 100%;background-color: #333;color: #fff;text-align: center;padding: 8px 0px 8px 0px;font-size: 13px;clear:both;'>Copyright &copy; 2007 Infant Botulism Treatment and Prevention Program, All rights reserved.</div>" />
<input type="hidden" name="x_header_html_receipt" value="<img src='http://ibrcc2007.org/images/logo3.png' />" />
<input type="hidden" name="x_footer_html_receipt" value="<div style='font-family: arial; width: 100%;background-color: #333;color: #fff;text-align: center;padding: 8px 0px 8px 0px;font-size: 13px;clear:both;'>Copyright &copy; 2007 Infant Botulism Treatment and Prevention Program, All rights reserved.</div>" />
</form>
</div>
	
<?php require("includes/footer.php"); ?>