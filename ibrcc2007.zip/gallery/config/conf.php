<?php

	$host = 'localhost';
	$db = 'ibrccphoto';
	$user = 'ibrccphoto';
	$pass = 'big506';

	$pre = 'ssp_';

?>