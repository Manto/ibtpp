<?php

/* 	You can use this file to set specific variables outside the SlideShowPro Director core,
	so updates won't affect them. Warning: This is for advanced users only, those with a 
	proper understanding of PHP and its' syntax.
*/

/*
	SESSION SAVE PATH
	A common use of this file is to set a custom session save path, as required by your host.
	Uncomment out the line below and replace the path with your host's session
	save path.
*/

	// session_save_path('/path/from/your/host');
	
?>