<?php

class AlbumsController extends AppController {
    var $name = 'Albums';
	var $uses = array('Album', 'Image', 'Tag');
	var $helpers = array('Html', 'Javascript', 'Ajax', 'Director');
	var $components = array('Director');
	
	var $non_ajax_actions = array('edit', 'process', 'do_process', 'refresh_generate_pane', 'reorder', '_list', '_preview');
	
	// Only logged in users should see this controller's actions
 	function beforeFilter() {
		// Protect ajax actions
		if (!in_array($this->action, $this->non_ajax_actions)) {
			$this->verifyAjax();
		}
		// Check session
		$this->checkSession();
	}
	
	////
	// Create album
	////
	function create() {
		$this->data['Album']['created_on'] = date('Y-m-d H:i:s');
		if ($this->Album->save($this->data)) {
			// Make directories and set path
			$this->Album->id = $this->Album->getLastInsertId();
			$path = 'album-' . $this->Album->id;
			if ($this->Director->makeDir(ALBUMS . DS . $path) &&
				$this->Director->createAlbumDirs($path))
			{
				// Directories were created successfully, go ahead with new album and redirection
				$this->Album->saveField('path', $path);
				
				// Render redirect via JS
				$this->set('new_id', $this->Album->id);
				$this->render('after_create', 'ajax');
			} else {
				// Directory creation failed, we have a permission problem. Delete the album and notify user
				$this->Album->delete();
				$this->render('creation_failure', 'ajax');
			}
		}	
	}
	
	////
	// Album edit pane
	////
	function edit($id, $tab = 'info') {
		$this->pageTitle = 'Edit album';
		$this->Album->id = $id;
		$this->data = $this->Album->read();
		
		switch($tab) {
			case('generate'):
				$this->set("title_check", $this->Image->findAll("aid = $id AND title IS NOT NULL AND title <> ''"));
				$this->set("link_check", $this->Image->findAll("aid = $id AND link IS NOT NULL AND link <> ''"));
				$this->set("captions_check", $this->Image->findAll("aid = $id AND caption IS NOT NULL AND caption <> ''"));
				break;
				
			case('images'):
				$this->set('images', $this->data['Image']);
				break;
			
			case('audio'):
				$this->set('mp3s', $this->Director->directory(AUDIO, 'mp3'));
				break;
				
			case('upload'):
				$this->set('writable', $this->Director->setAlbumPerms($this->data['Album']['path']));
				$this->set('other_writable', $this->Director->setOtherPerms());
				// Check if any new files have been uploaded via FTP
				$files = $this->Director->directory(ALBUMS . DS . $this->data['Album']['path'] . DS . 'lg', 'accepted');
				if (count($files) > count($this->data['Image'])) {
					set_time_limit(0);
					$noobs = array();
					foreach($files as $file) {
						$img = $this->Image->find(aa('src', $file, 'aid', $id));
						if (empty($img)) {
							$new['Image']['aid'] = $id;
							$new['Image']['src'] = $file;
							$new['Image']['created_on'] = date('Y-m-d H:i:s');
							$this->Image->create();
							if ($this->Image->save($new)) {
								$noobs[] = $file;
								$this->Director->postProcess($this->data, $file);
							}
						}
					}
					$this->Album->reorder($id);
					$this->Album->cacheQueries = false;
					$this->data = $this->Album->read();
					$this->set('noobs', $noobs);
				}
				break;
		}
		
		$this->set('album', $this->data);
		$this->set('tab', $tab);
		$this->set('thumbs', !empty($this->data['Album']['thumb_specs']));
		$this->set('lg_specs', $this->Director->specsToArray($this->data['Album']['process_specs']));
		$this->set('tn_specs', $this->Director->specsToArray($this->data['Album']['thumb_specs'], true));
	}
	
	////
	// Update album
	////
	function update($id, $refer = '') {
		$this->Album->id = $id;
		if ($this->Album->save($this->data)) {
			switch($refer) {
				case('preview'):
					$this->_preview($id);
					exit();
					break;
			
				default:
					e($this->data['Album']['name'] . ' <small>(<strong>ID:</strong> ' . $id . ')</small>');
					exit();
					break;
			}
		}
	}
	
	////
	// Delete an album
	////
	function delete() {
		$album = $this->Album->find($this->data);
		$albums = $this->Album->findAll("path = '{$album['Album']['path']}'");
		
		// Delete the album from the DB
		if ($this->Album->del($album['Album']['id'], true)) {
			if (!empty($album['Album']['path'])) {
				// Remove the directory only if no other albums use it
				if (count($albums) == 1) {
					$dir = ALBUMS . DS . $album['Album']['path'];
					$this->Director->rmdirr($dir);
				}
				// Remove the custom thumb if there was one
				$custom_thumb = $this->Director->regExpSearch("/^album-{$album['Album']['id']}\.*+/", THUMBS);
				if ($custom_thumb) {
					@unlink(THUMBS . DS . $custom_thumb);
				}
			}
			$this->_list();
		}
	}
	
	////
	// Toggles albums active and inactive
	////
	function toggle($id) {
		$this->Album->id = $id;
		$this->data['Album']['active'] = $this->params['form']['value'];
		if ($this->Album->save($this->data)) {
			$this->_list();
		}
		// Destroy any gallery links if this is being deactivated
		if (!$this->params['form']['value']) {
			$tag_table = $this->Tag->tablePrefix . $this->Tag->table;
			$this->Tag->query("DELETE FROM $tag_table WHERE aid = $id");
		}
	}

	////
	// Updates album order
	////
	function order() {
		$order = $this->params['form']['active-albums'];
		while (list($key, $val) = each($order)) {
			$key++;
			$this->Album->id = $val;
			$this->data['Album']['displayOrder'] = $key;
			$this->Album->save($this->data);
		}
	}
	
	////
	// Process large images/thumbs
	////
	function process($type) {
		if ($type == 'thumbs') {
			$index_str = 'thumb_specs'; 
		} else {
			$index_str = 'process_specs';
		}
		
		$this->Album->id = $this->params['form']['id'];
		$album = $this->Album->read();
	
		// No album, possibly a page refresh or hack
		if (empty($album)) {
			exit();
		}
		
		$album_dir = ALBUMS . DS . $album['Album']['path'] . DS;
		
		if (!$this->Director->setAlbumPerms($album['Album']['path'])) {
			$this->set('path', 'albums' . DS . $album['Album']['path']);
			$this->render('process_failure', 'ajax');
			exit;
		} elseif (empty($album['Image'])) {
			$this->render('process_failure_empty', 'ajax');
			exit;
		}
		
		$this->Album->saveField($index_str, $this->Director->assembleSpecs($this->params['form']));
		
		if ($type == 'thumbs') {
			$this->Album->saveField('tn', 1);
		}
		
		$album_dir = ALBUMS . DS . $album['Album']['path'] . DS;
		$process_info = array(
							'hr_dir' 	=> $album_dir . 'hr',
							'lg_dir' 	=> $album_dir . 'lg',
							'tn_dir' 	=> $album_dir . 'tn',
							'width' 	=> $this->params['form']['width'],
							'height' 	=> $this->params['form']['height'],
							'quality' 	=> $this->params['form']['quality'],
							'square' 	=> $this->params['form']['group_sq'],
							'count'		=> count($album['Image']),
							'album_id'	=> $album['Album']['id']
						);
		$this->Session->write('Images', $album['Image']);
		$this->Session->write('Process', $process_info);
		$this->Session->write('Progress', 0);
		$this->redirect('/albums/do_process/' . $type);
	}
	
	////
	// Perform processing on an image to image basis
	////
	function do_process($type) {
		// Make sure this action has the proper data, die if it doesn't
		if ($this->Session->check('Process') && $this->Session->check('Images') && $this->Session->check('Progress')) {		
			$specs = $this->Session->read('Process');
			$images = $this->Session->read('Images');
			$progress = $this->Session->read('Progress');
		
			$this->Session->delete('Images');
			$this->Session->delete('Progress');
		
			$image = array_pop($images);
		
			if ($type == 'thumbs') {
				$destination = $specs['tn_dir'] . DS . $image['src'];
			} else {
				$destination = $specs['lg_dir'] . DS . $image['src'];
			}
		
			if (file_exists($specs['hr_dir'] . DS . $image['src'])) {
				$source = $specs['hr_dir'] . DS . $image['src'];
			} else {
				if ($type == 'large') {
					rename($specs['lg_dir'] . DS . $image['src'], $specs['hr_dir'] . DS . $image['src']);
					$source = $specs['hr_dir'] . DS . $image['src'];
				} else {
					$source = $specs['lg_dir'] . DS . $image['src'];
				}
			}
		
			$this->Director->createThumb($source, $destination, $specs['width'], $specs['height'], $specs['quality'], $specs['square']);
			$progress++;
			$this->set('percent', ($progress/$specs['count'])*100);
			$this->set('album_id', $specs['album_id']);
			$this->set('sq', $specs['square']);
			$this->Session->write('Images', $images);
			$this->Session->write('Progress', $progress);
			$this->render('do_process', 'ajax');
		} else {
			exit();
		} 
	}
	
	////
	// Resize album preview
	////
	function preview() {
		$this->Album->id = $this->params['form']['id'];
		$specs = $this->params['form'];
		$album = $this->Album->read();
		$thumb = basename($album['Album']['aTn']);
		$album_dir = ALBUMS . DS . $album['Album']['path'] . DS;
		$ext = $this->Director->returnExt($thumb);
		$destination = THUMBS . DS . 'album-' . $this->Album->id . '.' . $ext;
		$for_db = 'album-thumbs/' . 'album-' . $this->Album->id . '.' . $ext; 
		
		if (file_exists($album_dir . 'hr' . DS . $thumb)) {
			$source = $album_dir . 'hr' . DS . $thumb;
		} else {
			$source = $album_dir . 'lg' . DS . $thumb;
		}
		
		$this->Director->createThumb($source, $destination, $specs['width'], $specs['height'], $specs['quality'], $specs['group_sq']);
		$this->data['Album']['aTn'] = $for_db;
		$this->Album->save($this->data);
		$this->_preview($this->Album->id);
	}
	
	////
	// Refresh left side of generate pane after image processing
	////
	function refresh_generate_pane($id) {
		$this->Album->id = $id;
		$this->data = $this->Album->read();
		$this->set('album', $this->data);
		$this->set('thumbs', !empty($this->data['Album']['thumb_specs']));
		$this->set('lg_specs', $this->Director->specsToArray($this->data['Album']['process_specs']));
		$this->set('tn_specs', $this->Director->specsToArray($this->data['Album']['thumb_specs'], true));
		$this->render('refresh_generate_pane', 'ajax');
	}
	
	////
	// Clear thumbs
	////
	function clear_thumbs() {
		$this->Album->id = $this->data['Album']['id'];
		$this->data['Album']['tn'] = 0;
		$this->data['Album']['thumb_specs'] = '';
		$this->Album->save($this->data);
		$album = $this->Album->read();
		$tn_path = ALBUMS . DS . $album['Album']['path'] . DS . 'tn';
		$this->Director->rmdirr($tn_path);
		$this->Director->makeDir($tn_path);
		$this->set('album', $album);
		$this->set('thumbs', !empty($album['Album']['thumb_specs']));
		$this->set('lg_specs', $this->Director->specsToArray($album['Album']['process_specs']));
		$this->set('tn_specs', $this->Director->specsToArray($album['Album']['thumb_specs'], true));
		$this->render('refresh_generate_pane', 'ajax');
	}
	
	////
	// Reset order type and refresh the image order as needed
	////
	function order_type($id) {
		$this->Album->id = $id;
		$this->Album->save($this->data);
		$this->Album->cacheQueries = false;
		if ($this->Album->reorder($id)) {
			$this->data = $this->Album->read();
			$this->set('images', $this->data['Image']);
			$this->set('album', $this->data);
			$this->render('order_type', 'ajax');
		}
	}
	
	////
	// Reorder album after image upload
	////
	function reorder($id) {
		if ($this->Album->reorder($id)) {
			$this->redirect("/albums/edit/$id/images");
		}
	}
	
	////
	// Private function to refresh list
	////
	function _list() {
		// Find active and inactive albums
		$this->set('active_albums', $this->Album->findAll(aa('Album.active', 1), null, 'displayOrder', null, 1, -1));
		$this->set('inactive_albums', $this->Album->findAll(aa('Album.active', 0), null, 'displayOrder', null, 1, -1));
		// Render list to refresh dashboard
		$this->render('index', 'ajax');
	}
	
	////
	// Re-render preview area after changes
	////
	function _preview($id) {
		$this->Album->id = $id;
		$this->data = $this->Album->read();
		$this->set('album', $this->data);
		$this->render('preview', 'ajax');
	}
}

?>