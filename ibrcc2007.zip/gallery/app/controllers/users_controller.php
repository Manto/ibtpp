<?php

class UsersController extends AppController
{
    var $name = 'Users';
	var $uses = array('User'); 
	var $helpers = array('Html', 'Javascript', 'Ajax');
	var $components = array('Director');
	
	// No session check for these actions
	var $no_check = array('login', 'password', 'send_password');
	
	// Verify that any action *not* in this list is an Ajax call
	var $non_ajax_actions = array('manage', '_list', 'profile', 'login', 'logout', 'password');

	// Only logged in users should see this controller's actions
 	function beforeFilter() {
		// Protect ajax actions
		if (!in_array($this->action, $this->non_ajax_actions)) {
			$this->verifyAjax();
		}
		
		// Check session
		if (!in_array($this->action, $this->no_check)) {
			$this->checkSession();
		}
	}
	
	////
	// Acts as both the login display and actual login ui
	////
	function login() {
		$this->pageTitle = 'Login';
        $this->set('error', false);

        if (!empty($this->data)) {
            $someone = $this->User->findByUsr($this->data['User']['usr']);
            if (!empty($someone['User']['pwd']) && $someone['User']['pwd'] == $this->data['User']['pwd']) {
                $this->Session->write('User', $someone['User']);
				$redirect_to = $this->Session->read('redirect_to');
				if (strrpos($redirect_to, '/') == (strlen($redirect_to)-1)) {
					$redirect_to = '';
				}
				if (empty($redirect_to)) {
                	$this->redirect('/dashboard');
				} else {
					$this->Session->delete('redirect_to');
					header("Location: $redirect_to");
					exit();
				}
            } else {
                $this->set('error', true);
            }
        }
    }

	////
	// Password/login retrieval
	////
	function password() {
		$this->pageTitle = 'Password Reminder';
	}
	
	////
	// Password/login retrieval action
	////
	function send_password() {
		if ($this->data) {
			$cred = $this->data['User']['cred'];
			$user = $this->User->find("usr = '$cred' OR email = '$cred'");
			if (empty($user)) {
				$success = 0;
			} else {
				if (empty($user['User']['email'])) {
					$success = 1;
				} else {
					$path = DIR_HOST;
					$email = $user['User']['email'];
					$usr = $user['User']['usr'];
					$pwd = $user['User']['pwd'];
				
					$message = "This is a password reminder sent from SlideShowPro Director.\n\n------------------------------\n\n";
					$message .= 'Login here: ' . $path . "/\n";
					$message .= "Username: $usr\nPassword: $pwd\n\n";

					$headers = 'From: ' . $email;

					if (mail($email, 'SlideShowPro Director Login Reminder', $message, $headers)) {
						$success = 3;
					} else {
						$success = 2;
					}
				}
			}
			$this->set('success', $success);
			$this->render('send_password', 'ajax');
	 	} else {
			exit;
		}
	}
	
	////
	// Log the user out
	////
	function logout() {	
		$this->pageTitle = 'Logout';
        $this->Session->delete('User');
    }

	////
	// Edit user profile
	////
	function profile() {
		$this->pageTitle = 'User Profile';
		$id = $this->Session->read('User.id');
		$this->data = $this->User->find("id = $id");
	}
	
	////
	// Update a user record
	////
	function update($id) {
		$this->User->id = $id;
		if (!empty($this->params['form']['pass1'])) {
			$this->data['User']['pwd'] = $this->params['form']['pass1'];
		}
		$this->User->save($this->data);
		$u = $this->User->find(aa('id', $id));
		$this->Session->write('User', $u['User']);
	}
	
	////
	// Delete a user
	////
	function delete() {
		$this->User->del($this->data['User']['id']);
		$this->_list();
		$this->render('users', 'ajax');
	}
	
	////
	// Create user
	////
	function create() {
		if (!empty($this->data['User'])) {
			$this->data['User']['email'] = $this->data['User']['usr'];
			if ($this->User->save($this->data['User'])) {
				$this->User->id = $this->User->getLastInsertId();
				$pwd = $this->Director->randomStr();
				$this->User->saveField('pwd', $pwd);
				$path = DIR_HOST;
				$email = $this->data['User']['usr'];
				
				$message = $this->params['form']['message'];
				$message .= "\n\n------------------------------\n\n";
				$message .= 'Login here: ' . $path . "/\n";
				$message .= "Username: $email\nPassword: $pwd\n\n";
				$message .= 'Once you login you can change your password to something more familiar.';

				$headers = 'From: ' . $this->params['form']['from_email'];

				mail($email, 'SlideShowPro Director Login', $message, $headers);
				$this->_list();
				$this->render('users', 'ajax');
			}
		}
	}
	
	////
	// Manage users
	////
	function manage() {
		$this->pageTitle = 'Manage Users';
		$this->_list();
	}
	
	////
	// Get list of users for manage actions
	////
	function _list() {
		$this->set('users', $this->User->findAll("perms <> 4", null, 'usr'));
	}
}

?>