<?php

class AccountsController extends AppController {
    var $name = 'Accounts';
	var $helpers = array('Html', 'Javascript', 'Ajax', 'Director');
	var $components = array('Director');
	
	var $non_ajax_actions = array('preferences', '_data');
	
	// Only logged in users should see this controller's actions
 	function beforeFilter() {
		// Protect ajax actions
		if (!in_array($this->action, $this->non_ajax_actions)) {
			$this->verifyAjax();
		}
		// Check session
		$this->checkSession();
	}
	
	////
	// Manage account preferences
	////
	function preferences() {
		$this->pageTitle = 'Manage Preferences';
		$account = $this->Account->find();
		$this->set('account', $account);
		$this->_data($account);
		GD_VERSION > 0 ? $gd = true : $gd = false;
		$this->set('gd', $gd);
		$this->set('curl', extension_loaded('curl'));
	}
	
	////
	// Update accoumt
	////
	function update($id) {
		$this->Account->id = $id;
		$this->Account->save($this->data);
		exit;
	}
	
	////
	// Assemble and save default strings
	////
	function update_defaults($id) {
		$this->Account->id = $id;
		$this->Account->saveField($this->params['form']['switch'], $this->Director->assembleSpecs($this->params['form']));
		$account = $this->Account->read();
		$this->set('account', $account);
		$this->_data($account);
		$this->render('defaults', 'ajax');
	}
	
	////
	// DRY
	////
	function _data($account) {
		$this->set('lg_specs', $this->Director->specsToArray($account['Account']['process_specs']));
		$this->set('tn_specs', $this->Director->specsToArray($account['Account']['thumb_specs'], true));
	}
}

?>