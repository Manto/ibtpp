<?php

$xml_data = array();
$xml_album = array();
$xml_images = array();

class ImportsController extends AppController {
	// Models needed for this controller
	var $uses = array('Album', 'Image', 'Gallery', 'Tag');
    var $name = 'Imports';
	var $components = array('Director', 'RequestHandler');
	var $helpers = array('Html', 'Javascript', 'Ajax', 'Director');
	
	////
	// Index
 	////
	function index() {
		$this->checkSession();
		$this->pageTitle = 'Importing';
		$this->set('writable', $this->Director->setPerms(ALBUMS));
		$this->set('other_writable', $this->Director->setOtherPerms());
		
		if (is_dir(IMPORTS)) {
			$this->set('folders', $this->Director->checkImports());
		} else {
			$this->set('no_folder', true);
		}
	}
	
	////
	// Attempt to import the data and files
	////
	function vandelay() {
		$this->verifyAjax();
		if ($this->data) {
			global $xml_data;
			if (function_exists('set_time_limit')) {
				set_time_limit(0);
			}
			$folder = IMPORTS . DS . $this->data['Import']['folder'];
			$xml_file = $folder . DS . 'images.xml';
			
			$xml_parser = xml_parser_create(); 
			xml_set_element_handler($xml_parser, a($this, '_startTag'), a($this, '_endTag')); 
			xml_set_character_data_handler($xml_parser, a($this, '_contents')); 

			$fp = fopen($xml_file, "r"); 
			$data = fread($fp, 80000); 

			if(!(xml_parse($xml_parser, $data, feof($fp)))){ 
			    die("Error on line " . xml_get_current_line_number($xml_parser));
			} 

			xml_parser_free($xml_parser); 

			fclose($fp);
			
			$account = $this->Director->fetchAccount();
			$this->Gallery->save($this->data);
			$gallery_id = $this->Gallery->getLastInsertId();
			
			$order = 1;
			
			foreach($xml_data as $album) {
				$album_id = 0;
				$path = ''; $lg = ''; $tn = ''; $director = ''; $local_path = '';
				
				$node_count = count($album);
				$a = $album[0];
				$data = array();
				$local_path = isset($a['LGPATH']) ? $a['LGPATH'] : '';
				$local_path = $this->_trimSlashes($local_path);
				
				$local_tn_path = isset($a['TNPATH']) ? $a['TNPATH'] : '';
				$local_tn_path = $this->_trimSlashes($local_tn_path);
				
				if (is_dir($folder . DS . $local_path)) {
					$data['Album']['created_on'] = date('Y-m-d H:i:s');
					$data['Album']['active'] = 1;
					$data['Album']['name'] = isset($a['TITLE']) ? $a['TITLE'] : 'No name';
					$data['Album']['description'] = isset($a['DESCRIPTION']) ? $a['DESCRIPTION'] : '';
					if (!empty($local_tn_path)) { $data['Album']['tn'] = 1; };
					$this->Album->create();
					$this->Album->save($data);
					$album_id = $this->Album->getLastInsertId();
					$path = "album-$album_id";
					$this->Album->id = $album_id;
					$album_data = $this->Album->read();
					
					if ($this->Director->makeDir(ALBUMS . DS . $path) && $this->Director->createAlbumDirs($path)) {
						$this->Album->saveField('path', $path);
						$lg = ALBUMS . DS . $path . DS . 'lg';
						$tn = ALBUMS . DS . $path . DS . 'tn';
						$director = ALBUMS . DS . $path . DS . 'director';
						
						// Images
						for ($i = 1; $i < $node_count; $i++) {
							$data = array();
							$img = $album[$i];
							$original_src = $img['SRC'];
							$original_src = $this->_trimSlashes($original_src);
							$file = $folder . DS . $local_path . DS . $original_src;
							$thumb = $folder . DS . $local_tn_path . DS . $original_src;
							if (file_exists($file)) {
								$src = basename($file);
								$data['Image']['aid'] = $album_id;
								$data['Image']['src'] = $src;
								$data['Image']['title'] = isset($img['TITLE']) ? $img['TITLE'] : '';
								$data['Image']['caption'] = isset($img['CAPTION']) ? $img['CAPTION'] : '';
								$data['Image']['link'] = isset($img['LINK']) ? $img['LINK'] : '';
								$data['Image']['pause'] = isset($img['PAUSE']) ? $img['PAUSE'] : 0;
								$data['Image']['created_on'] = date('Y-m-d H:i:s');
								$data['Image']['seq'] = $i;
								$this->Image->create();
								$this->Image->save($data);
								copy($file, $lg . DS . $src);
								
								if (is_dir($director) && $account['Account']['internals']) {
									$this->Director->createThumb($lg . DS . $src, $director . DS . $src, 200, 200, 75, false);
								}
								
								if (file_exists($thumb)) {
									copy($thumb, $tn . DS . $src);
								}
							}
						}
						// Manage aTn
						if (isset($a['TN'])) {
							$atn = $this->_trimSlashes($a['TN']);
							$atn = $folder . DS . $atn;
							$file = basename($atn);
							if (file_exists($folder . DS . $local_tn_path . DS . $file)) {
								$this->Album->saveField('aTn', 'albums/' . $path . '/tn/' . $file);
							} else {
								$name = $path . '.' . $this->Director->returnExt($file);
								copy($atn, THUMBS . DS . $name);
								$this->Album->saveField('aTn', 'album-thumbs/' . $name);
							}
						}
						
						// Audio
						if (isset($a['AUDIO'])) {
							$audio_file = $this->_trimSlashes($a['AUDIO']);
							$file = $folder . DS . $audio_file;
							copy($file, AUDIO . DS . basename($file));
							$this->Album->saveField('audioFile', basename($file));
							if (isset($a['AUDIOCAPTION'])) {
								$this->Album->saveField('audioCap', $a['AUDIOCAPTION']);
							}
						}
						
						$tag['Tag']['did'] = $gallery_id;
						$tag['Tag']['aid'] = $album_id;
						$tag['Tag']['display'] = $order;
						$this->Gallery->Tag->create();
						$this->Gallery->Tag->save($tag);
						$order++;
					}
				}
			}
			exit;
		}
	}
	
	////
	// Private functions to parse the XML
	////
	function _contents($parser, $data) { 
		// Not needed, all data is contained in attributes
	} 

	function _startTag($parser, $tag, $attr) { 
		global $xml_album, $xml_images;
		switch($tag) {
			case 'ALBUM':
				$xml_album[] = $attr;
				break;
			case 'IMG':
				$xml_images[] = $attr;
				break;
		}	
	} 

	function _endTag($parser, $tag){ 
		if ($tag == 'ALBUM') {
			global $xml_album, $xml_images, $xml_data;
			$xml_data[] = array_merge($xml_album, $xml_images);
			$xml_album = array(); $xml_images = array();
		}
	}
	
	function _trimSlashes($string) {
		if (strpos($string, '/') === 0) {
			$string = substr_replace($string, '', 0, 1);
		}
		$len = strlen($string);
		if (strrpos($string, '/') == ($len-1)) {
			$string = substr_replace($string, '', $len-1, $len);
		}
		return str_replace('/', DS, $string);
	}
}

?>