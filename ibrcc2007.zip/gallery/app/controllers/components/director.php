<?php
class DirectorComponent extends Object {
   	var $controller = true;
	var $uses = array('Account', 'Image');
 
    function startup (&$controller) {
        $this->controller = &$controller;
    }

	////
	// Fetch account
	////
	function fetchAccount() {
		loadModel('Account');
		$this->Account =& new Account(); 
		return $this->Account->find();
	}
	
	////
	// Check email for a user
	////
	function checkMail($id) {
		loadModel('User');
		$this->User =& new User(); 
		$user = $this->User->find($id);
		return $user['User']['email'];
	}
	
	////
	// Get all slide shows
	////
	function fetchShows() {
		loadModel('Slideshow');
		$this->Slideshow =& new Slideshow();
		return $this->Slideshow->findAll();
	}
	
	////
	// Generate random string
	////
	function randomStr($len = 6) {
		return substr(md5(uniqid(microtime())), 0, $len);
	}
	
	////
	// Central directory creation logic
	// Creates a directory if it does not exits
 	////
	function makeDir($dir, $perms = '0777') {
		if (!is_dir($dir)) {
			umask(0);
			if (@mkdir($dir, octdec($perms))) {
				return true;
			} else {
				return false;
			}	
		} else {
			return true;
		}
	}
	
	////
	// Check for import folders
	////
	function checkImports() {
		if (is_dir(IMPORTS) && $handle = opendir(IMPORTS)) {
		    $folders = array();

		    while (false !== ($file = readdir($handle))) {
				$full_path = IMPORTS . DS . $file;
		        if (is_dir($full_path) && file_exists($full_path . DS . 'images.xml') && $file != '.' && $file != '..') {
					$folders[] = $file;
				}
		    }
		
		    closedir($handle);
			return $folders;
		} else {
			return array();
		}
	}
	
	
	////
	// Set permissions on a directory
	////
	function setPerms($dir, $perms = '0777') {
		if (!is_dir($dir)) {
			return $this->makeDir($dir);
		} elseif (is_writable($dir)) {
			return true;
		} else {
			$current_perms = substr(sprintf('%o', fileperms($dir)), -4);
			settype($current_perms, "string"); 
			if ($current_perms === $perms) {
				return true;
			} else {
				$mask = umask(0);                 
				if (@chmod($path, octdec($perms))) {
					umask($mask);
					return true;
				} else {
					umask($mask);
					return false;
				}
		    }
		}
	}
	
	////
	// Make sure album-audio and album-thumb have the correct perms
	////
	function setOtherPerms() {
		if ($this->setPerms(AUDIO) && $this->setPerms(THUMBS)) {
			return true;
		} else {
			return false;
		}
	}
	
	////
	// Create album subdirectories
	////
	function setAlbumPerms($path) {
		if (empty($path)) {
			return false;
		} else {
			$path = ALBUMS . DS . $path;
			$hr = $path . DS . 'hr';
			$lg = $path . DS . 'lg';
			$tn = $path . DS . 'tn';
			$director = $path . DS . 'director';
		
			if ($this->setPerms($hr) && $this->setPerms($lg) && $this->setPerms($tn) && $this->setPerms($director)) {
				return true;
			} else {
				return false;
			}
		}
	}
	
	////
	// Process permissions for album subdirectories
	////
	function createAlbumDirs($path) {
		$path = ALBUMS . DS . $path;
		$hr = $path . DS . 'hr';
		$lg = $path . DS . 'lg';
		$tn = $path . DS . 'tn';
		$director = $path . DS . 'director';
		
		if ($this->makeDir($hr) && $this->makeDir($lg) && $this->makeDir($tn) && $this->makeDir($director)) {
			return true;
		} else {
			return false;
		}
	}
	
	////
	// Search a directory for a filename using a regular expression
	// Found in PHP docs: http://us3.php.net/manual/en/function.file-exists.php#64908
	////
	
	function regExpSearch($regExp, $dir, $regType='P', $case='') {
		$func = ( $regType == 'P' ) ? 'preg_match' : 'ereg' . $case;
		$open = opendir($dir);
		while( ($file = readdir($open)) !== false ) {
			if ($func($regExp, $file) ) {
				return $file;
			}
		}
		return false;
	}
	
	////
	// Grab the extension of of any file
	////
	function returnExt($file) {
		$pos = strrpos($file, '.');
		return strtolower(substr($file, $pos+1, strlen($file)));
	}

	////
	// Grab all files in a directory
	////
	function directory($dir, $filters = 'all') {
		if ($filters == 'accepted') { $filters = 'jpg,JPG,JPEG,jpeg,gif,GIF,png,PNG,swf,SWF,flv,FLV'; }
		$handle = opendir($dir);
		$files = array();
		if ($filters == "all"):
			while (($file = readdir($handle))!==false):
				$files[] = $file;
			endwhile;
		endif;
		if ($filters != "all"):
			$filters = explode(",", $filters);
			while (($file = readdir($handle))!==false):
				for ($f=0; $f< sizeof($filters); $f++):
					$system = explode(".", $file);
					$count = count($system);
					if ($system[$count-1] == $filters[$f]):
						$files[] = $file;
					endif;
				endfor;
			endwhile;
		endif;
		closedir($handle);
		return $files;
	}
	
	////
	// Return string describing large thumbnail specs
	////
	function generateDesc($specs, $thumbs = false, $defaults = false) {
		if ($thumbs) {
			$desc_str = 'Thumbnails';
		} else {
			$desc_str = 'Large images';
		}
		
		if (empty($specs)) {
			if ($defaults) {
				return 'No default values for ' . strtolower(rtrim($desc_str, 's')) . ' processing.';
			} else {
				return 'No ' . strtolower($desc_str) . ' have been generated for this album.';
			}
		} else {
			$arr = $this->specsToArray($specs, $thumbs);
			$type_str = $this->typeStr($arr['s']);
			return "{$desc_str} are $type_str {$arr['w']}x{$arr['h']} ({$arr['q']} quality).";
		}
	}
	
	////
	// Turn the specs string into an array
	////
	function specsToArray($specs, $thumbs = false, $defaults = true) {
		if ($thumbs) {
			$index_str = 'thumb_specs';
		} else {
			$index_str = 'process_specs';
		}
		
		if (empty($specs)) {
			if ($defaults) {
				if (empty($this->controller->account['Account'][$index_str])) {
					$final = array(	
									'w' => '',
									'h' => '',
									'q' => 75,
									's' => 0
								);
				} else {
					$final = $this->specsToArray($this->controller->account['Account'][$index_str]);
				}
			} else {
				$final = array();
			}
		} else {
			$arr = explode('x', $specs);
			$final = array(	
							'w' => $arr[0],
							'h' => $arr[1],
							'q' => $arr[2],
							's' => $arr[3]
						);
		}
		return $final;
	}
	
	////
	// Write the type string based on square/proportional
	////
	function typeStr($square) {
		if ($square) {
			return 'cropped to fit';
		} else {
			return 'scaled proportionally to';
		}
	}
	
	////
	// Assemble spec string from user input
	////
	function assembleSpecs($arr) {
		return $arr['width'] . 'x' . $arr['height'] . 'x' . $arr['quality'] . 'x' . $arr['group_sq'];
 	}

	////
	// Process new image according to existing settings
	////
	function postProcess($album, $file) {
		if (in_array($this->returnExt($file), array('swf', 'flv'))) { return; }
		$path = ALBUMS . DS . $album['Album']['path'];
		$hr_path = $path . DS . 'hr' . DS . $file;
		$lg_path = $path . DS . 'lg' . DS . $file;
		$tn_path = $path . DS . 'tn' . DS . $file;
		$int_path = $path . DS . 'director' . DS . $file;
		
		$lg_specs = $this->specsToArray($album['Album']['process_specs'], false, false);
		$tn_specs = $this->specsToArray($album['Album']['thumb_specs'], true, false);

		if (!empty($lg_specs)) {
			rename($lg_path, $hr_path);
			$this->createThumb($hr_path, $lg_path, $lg_specs['w'], $lg_specs['h'], $lg_specs['q'], $lg_specs['s']);
		}

		if (!empty($tn_specs)) {
			if (file_exists($hr_path)) {
				$source = $hr_path;
			} else {
				$source = $lg_path;
			}
			$this->createThumb($source, $tn_path, $tn_specs['w'], $tn_specs['h'], $tn_specs['q'], $tn_specs['s']);
		}

		// Create internal thumb
		$account = $this->fetchAccount();
		if (is_dir($path . DS . 'director') && $account['Account']['internals']) {
			if (file_exists($hr_path)) { 
				$source = $hr_path;
			} else {
				$source = $lg_path;
			}
			$this->createThumb($source, $int_path, 200, 200, 75, false);
		}
	}
	
	////
	// Process new image content templates
	////
	function postProcessTemplates($album, $image_id) {
		loadModel('Image');
		$this->Image =& new Image(); 
		
		$title = $album['Album']['title_template'];
		$link = $album['Album']['link_template'];
		$caption = $album['Album']['caption_template'];
		$this->Image->id = $image_id;
		
		if (!empty($title)) {
			$this->Image->formTitle($title);
		}
		
		if (!empty($caption)) {
			$this->Image->formCaption($caption);
		}
		
		if (!empty($link)) {
			$this->Image->formLink($link, $album);
		}
	}
	
	////
	// Recursive Directory Removal
	////
	function rmdirr($dir) {
	   	if (!$dh = @opendir($dir)) return;
	   	while (($obj = readdir($dh))) {
	       	if ($obj=='.' || $obj=='..') continue;
	       	$path = $dir.'/'.$obj;
			if (is_dir($path)) {
				@$this->rmdirr($path);
			} else {
				@unlink($path);
			}
	   	}
	 	closedir($dh);
	   	rmdir($dir);
	}

	////
	// Transform a string (e.g. 15MB) into an actual byte representation
	////
	function returnBytes($val) {
	   $val = trim($val);
	   $last = strtolower($val{strlen($val)-1});
	   switch($last) {
	       case 'g':
	           	$val *= 1024;
	       case 'm':
	           	$val *= 1024;
	       case 'k':
	           	$val *= 1024;
	   }
	   return $val;
	}

	////
	// Ye old autop function via PhotoMatt.net
	// This function is GPL'd (I believe) and is not covered by the Director license
	////
	function autop($pee, $br=1) {
		$pee = preg_replace("/(\r\n|\n|\r)/", "\n", $pee); // cross-platform newlines
		$pee = preg_replace("/\n\n+/", "\n\n", $pee); // take care of duplicates
		$pee = preg_replace('/\n?(.+?)(\n\n|\z)/s', "<p>$1</p>\n", $pee); // make paragraphs, including one at the end
		if ($br) $pee = preg_replace('|(?<!</p>)\s*\n|', "<br />\n", $pee); // optionally make line breaks
		return $pee;
	}
	
	////
	// Check GD
	////
	function gdVersion() {
		if (function_exists('gd_info')) {
			$gd = gd_info();
			$version = ereg_replace('[[:alpha:][:space:]()]+', '', $gd['GD Version']);
			settype($version, 'integer');
			return $version;
	 	} else {
			return 0;
		}
	}

	////
	// The workhorse createThumb function
	////
	function createThumb($name, $filename, $new_w, $new_h, $quality, $square = false) {
		$old_mask = umask(0);
		$ext = $this->returnExt($name);
		$gd = $this->gdVersion();
		
		// Find out what we are dealing with
		switch(true) {
			case preg_match("/jpg|jpeg|JPG|JPEG/", $ext):
				if (imagetypes() & IMG_JPG) {
					$src_img = imagecreatefromjpeg($name);
					$type = 'jpg';
				} else {
					return;
				}
				break;
			case preg_match("/png/", $ext):
				if (imagetypes() & IMG_PNG) {
					$src_img = imagecreatefrompng($name);
					$type = 'png';
				} else {
					return;
				}
				break;
			case preg_match("/gif|GIF/", $ext):
				if (imagetypes() & IMG_GIF) { 
					$src_img = imagecreatefromgif($name);
					$type = 'gif';
				} else {
					return;
				}
				break;
		}
		
		if (!isset($src_img)) { return; };

		$old_x = imagesx($src_img);
		$old_y = imagesy($src_img);

		$original_aspect = $old_x/$old_y;
		$new_aspect = $new_w/$new_h;

		if ($square) {
			if ($original_aspect >= $new_aspect) {
				$thumb_w = ($new_h*$old_x)/$old_y;
				$thumb_h = $new_h;
				$crop_x = ($thumb_w - $new_w)/2;
				$crop_y = 0;
			} else {
				$thumb_w = $new_w;
				$thumb_h = ($new_w*$old_y)/$old_x;
				$crop_y = ($thumb_h - $new_h)/2;
				$crop_x = 0;
			}
		} else {
		 	$crop_y = 0;
			$crop_x = 0;

			if ($original_aspect >= $new_aspect) {
				if ($new_w > $old_x) {
					copy($name, $filename);
					return;
				}
				$thumb_w = $new_w;
				$thumb_h = ($new_w*$old_y)/$old_x;
			} else { 
				if ($new_h > $old_y) {
				 	copy($name, $filename); 
					return;
				}
				$thumb_w = ($new_h*$old_x)/$old_y;
				$thumb_h = $new_h;
			}
		}

		if ($gd != 2) {
			$dst_img_one = imagecreate($thumb_w, $thumb_h);
			imagecopyresized($dst_img_one, $src_img, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y);    
		} else {
			$dst_img_one = imagecreatetruecolor($thumb_w,$thumb_h);
			imagecopyresampled($dst_img_one, $src_img, 0, 0, 0, 0, $thumb_w, $thumb_h, $old_x, $old_y); 
		}        

		if ($square) {
			if ($gd != 2) {
				$dst_img = imagecreate($new_w, $new_h);
				imagecopyresized($dst_img, $dst_img_one, 0, 0, $crop_x, $crop_y, $new_w, $new_h, $new_w, $new_h);    
			} else {
				$dst_img = imagecreatetruecolor($new_w, $new_h);
				imagecopyresampled($dst_img, $dst_img_one, 0, 0, $crop_x, $crop_y, $new_w, $new_h, $new_w, $new_h); 
			}
		} else {
			$dst_img = $dst_img_one;
		}

		if ($type == 'png') {
			imagepng($dst_img, $filename); 
		} elseif ($type == 'gif') {
			imagegif($dst_img, $filename);
		} else {
			imagejpeg($dst_img, $filename, $quality); 
		}

		imagedestroy($dst_img);
		imagedestroy($dst_img_one); 
		imagedestroy($src_img); 
		umask($old_mask);
	}

	////
	// Rotate image
	////
	function rotateImg($name, $r){ 
		$old_mask = umask(0);
		$ext = $this->returnExt($name);
		
		// Find out what we are dealing with
		switch(true) {
			case preg_match("/jpg|jpeg|JPG|JPEG/", $ext):
				if (imagetypes() & IMG_JPG) {
					$src_img = imagecreatefromjpeg($name);
					$type = 'jpg';
				} else {
					return;
				}
				break;
			case preg_match("/png/", $ext):
				if (imagetypes() & IMG_PNG) {
					$src_img = imagecreatefrompng($name);
					$type = 'png';
				} else {
					return;
				}
				break;
			case preg_match("/gif|GIF/", $ext):
				if (imagetypes() & IMG_GIF) { 
					$src_img = imagecreatefromgif($name);
					$type = 'gif';
				} else {
					return;
				}
				break;
		}
		
		if (!isset($src_img)) { return; };

		$new = imagerotate($src_img, $r, 0);

		if ($type == 'png') {
			imagepng($new, $name); 
	    } elseif ($type == 'gif') {
			imagegif($new, $name);
		} else {
			imagejpeg($new, $name, 95); 
		}

		imagedestroy($src_img);
		imagedestroy($new); 
		umask($old_mask);
	}
}
?>