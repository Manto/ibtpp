<?php

class SiteController extends AppController {
	// Models needed for this controller
	var $uses = array('Album', 'Gallery', 'Image', 'Slideshow', 'Rss', 'Tag');
	// Helpers
	var $helpers = array('Html', 'Javascript', 'Ajax', 'Director');
    var $name = 'Site';	
	// Data action does not need sessions
	var $disableSessions = array('data');
	
	////
	// Application Dashboard
	////
	function index() {
		$this->checkSession();
		$this->pageTitle = 'Dashboard';
		
		// Find active and inactive albums
		$this->set('active_albums', $this->Album->findAll(aa('Album.active', 1), null, 'displayOrder', null, 1, -1));
		$this->set('inactive_albums', $this->Album->findAll(aa('Album.active', 0), null, 'displayOrder', null, 1, -1));
		
		// Get Dynamic Galleries
		$this->Gallery->unbindModel(array('hasMany' => a('Tags')));
		$this->set('galleries', $this->Gallery->findAll());
		
		// Available imports?
		$imports = $this->Director->checkImports();
		if (empty($imports) || !$imports) {
			$this->set('imports', false);
		} else {
			$this->set('imports', true);
		}
		
		if ($this->account['Account']['externals'] && extension_loaded('curl')) {
			// Get the latest 6 news bits from ssp.net, cache it for 1 hour
        	$news = $this->Rss->findAll('http://www.slideshowpro.net/news/index.xml', 6, '+1 hour');
			$version = $this->Rss->findAll('http://www.slideshowpro.net/director_version/director_version.xml', 1, '+1 hour');
			$cur_version = $version['Items'][0]['title']['value'];
			if ($cur_version != substr(DIR_VERSION, 0, 5)) {
				$this->set('version_link', $version['Items'][0]['guid']['value']);
			}
        	$this->set('news', $news['Items']);
		} else {
			$this->set('news', array());
		}
	}
	
	////
	// XML output
	////
	function data($gid = 'no', $album = 0) {
		// Start building path to cache file
		$path_to_cache = XML_CACHE . DS . 'images';
		
		// Decide whether to serve a gallery, individual album, or full feed
		if ($gid != 'no') {
			$id = $gid;
			$path_to_cache .= '_gid_' . $id;
			$albums = $this->Tag->findAll("did = $id", null, 'display');
		} elseif ($album != 0) {
			$id = $album;
			$path_to_cache .= '_album_' . $id;
			$albums = $this->Album->findAll(aa("Album.id", $id), null, 'displayOrder');
		} else {
			$albums = $this->Album->findAll(aa('Album.active', 1), null, 'displayOrder');
		}
		
		$this->set('albums', $albums);
		
		// Finish up xml_cache path
		$path_to_cache .= '.xml';
		$this->set('path_to_cache', $path_to_cache);
		
		// Render w/o layout
		$this->render('data', 'ajax');
	}
}

?>