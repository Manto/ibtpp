<?php

class GalleriesController extends AppController {
	// Models needed for this controller
	var $uses = array('Album', 'Gallery', 'Tag');
	// Helpers
	var $helpers = array('Html', 'Javascript', 'Ajax', 'Director');
	var $components = array('Director');
    var $name = 'Galleries';

	var $non_ajax_actions = array('edit', '_memberData', '_list');
	
	// Only logged in users should see this controller's actions
 	function beforeFilter() {
		// Protect ajax actions
		if (!in_array($this->action, $this->non_ajax_actions)) {
			$this->verifyAjax();
		}
		// Check session
		$this->checkSession();
	}
	
	////
	// Create a new gallery
	////	
	function create() {
		if ($this->Gallery->save($this->data)) {
			$this->_list();
		}
	}
	
	////
	// Update Gallery
	////
	
	function update($id) {
		$this->Gallery->id = $id;
		if ($this->Gallery->save($this->data)) {
			exit($this->data['Gallery']['name']);
		}
		exit("error");
	}
	
	////
	// Delete gallery
	////
	function delete() {
		if ($this->Gallery->del($this->params['form']['id'])) {
			$this->_list();
		}
	}
	
	////
	// Edit gallery
	////
	function edit($id) {
		$this->pageTitle = 'Galleries';
		$this->_memberData($id);
		
	}
	
	////
	// Link and delink albums to galleries
	////
	function link($id, $aid) {
		$this->data['Tag']['did'] = $id;
		$this->data['Tag']['aid'] = $aid;
		$this->Gallery->Tag->save($this->data);
		
		$this->_memberData($id);
		$this->render('refresh_edit_pane', 'ajax');
	}
	
	function delink() {
		$id = $this->params['form']['id']; $aid = $this->params['form']['aid'];
		$link = $this->Tag->find("did = $id AND aid = $aid");
		$this->Tag->delete($link['Tag']['id']);
		$this->_memberData($id);
		$this->render('refresh_edit_pane', 'ajax');
	}
	
	////
	// Private function to refresh gallery members
	////
	function _memberData($id) {
		$this->data = $this->Gallery->find("id = $id", null, null, 2);
		$this->set('gallery', $this->data);
		
		$member_ids_arr = array();
		foreach ($this->data['Tags'] as $l) { 
			$member_ids_arr[] = $l['aid'];
		}
		
		// Find active albums, gallery members, and the diff
		$all_albums = $this->Album->findActive();
		$non_member_ids_arr = array();
		foreach ($all_albums as $a) { 
			$aid = $a['Album']['id'];
			if (!in_array($aid, $member_ids_arr)) {
				$non_member_ids_arr[] = $aid;
			}
		}
		if (empty($non_member_ids_arr)) {
			$non_members = array();
		} else {
			$non_member_ids = join(',', $non_member_ids_arr);
			$non_members = $this->Album->findAll("id IN ($non_member_ids)", null, 'name', null, 1, -1);
		}
		
		$this->set('members', $this->data['Tags']);
		$this->set('non_members', $non_members);
	}
	
	////
	// Private function to refresh list
	////
	function _list() {
		$this->set('galleries', $this->Gallery->findAll());
		$this->render('list', 'ajax');
	}
}

?>