<?php

class PicsController extends AppController {
	// Models needed for this controller
	var $uses = array('Album', 'Image');
	var $helpers = array('Director');
    var $name = 'Images';

	var $non_ajax_actions = array('_is_album_thumb');
	
	// Only logged in users should see this controller's actions
 	function beforeFilter() {
		// Protect ajax actions
		if (!in_array($this->action, $this->non_ajax_actions)) {
			$this->verifyAjax();
		}
		// Check session
		$this->checkSession();
	}
	
	////
	// Edit an image
	////
	function edit($id) {
		$this->Image->id = $id;
		$this->data = $this->Image->read();
		$this->set('i', $this->data['Image']);
		$this->set('a', $this->data['Album']);
		$this->set('is_album_thumb', $this->_is_album_thumb($this->data));
		$this->set('rel_path', str_replace('/index.php?', '', $this->base) . '/albums/' . $this->data['Album']['path'] . '/lg/' . $this->data['Image']['src']);
		$this->set('full_path', ALBUMS . DS . $this->data['Album']['path'] . DS . 'lg' . DS . $this->data['Image']['src']);
		$this->set('tn_path', ALBUMS . DS . $this->data['Album']['path'] . DS . 'tn' . DS . $this->data['Image']['src']);
		$this->render('edit', 'ajax');
	}
	
	////
	// Update image properties
	////
	function update($id) {
		$this->Image->id = $id;
		$image = $this->Image->read();
		$is_thumb = $this->_is_album_thumb($image);
		$this->Image->save($this->data);
		
		// If they made a change re: album thumb
		if (!$is_thumb && $this->params['form']['album-thumb']) {
			$thumb = 'albums/' . $image['Album']['path'] . '/tn/' . $image['Image']['src'];
		} elseif ($is_thumb && !$this->params['form']['album-thumb']) {
			$thumb = '';
		}
		
		if (isset($thumb)) {
			$this->Album->id = $image['Album']['id'];
			$this->Album->saveField('aTn', $thumb);
			$this->set('new_thumb', DIR_HOST . '/' . $thumb);
		}
		
		$this->render('update', 'ajax');
	}
	
	////
	// Delete an image
	////
	function delete() {
		$this->Image->id = $this->data['Image']['id'];
		$image = $this->Image->read();
		$is_thumb = $this->_is_album_thumb($image);
		$album_path = $image['Album']['path'];
		$albums = $this->Album->findAll(aa('path', $album_path));
		
		// Delete the image from the DB
		$this->Image->del();
		
		// Delete it from the filesystem if no other albums use this path
		if (count($albums) == 1) {
			$path = ALBUMS . DS . $album_path . DS;
			@unlink($path . 'director' . DS . $image['Image']['src']);
			@unlink($path . 'hr' . DS . $image['Image']['src']);
			@unlink($path . 'lg' . DS . $image['Image']['src']);
			@unlink($path . 'tn' . DS . $image['Image']['src']);
		}
		if ($is_thumb) {
			$this->Album->id = $image['Album']['id'];
			$this->Album->saveField('aTn', '');
			$this->set('new_thumb', '');
		}
		$this->render('update', 'ajax');
	}
	
	////
	// Rotate image
	////
	function rotate() {
		$this->Image->id = $this->data['rotate']['id'];
		$degree = $this->data['rotate']['deg'];
		$image = $this->Image->read();
		$account = $this->Director->fetchAccount();

		// Paths
		$path = ALBUMS . DS . $image['Album']['path'];
	
		$hr = $path . DS . 'hr' . DS . $image['Image']['src'];
		$base = $lg = $path . DS . 'lg' . DS . $image['Image']['src'];
		$tn = $path . DS . 'tn' . DS . $image['Image']['src'];
		$dir = $path . DS . 'director' . DS . $image['Image']['src'];
		
		// Rotate hr if it exists
		if (file_exists($hr)) {
			$this->Director->rotateImg($hr, $degree);
			$base = $hr;
		}
		
		// Rotate lg	
		if (!empty($image['Album']['process_specs']) && $base != $lg) {
			$specs = $this->Director->specsToArray($image['Album']['process_specs']);
			$this->Director->createthumb($base, $lg, $specs['w'], $specs['h'], $specs['q'], $specs['s']);
		} else {
			$this->Director->rotateImg($lg, $degree);
		}
		
		// Rotate tn
		if (!empty($image['Album']['thumb_specs'])) {
			$specs = $this->Director->specsToArray($image['Album']['thumb_specs']);
			$this->Director->createthumb($base, $tn, $specs['w'], $specs['h'], $specs['q'], $specs['s']);
		} elseif (file_exists($tn)) {
			$this->Director->rotateImg($tn, $degree);
		}
		
		// Rotate internal thumb
		if (file_exists($dir)) {
			$this->Director->rotateImg($dir, $degree);
		}
		exit;
	}
	
	////
	// Private function to check if the current image is the album thumb
	////
	function _is_album_thumb($data) {
		$album_thumb = $data['Album']['aTn'];
		if (eregi('/tn/', $album_thumb) && basename($album_thumb) == $data['Image']['src']) {
			return true;
		} else { 
			return false;
		}
	}
	
	////
	// Updates image order
	////
	function order() {
		// On really large albums, this might take a while
		if (function_exists('set_time_limit')) {
			set_time_limit(0);
		}
		$order = $this->params['form']['image-view'];
		while (list($key, $val) = each($order)) {
			$key++;
			$this->Image->id = $val;
			$this->Image->saveField('seq', $key);
		}
	}
	
	////
	// Set titles on all images in an album
	////
	function titles($id) {
		// On really large albums, this might take a while
		if (function_exists('set_time_limit')) {
			set_time_limit(0);
		}
		$images = $this->Album->returnImages($id);
		foreach ($images as $i) {
			$this->Image->id = $i['id'];
			$this->Image->formTitle($this->data['Album']['title_template']);
		}
		$this->Album->id = $id;
		$this->Album->save($this->data);
		exit();
	}
	
	////
	// Set captions on all images in an album
	////
	function captions($id) {
		// On really large albums, this might take a while
		if (function_exists('set_time_limit')) {
			set_time_limit(0);
		}
		$images = $this->Album->returnImages($id);
		foreach ($images as $i)	{
			$this->Image->id = $i['id'];
			$this->Image->formCaption($this->data['Album']['caption_template']);
		}
		$this->Album->id = $id;
		$this->Album->save($this->data);
		exit();
	}
	
	////
	// Set links on all images in an album
	////
	function links($id)	{
		// On really large albums, this might take a while
		if (function_exists('set_time_limit')) {
			set_time_limit(0);
		}
		$images = $this->Album->returnImages($id);
		$this->Album->id = $id;
		$album = $this->Album->read();
		$action = $this->data['Album']['link_template'];
		
		foreach($images as $i) {
			$this->Image->id = $i['id'];
			$this->Image->formLink($action, $album);
		}
		
		$this->Album->save($this->data);
	}
}

?>