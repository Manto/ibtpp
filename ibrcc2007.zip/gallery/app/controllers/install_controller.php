<?php

class InstallController extends AppController
{
    var $name = 'Install';
	var $uses = array();
	var $helpers = array('Html', 'Javascript');
	var $components = array('Director');
	
	function beforeFilter() {
		$this->pageTitle = "Installing"; 
		$this->set('config_path', ROOT . DS . 'config');
	}
	
	////
	// Install landing page/license
	////
	function index() {}
	
	////
	// Perform server check
	////
	function test() {
		if ($this->data) {
			$php = version_compare(PHP_VERSION, '4.3.2', 'ge');
			extension_loaded('mysql') ? $mysql = true : $mysql = extension_loaded('mysqli');
			if (ini_get('safe_mode') == false || ini_get('safe_mode') == '' || strtolower(ini_get('safe_mode')) == 'off') {
				$no_safe_mode = true;
			} else {
				$no_safe_mode = false;
			}
			if ($php && $mysql && $no_safe_mode) {
				$this->set('success', true);
			} else {
				$this->set('success', false);
				$this->set('php', $php);
				$this->set('mysql', $mysql);
				$this->set('no_safe_mode', $no_safe_mode);
			}
		} else {
			$this->redirect('/install');
			exit;
		}
	}
	
	////
	// Enter database details and create config file
	////
	function database() {
		$this->set('db_select_error', false);
		$this->set('connection_error', false);
		$this->set('conf_exists', false);
		$this->set('write_error', false);
		$filename = ROOT . DS . 'config' . DS . 'conf.php';
		
		if ($this->data) {
			if (file_exists($filename)) {
				$this->set('conf_exists', true);
			} else {
				$details = $this->data['db'];
				$server = trim($details['server']);
				$name = trim($details['name']);
				$user = trim($details['user']);
				$pass = trim($details['pass']);
				$prefix = trim($details['prefix']);
			
				$link = @mysql_connect($server, $user, $pass);
				if (!$link) {
				    $this->set('connection_error', true);
					$this->set('mysql_error', mysql_error());
				} elseif (@!mysql_select_db($details['name'])) {
					$this->set('db_select_error', true);
					$this->set('mysql_error', mysql_error());
				} else {			
					$fill = "<?php\n\n\t";
					$fill .= '$host = \''.	$server	."';\n\t";
					$fill .= '$db = \''.	$name	."';\n\t";
					$fill .= '$user = \''.	$user	."';\n\t";
					$fill .= '$pass = \''.	$pass	."';\n\n\t";
					$fill .= '$pre = \''.	$prefix	."';\n\n";
					$fill .= '?>';
			
				
					$handle = fopen($filename, 'w+');

					if (fwrite($handle, $fill) == false) {
						$this->set('write_error', true);
					} else {
						$this->redirect('/install/register');
						exit;
					}
				}
			}
		} else {
			if (file_exists($filename)) {
				$this->set('conf_exists', true);
			}
		}
	}
	
	////
	// Create the first user
	////
	function register() {}
	
	////
	// Install it already!
	////
	function finish() {
		if ($this->data) {
			mysql_connect(DIR_DB_HOST, DIR_DB_USER, DIR_DB_PASSWORD);
			mysql_select_db(DIR_DB);
		
			$atbl = DIR_DB_PRE . 'albums';
			$itbl = DIR_DB_PRE . 'images';
			$dtbl = DIR_DB_PRE . 'dynamic';
			$dltbl = DIR_DB_PRE . 'dynamic_links';
			$stbl = DIR_DB_PRE . 'slideshows';
			$utbl = DIR_DB_PRE . 'usrs';
			$acctbl = DIR_DB_PRE . 'account';
		
			$this->set('error', '');
		
			$queries = array(
					"CREATE TABLE $atbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), name VARCHAR(100), description BLOB, path VARCHAR(50), tn TINYINT(1) NOT NULL DEFAULT '0', aTn VARCHAR(150), active TINYINT(1) NOT NULL DEFAULT '0', startHere TINYINT(1) NOT NULL DEFAULT '0', audioFile VARCHAR(100) DEFAULT NULL, audioCap VARCHAR(200) DEFAULT NULL, displayOrder INT(4) DEFAULT '999', target TINYINT(1) NOT NULL DEFAULT '0', thumb_specs VARCHAR(255), process_specs VARCHAR(255), show_headers INT(1) NOT NULL DEFAULT '1', images_count INT NOT NULL DEFAULT 0, sort_type VARCHAR(255) NOT NULL DEFAULT 'manual', title_template VARCHAR(255), link_template INT(2), caption_template TEXT, updated_on TIMESTAMP, created_on TIMESTAMP)",
					"CREATE TABLE $itbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), aid INT, title VARCHAR(255), src VARCHAR(255), caption TEXT, link TEXT, active TINYINT(1) NOT NULL DEFAULT '1', seq INT(4) NOT NULL DEFAULT '999', pause INT(4) NOT NULL DEFAULT '0', target TINYINT(1) NOT NULL DEFAULT '0', updated_on TIMESTAMP, created_on TIMESTAMP)",
					"CREATE TABLE $utbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), usr VARCHAR(50), pwd VARCHAR(50), email VARCHAR(255), perms INT(2) NOT NULL DEFAULT '1')",
					"CREATE TABLE $dtbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), name VARCHAR(100))",
					"CREATE TABLE $dltbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), did INT, aid INT, display INT DEFAULT '800')",
					"CREATE TABLE $stbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), name VARCHAR(255), url VARCHAR(255))",
					"INSERT INTO $utbl (id, usr, email, pwd, perms) VALUES (NULL, '" . $this->data['User']['usr'] . "', '" . $this->data['User']['email'] . "', '" . $this->data['User']['pwd'] . "', 4)",
					"CREATE TABLE $acctbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), externals TINYINT(1), internals TINYINT(1), process_specs VARCHAR(255), thumb_specs VARCHAR(255), version VARCHAR(255))",
					"INSERT INTO $acctbl VALUES (NULL, 1, 1, '', '', '" . DIR_VERSION . "')"			
				);
		
			foreach($queries as $query) {
				if (!mysql_query($query)) {
					$this->set('error', mysql_error());
					$this->render();
					exit;
				}
			}
			$this->_clean(CACHE . DS . 'models');
		} else {
			$this->redirect('/install');
		}
	}
	
	////
	// Perform upgrade
	////
	function upgrade() {
		// Make sure they have the appropriate version of PHP, as 1.0.8+ now requires 4.3.2+
		if (version_compare(PHP_VERSION, '4.3.2', 'ge')) {
			$this->set('error', false);
			mysql_connect(DIR_DB_HOST, DIR_DB_USER, DIR_DB_PASSWORD);
			mysql_select_db(DIR_DB);
		
			$version = DIR_VERSION;
			$atbl = DIR_DB_PRE . 'albums';
			$itbl = DIR_DB_PRE . 'images';
			$dtbl = DIR_DB_PRE . 'dynamic';
			$dltbl = DIR_DB_PRE . 'dynamic_links';
			$stbl = DIR_DB_PRE . 'slideshows';
			$utbl = DIR_DB_PRE . 'usrs';
			$acctbl = DIR_DB_PRE . 'account';
		
			@mysql_query("CREATE TABLE $acctbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), externals TINYINT(1), internals TINYINT(1), process_specs VARCHAR(255), thumb_specs VARCHAR(255), version VARCHAR(255)) ");
		
			$check = mysql_query("SELECT * FROM $acctbl");
		
			if (mysql_num_rows($check) == 0):
				@mysql_query("INSERT INTO $acctbl VALUES (NULL, 1, 1, '', '', '$version')");
			endif;
		
			// 1.0.0
			@mysql_query("ALTER TABLE $atbl CHANGE displayOrder displayOrder INT(4) NOT NULL DEFAULT '999'");
			@mysql_query("ALTER TABLE $itbl CHANGE seq seq INT(4) NOT NULL DEFAULT '999'");
			@mysql_query("ALTER TABLE $itbl ADD pause INT(4) NOT NULL DEFAULT '0'");
			@mysql_query("ALTER TABLE $itbl ADD title VARCHAR(255)");
			@mysql_query("ALTER TABLE $itbl ADD target TINYINT(1) NOT NULL DEFAULT '0'");
			@mysql_query("ALTER TABLE $utbl ADD perms TINYINT(1) NOT NULL DEFAULT '1'");
			@mysql_query("CREATE TABLE $stbl(id INT AUTO_INCREMENT, PRIMARY KEY(id), name VARCHAR(255), url VARCHAR(255))");
			@mysql_query("UPDATE $utbl SET perms = 4 WHERE id = {$_SESSION['loginID']}");
		
			// 1.0.3
			@mysql_query("ALTER TABLE $atbl ADD show_headers INT(1) NOT NULL DEFAULT '1'");
			@mysql_query("ALTER TABLE $atbl ADD process_specs VARCHAR(255)");
			@mysql_query("ALTER TABLE $atbl ADD thumb_specs VARCHAR(255)");
			@mysql_query("UPDATE $atbl SET show_headers = 1");
			@mysql_query("ALTER TABLE $itbl CHANGE src src VARCHAR(255)");
		
			// 1.0.5
			@mysql_query("UPDATE $atbl SET thumb_specs = CONCAT(thumb_specs, 'x0') WHERE thumb_specs IS NOT NULL AND thumb_specs <> ''");
		
			// 1.0.6
			@mysql_query("UPDATE $atbl SET process_specs = CONCAT(process_specs, 'x0') WHERE thumb_specs IS NOT NULL AND thumb_specs <> ''");
		
			// 1.0.7
			@mysql_query("ALTER TABLE $atbl ADD updated_on TIMESTAMP");
			@mysql_query("ALTER TABLE $atbl ADD created_on TIMESTAMP");
		
			@mysql_query("UPDATE $atbl SET created_on = NOW() WHERE created_on IS NULL OR created_on = '' OR created_on = '0000-00-00 00:00'");
		
			@mysql_query("ALTER TABLE $itbl ADD updated_on TIMESTAMP");
			@mysql_query("ALTER TABLE $itbl ADD created_on TIMESTAMP");
		
			@mysql_query("UPDATE $itbl SET created_on = NOW() WHERE created_on IS NULL OR created_on = '' or created_on = '0000-00-00 00:00'");
		
			@mysql_query("UPDATE $acctbl SET version = '$version'");
		
			// 1.0.8
			@mysql_query("ALTER TABLE $utbl CHANGE perms perms INT(2) NOT NULL DEFAULT 1");
			@mysql_query("ALTER TABLE $atbl ADD images_count INT NOT NULL DEFAULT 0");
			@mysql_query("ALTER TABLE $atbl ADD sort_type VARCHAR(255) NOT NULL DEFAULT 'manual'");
		
			// 1.0.9
			@mysql_query("ALTER TABLE $atbl ADD title_template VARCHAR(255)");
			@mysql_query("ALTER TABLE $atbl ADD link_template INT(2)");
			@mysql_query("ALTER TABLE $atbl ADD caption_template TEXT");
			@mysql_query("ALTER TABLE $utbl ADD email VARCHAR(255)");
		
			// Strip abs path from album thumbs
			loadModel('Album');
			$this->Album =& new Album(); 
			$albums = $this->Album->findAll("atn LIKE 'http://%'");
			$clean_host = trim(preg_replace('/(http:\/\/www.|http:\/\/)/', '', DIR_HOST));
			$clean_host = str_replace('/', "\\/", $clean_host);
			foreach($albums as $a) {
				$this->Album->id = $a['Album']['id'];
				$tn = $a['Album']['aTn'];
				$clean = preg_replace("/http:\/\/(www.)?$clean_host\//", '', $tn);
				$this->Album->saveField('aTn', $clean);
			}
		
			// Image counts
			$albums = $this->Album->findAll('images_count = 0 OR images_count IS NULL');
			foreach($albums as $a) {
				$this->Album->id = $a['Album']['id'];
				$images = count($this->Album->returnImages($this->Album->id));
				$this->Album->saveField('images_count', $images);
			}
		
			// Clean XML cache and model cache
			$this->_clean(XML_CACHE);
			$this->_clean(CACHE . DS . 'models');
	 	} else {
			$this->set('error', true);
		}
	}
	
	////
	// Clean a directory
	////
	function _clean($dir) {
		if ($dh = @opendir($dir)) {
			while (($obj = readdir($dh))) {
		       if ($obj=='.' || $obj=='..' || $obj =='.svn') continue;
		       if (!@unlink($dir.'/'.$obj)) $this->Director->rmdirr($dir.'/'.$obj);
		   	}    
		}
	}
}