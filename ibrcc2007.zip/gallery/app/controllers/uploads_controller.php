<?php

class UploadsController extends AppController {
	// Models needed for this controller
	var $uses = array('Album', 'Image');
    var $name = 'Uploads';
	var $components = array('Director', 'RequestHandler');
	
	////
	// Accepts file uploads
 	////
	function image($id, $upload_type) {	
		// Make sure this is coming from the flash player and is a POST request
		if (strpos(strtolower(env('HTTP_USER_AGENT')), 'flash') === false || !$this->RequestHandler->isPost()) {
			exit;
		}
		
		// Make sure permissions are set correctly
		$old_mask = umask(0);
			
		// Get album
		$this->Album->id = $id;
		$album = $this->Album->read();
		
		// Flash uploads crap out when spaces are in the name
		$file = str_replace(" ", "_", $this->params['form']['Filedata']['name']);
		$file = ereg_replace("[^A-Za-z0-9._-]", "_", $file);

		// Get image extensions so we make sure
		// a safe file is uploaded
		$ext = $this->Director->returnExt($file);
		
		// Paths
		$the_temp = $this->params['form']['Filedata']['tmp_name'];
		$path = ALBUMS . DS . $album['Album']['path'];
		$hr_path = $path . DS . 'hr' . DS . $file;
		
		$lg_path = $path . DS . 'lg' . DS . $file;
		$lg_temp = $lg_path . '.tmp';
		
		$tn_path = $path . DS . 'tn' . DS . $file;
		$tn_temp = $tn_path . '.tmp';
		
		$thumb_path = THUMBS . DS . 'album-' . $id . '.' . $ext;
		$thumb_temp = $thumb_path . '.tmp';
		
		$int_path = $path . DS . 'director' . DS . $file;
				
		settype($upload_type, 'integer');
		
		if (in_array($ext, a('jpg', 'jpeg', 'gif', 'png', 'flv', 'swf', 'mp3'))) {
			switch($upload_type) {
				// Standard image
				case(1):
					if (is_uploaded_file($the_temp) && move_uploaded_file($the_temp, $lg_temp)) {
						copy($lg_temp, $lg_path);
						unlink($lg_temp);

						// Is this a new file or a replacement
						$check = $this->Image->findAll("aid = $id AND src = '$file'");

						if (empty($check)) {
							$this->data['Image']['src'] = $file;
							$this->data['Image']['aid'] = $id;
							$this->data['Image']['created_on'] = date('Y-m-d H:i:s');
							$this->Image->save($this->data);
							$image_id = $this->Image->getLastInsertId();
						} else {
							$image_id = $check['Image']['id'];
						}

						// Perform image processing if settings are in place
						// and GD is present
						if ($this->Director->gdVersion() > 0) {
							$this->Director->postProcess($album, $file);
						}
						
						// Perform any template processing
						$this->Director->postProcessTemplates($album, $image_id);						
					}
					break;
				// Thumbnail
				case(2):
					if (is_uploaded_file($the_temp) && move_uploaded_file($the_temp, $tn_temp)) {
						copy($tn_temp, $tn_path);
						unlink($tn_temp);
						if (!$this->data['Album']['tn']) {
							$this->Album->saveField('tn', true);
						}
					}
					break;
				// Album Thumb
				case(3):
					if (is_uploaded_file($the_temp) && move_uploaded_file($the_temp, $thumb_temp)) {
						copy($thumb_temp, $thumb_path);
						unlink($thumb_temp);
						$for_db = 'album-thumbs/' . 'album-' . $id . '.' . $ext; 
						$this->Album->saveField('aTn', $for_db);
					}
					break;
				// Audio	
				case(4):
					if (is_uploaded_file($the_temp) && $this->Director->setPerms(AUDIO)) {
						$a_tmp = AUDIO . DS . $file . '.tmp';
						move_uploaded_file($the_temp, $a_tmp);
						copy($a_tmp, AUDIO . DS . $file);
						unlink($a_tmp);
						$this->Album->saveField('audioFile', $file);
					}
					break;
			}
		}

		// Reset umask
		umask($old_mask);
		
		// Exit with some empty space so onComplete always fires in flash/Mac
		exit(' ');
	}
}

?>