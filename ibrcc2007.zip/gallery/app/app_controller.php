<?php

class AppController extends Controller {
	var $components = array('Director', 'RequestHandler');
	
	////
	// Make sure database connects successfully
	////
	function __construct() {
	        parent::__construct();               
	
		if (!INSTALLING) {
			loadModel('ConnectionManager');
	        $db =& ConnectionManager::getDataSource('default');
	        if (empty($db->connection)) {           
				$this->webroot = str_replace('index.php/', '', BASE_URL . '/app/webroot/');
				$this->pageTitle = 'Database Connection Error';
	            $this->viewPath = 'errors';
	            $this->render('db_connection_failed');
	            exit;
	        }
		}
	}
	
	////
	// Catch missing table for pre 1.0.6 installs
	////
	function appError($method, $params) {
		switch($method) {
			case 'missingTable':
				$go = '';
				$mia = $params[0]['table'];
				if (preg_match('/account/', $mia)) { $go .= '/upgrade'; }
				header('Location: ' . DIR_HOST . '/index.php?/install' . $go);
				exit;
				break;
		}
	}
	
	////
	// Session check
	////
    function checkSession() {	
        if ($this->Session->check('User')) {
			$this->account = $this->Director->fetchAccount();
			if ($this->account['Account']['version'] != DIR_VERSION) {
				$this->redirect("/install/upgrade");
				exit;
			}
			// As of 1.0.9, all users need an email address
			$user = $this->Session->read('User');
			if (empty($user['email']) && $this->action != 'profile' && $this->action != 'update') {
				$check = $this->Director->checkMail($user['id']);
				if (empty($check)) {
					$this->redirect("/users/profile");
				}
			}
			
			$this->set('account', $this->account);
			$this->set('user', $this->Session->read('User'));
			$this->set('shows', $this->Director->fetchShows());
			
			define('MAX_SIZE', $this->Director->returnBytes(ini_get('upload_max_filesize')));
			define('GD_VERSION', $this->Director->gdVersion());
		} else {
            // Force the user to login, record where they wanted to go
			$this->Session->write('redirect_to', $this->here);
            $this->redirect("/users/login");
            exit;
        }
    }

	////
	// Make sure ajax calls are actual ajax calls
	////
	function verifyAjax() {
		if (!$this->RequestHandler->isAjax()) {
			die();
		}
	}
}

?>