<?php 
	////
	// This is a passthrough file. Requests are either 
	// redirected to an existing cache file, or to site/data
	// to render a new fresh XML document.
	////
	
	$gid = 'no';
	$aid = 0;
	
	$path_to_cache = 'xml_cache/images';
	
	if (isset($_GET['gid'])):
		if (!is_numeric($_GET['gid'])) {
			die('Incorrect parameters');
		} else {
			$path_to_cache .= '_gid_' . $_GET['gid'];
			$gid = $_GET['gid'];
		}
	elseif (isset($_GET['album'])):
		if (!is_numeric($_GET['album'])) {
			die('Incorrect parameters');
		} else {
			$path_to_cache .= '_album_' . $_GET['album'];
			$aid = $_GET['album'];
		}
	endif;   

	$path_to_cache .= '.xml';
	$full_path = dirname(dirname(dirname(__FILE__))) . $ds . str_replace('/', $ds, $path_to_cache);

	if (file_exists($full_path)):   
		$tail = substr(md5(uniqid(microtime())), 0, 6);
		header("Location: $path_to_cache?$tail");
	else:
		$tail = "$gid/$aid";
		header("Location: index.php?/site/data/$tail"); 
	endif;

?>