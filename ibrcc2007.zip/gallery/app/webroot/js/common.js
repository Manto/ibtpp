// Holds the currently edited image's ID so we can do various checks
var current_image_edit = 0;
var cur_size = 175;
var cur_v = 1;

var detect = navigator.userAgent.toLowerCase();
var OS,browser,version,total,thestring;

if (checkIt('konqueror'))
{
	browser = "Konqueror";
	OS = "Linux";
}
else if (checkIt('safari')) browser = "Safari"
else if (checkIt('omniweb')) browser = "OmniWeb"
else if (checkIt('opera')) browser = "Opera"
else if (checkIt('webtv')) browser = "WebTV";
else if (checkIt('icab')) browser = "iCab"
else if (checkIt('msie')) browser = "Internet Explorer"
else if (!checkIt('compatible'))
{
	browser = "Netscape Navigator"
	version = detect.charAt(8);
}
else browser = "An unknown browser";

if (!version) version = detect.charAt(place + thestring.length);

if (!OS)
{
	if (checkIt('linux')) OS = "Linux";
	else if (checkIt('x11')) OS = "Unix";
	else if (checkIt('mac')) OS = "Mac"
	else if (checkIt('win')) OS = "Windows"
	else OS = "an unknown operating system";
}

function checkIt(string)
{
	place = detect.indexOf(string) + 1;
	thestring = string;
	return place;
}

function widont(str) {
	space = str.lastIndexOf(' ');
	if (space == -1) {
		return str;
	} else {
		return str.substr(0, space) + '&nbsp;' + str.substr(space+1);
	}
}

function clear_classes(class_name) {
	var clear_these = document.getElementsByClassName(class_name);
	for (i=0; i < clear_these.length; i++) {
		clear_these[i].className = '';
	}
}

function prev_image() {
	init_message("Loading image for edit...", 1, true);
	lis = $('image-view').getElementsByTagName('LI');
	for (i=0; i < lis.length; i++) {
		if (Element.hasClassName(lis[i], 'current')) {
			if (lis[i-1] == undefined) {
				id = lis[lis.length-1].id.split('image_')[1];
			} else {
				id = lis[i-1].id.split('image_')[1];
			}   
			edit_image(id);
			break;
		}
	}
}

function next_image() { 
	init_message("Loading image for edit...", 1, true);
	lis = $('image-view').getElementsByTagName('LI');
	for (i=0; i < lis.length; i++) {
		if (Element.hasClassName(lis[i], 'current')) {
			if (lis[i+1] == undefined) {
				id = lis[0].id.split('image_')[1];
			} else {
				id = lis[i+1].id.split('image_')[1];
			}   
			edit_image(id);
			break;
		}
	}
}

function hide_image_edit() {
	clear_classes('current');
	Effect.BlindUp('edit-box');
	current_image_edit = 0;
}

function edit_image(id) {
	init_message("Loading image for edit...", 1, false);
  	clear_classes('current');
	var elem = $('image_' + id);
	elem.className = 'current';
	var url = base_url + "pics/edit/" + id;
	var tgt = 'target';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post',
		evalScripts:true,
		onComplete: function() {
			init_message("Loading image for edit...", 2, true);
			var elem = $('edit-box');
			if (elem.style.display == 'none') {
				Effect.BlindDown(elem, { queue: 'end' });        
			}
			new Effect.ScrollTo('container', { offset: -10 });
			current_image_edit = id;
		} }); 
}

function albums_sort_init() {
	if ($('active-albums') == undefined) { return; }
	var check = $('active-albums').getElementsByTagName('LI').length;
	if (check > 1) {
		Sortable.create('active-albums',
			{overlap:'vertical', constraint: 'vertical',
			 onUpdate:function(){
				var keys = Sortable.serialize('active-albums');
				var url = base_url + "albums/order";
				var myAjax = new Ajax.Request(url, {method: 'post', parameters: keys});
			 }
		});             
	}
	if (check == 1) {
		Element.removeClassName($('active-albums').getElementsByTagName('LI')[0], 'sort');
	}
}

function clear_thumbs(id) {
	_confirm("Are you sure you want to clear your thumbnails for this&nbsp;album?", 'clear_thumbs_exe', id);
}

function clear_thumbs_exe(id) {
	init_message('Clearing thumbs...', 1, false)
	var url = base_url + "albums/clear_thumbs";
	var params = 'data[Album][id]=' + id;
	var tgt = 'processing';
	var myAjax = new Ajax.Updater(tgt, url, { 
		method: 'post', 
		parameters: params,
		onComplete: function () {
			init_message('Clearing thumbs...done', 2, true)
		}
	});    
}

function refresh_gen_panes(id) {
	var url = base_url + "albums/refresh_generate_pane/" + id;
	var tgt = 'processing';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post', 
		onSuccess: function() {
			init_message('Images processed...done', 2, true);
		},
		onComplete: function() { register_generate_helpers(); }
	});
}

function prefill_links(id, form) {
	$('links-button').disabled = true;     
	$('links-clear-button').disabled = true;
	$('links-messenger').innerHTML = 'Filling links...';
	$('links-messenger').style.display = 'inline';
	var url = base_url + "pics/links/" + id;
	var params = 'data[Album][link_template]=' + $F('link');
	var myAjax = new Ajax.Request(url, { 
		method: 'post', 
		parameters: params, 
		onSuccess: function() { 
			$('links-messenger').innerHTML = 'Links filled!';
			window.setTimeout("kill_messenger('links-messenger')", 2000);
			$('links-button').disabled = false;
			$('links-clear-button').disabled = false;
			if ($('link-clear').style.display == 'none') 
				Effect.BlindDown('link-clear');
	    } });
}

function clear_links(id) {
	$('links-button').disabled = true; 
	$('links-clear-button').disabled = true;
	$('links-messenger').innerHTML = 'Clearing links...';
	$('links-messenger').style.display = 'inline';
	var url = base_url + "pics/links/" + id;
	var params = 'data[Album][link_template]=0';
	var myAjax = new Ajax.Request(url, { 
		method: 'post', 
		parameters: params, 
		onSuccess: function() { 
			$('link').options[0].selected = true;
			$('links-messenger').innerHTML = 'Links cleared!';
			window.setTimeout("kill_messenger('links-messenger')", 2000);
			$('links-button').disabled = false;
			$('links-clear-button').disabled = false;
			window.setTimeout("new Effect.BlindUp('link-clear')", 1000);
		} });
}

function clear_messenger_classes() {
	var elem_p = $('messenger-span');
	Element.removeClassName(elem_p, 'hourglass');
	Element.removeClassName(elem_p, 'accept');
	Element.removeClassName(elem_p, 'exclamation');
	Element.removeClassName(elem_p, 'stop');
}                                                  

function fill_cap_tag(val) {
	var previous_val = $F('AlbumCaptionTemplate');
	if (previous_val != '')
		previous_val += ' ';
	$('AlbumCaptionTemplate').innerHTML = previous_val + val;
} 

function fill_title_tag(val) {
	var previous_val = $F('AlbumTitleTemplate');
	if (previous_val != '')
		previous_val += ' ';
	$('AlbumTitleTemplate').value = previous_val + val;
}

function prefill_titles(id) {
	$('title-button').disabled = true;
	$('title-clear-button').disabled = true;
	$('title-messenger').innerHTML = 'Filling titles...';
	$('title-messenger').style.display = 'inline';
	var url = base_url + "pics/titles/" + id;
	var params = 'data[Album][title_template]=' + $F('AlbumTitleTemplate');
	var myAjax = new Ajax.Request(url, { 
		method: 'post', 
		parameters: params, 
		onSuccess: function() { 
			$('title-messenger').innerHTML = 'Titles filled!';
			window.setTimeout("kill_messenger('title-messenger')", 2000);
			$('title-button').disabled = false;
			$('title-clear-button').disabled = false;
			if ($('title-clear').style.display == 'none') 
				Effect.BlindDown('title-clear');
	    } });
}

function clear_titles(id) {
	$('title-button').disabled = true;
	$('title-clear-button').disabled = true;
	$('title-messenger').innerHTML = 'Clearing titles...';
	$('title-messenger').style.display = 'inline';
	var url = base_url + "pics/titles/" + id;
	var params = 'data[Album][title_template]=';
	var myAjax = new Ajax.Request(url, { 
		method: 'post', 
		parameters: params, 
		onSuccess: function() { 
			$('AlbumTitleTemplate').value = '';
			$('title-messenger').innerHTML = 'Titles cleared!';
			window.setTimeout("kill_messenger('title-messenger')", 2000);
			$('title-button').disabled = false;
			$('title-clear-button').disabled = false;
			window.setTimeout("new Effect.BlindUp('title-clear')", 1000);
		} });
}

function prefill_captions(id) {
	$('captions-button').disabled = true;
	$('captions-clear-button').disabled = true;
	$('captions-messenger').innerHTML = 'Filling captions...';
	$('captions-messenger').style.display = 'inline';
	var url = base_url + "pics/captions/" + id;
	var params = 'data[Album][caption_template]=' + $F('AlbumCaptionTemplate');
	var myAjax = new Ajax.Request(url, { 
		method: 'post', 
		parameters: params, 
		onSuccess: function() { 
			$('captions-messenger').innerHTML = 'Captions filled!';
			window.setTimeout("kill_messenger('captions-messenger')", 2000);
			$('captions-button').disabled = false;
			$('captions-clear-button').disabled = false;
			if ($('caption-clear').style.display == 'none') 
				Effect.BlindDown('caption-clear');
	    } });
}

function clear_captions(id) {
	$('captions-button').disabled = true;
	$('captions-clear-button').disabled = true;
	$('captions-messenger').innerHTML = 'Clearing captions...';
	$('captions-messenger').style.display = 'inline';
	var url = base_url + "pics/captions/" + id;
	var params = 'data[Album][caption_template]=';
	var myAjax = new Ajax.Request(url, { 
		method: 'post', 
		parameters: params, 
		onSuccess: function() { 
			$('AlbumCaptionTemplate').value = '';
			$('captions-messenger').innerHTML = 'Captions cleared!';
			window.setTimeout("kill_messenger('captions-messenger')", 2000);
			$('captions-button').disabled = false;
			$('captions-clear-button').disabled = false;
			window.setTimeout("new Effect.BlindUp('caption-clear')", 1000);
		} });
}

function update_show_tn(val, aid) {
	if (val)
		val = 1;
	else
		val = 0;
	var params = 'data[Album][tn]=' + val; 
	var url = base_url + "albums/update/" + aid;
	var myAjax = new Ajax.Request(url, {
		method: 'post',
		parameters: params 
	});
}

function update_show_headers(val, aid) {
	if (val)
		val = 1;
	else
		val = 0;
	var params = 'data[Album][show_headers]=' + val;
	var url = base_url + "albums/update/" + aid;
	var myAjax = new Ajax.Request(url, {
		method: 'post',
		parameters: params 
	});
}

function update_album(form, id) {
	if ($F('AlbumName') == '') {
		init_message('Album name cannot be blank.', 3, false);
		return false;
	}
	$('save-button').disabled = true;
	$('album-messenger').innerHTML = '<small>Saving...</small>';
	$('album-messenger').style.display = 'inline';
	var allNodes = Form.serialize(form);
	var url = base_url + "albums/update/" + id;
	var tgt = 'album-name';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post',
		parameters: allNodes, 
		onSuccess: function() {
			$('album-messenger').innerHTML = '<small>Album updated!</small>';
			window.setTimeout("kill_messenger('album-messenger')", 2000);
			$('save-button').disabled = false;
			} 
		});
}

function update_dg_name(form, id) {
	if ($F('GalleryName') == '') {
		init_message('Gallery name cannot be blank.', 3, false);
		return false;
	}
	$('dg-name-btn').disabled = true;
	$('dg-messenger').innerHTML = '<small>Saving...</small>';
	$('dg-messenger').style.display = 'inline';
	var allNodes = Form.serialize(form);
	var url = base_url + "galleries/update/" + id;
	var tgt = 'album-name';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post',
		parameters: allNodes, 
		onSuccess: function() {
			$('dg-messenger').innerHTML = '<small>Gallery name updated!</small>';
			window.setTimeout("kill_messenger('dg-messenger')", 2000);
			$('dg-name-btn').disabled = false;
			} 
		});
}

function add_dynamic_link(did, aid) {
	var params = 'did=' + did + '&aid=' + aid;
	var url = base_url + "galleries/link/" + did + "/" + aid;
	var tgt = 'fill';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post', 
		parameters: params, 
		onSuccess: function() {    
			window.setTimeout("dynamic_sort_init()", 500);
		} 
	});
}

function delete_dynamic_link(did, aid) {
	var params = 'id=' + did + '&aid=' + aid;
	var url = base_url + "galleries/delink";
	var tgt = 'fill';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post', 
		parameters: params, 
		onSuccess: function() {      
			window.setTimeout("dynamic_sort_init()", 500);
		} 
	});
}

function dynamic_sort_init() {
	if ($('sort') == undefined) {
		check = 0;
	} else {
		var check = $('sort').getElementsByTagName('LI').length;
	}
	$('albums-count').innerHTML = 'No. of albums: ' + check;
	if (check == 1) {
		Element.removeClassName($('sort').getElementsByTagName('LI')[0], 'sort');
	} else if (check > 1) {
		Sortable.create('sort',
			{overlap:'vertical', constraint: 'vertical', tag: 'li',
			 onUpdate:function(){
				var keys = Sortable.serialize('sort');
				var url = base_url + "tags/order";
				var myAjax = new Ajax.Request(url, {method: 'post', parameters: keys});
			 }
		});
	}
}

function save_image(form, id) {
	$('save-button').disabled = true;
	$('image-messenger').innerHTML = '<small>Saving image...</small>';
	$('image-messenger').style.display = 'inline';
	var allNodes = Form.serialize(form);
	var url = base_url + "pics/update/" + id;
	var tgt = 'dummy';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post', 
		parameters: allNodes, 
		onSuccess: function() { 
			$('save-button').disabled = false;
			$('image-messenger').innerHTML = '<small>Image saved!</small>';
			window.setTimeout("kill_messenger('image-messenger')", 2000);
		} 
	});
}

function send_pass(f) {
	if ($F('UserCred') == '') {
		init_message("Please enter your username or email address.", 3, false);
		return false;
	}
	$('send').disabled = true;
	var tgt = 'fill';
	var url = base_url + 'users/send_password';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post', 
		parameters: Form.serialize(f)
	});
	
}

function update_profile(form, id) {
	if ($('UserUsr').value == '') {
		init_message("Username cannot be empty!", 3, false);
		return false;
	}
	if ($('UserEmail').value == '') {
		init_message("Email cannot be empty!", 3, false);
		return false;
	}
	if ($('pass1').value != $('pass2').value) {
		init_message("Passwords don't match!", 3, false);
		return false;
	} else {
		$('user-messenger').innerHTML = '<small>Saving...</small>';
		$('user-messenger').style.display = 'inline';
		$('save-button').disabled = true;
		var allNodes = Form.serialize(form);
		var url = base_url + "users/update/" + id;
		var myAjax = new Ajax.Request(url, {
			method: 'post',
			parameters: allNodes, 
			onSuccess: function() {
				$('user-messenger').innerHTML = '<small>Profile updated!</small>';
				window.setTimeout("kill_messenger('user-messenger')", 2000);
				new Effect.BlindUp('password');
				$('save-button').disabled = false;
				$('pass1').value = '';
				$('pass2').value = '';
				} 
			});  
	}
}

function update_user_perms(elem, id) {
	var new_val = elem.options[elem.selectedIndex].value;
	var url = base_url + "users/update";
	var params =  'data[User][perms]=' + new_val + '&data[User][id]=' + id;
	var myAjax = new Ajax.Request(url, {
		method: 'post', 
		parameters: params, 
		onSuccess: function() { 
			init_message('User updated successfully...', 2, true);
		} 
	});
}

function delete_user(id) {
	_confirm("Are you sure you want to delete this user?", 'delete_user_exe', id);
}  

function delete_user_exe(id) {
	init_message('Deleting User...', 1, false)
	var url = base_url + "users/delete";
	var params = 'data[User][id]=' + id;
	var tgt = 'fill';
	var myAjax = new Ajax.Updater(tgt, url, { method: 'post', parameters: params,
	 	onComplete: function () {
			init_message('Deleting User...Done', 2, true)
	}});                
}

function add_album(form) {
	if ($F('AlbumName') == '') {
		init_message('Please give the album a name.', 3, false);
		Form.enable(form);
		return false;
	}
	init_message('Adding album...', 1, false);
	Effect.BlindUp('add-album');
	var allNodes = Form.serialize(form);
	var url = base_url + "albums/create";
	tgt = "dummy";
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post',
		parameters: allNodes,
		insertion: Insertion.Bottom,
		onComplete: function() {
			Form.enable(form);
			Form.reset(form);
		}                    
	});
}

function album_creation_failure() {
	init_message('The album was not added because Director was not able to create the proper directories in the albums folder. Make sure this folder has the necessary permissions and try again.', 3, false);
}

function album_process_failure(path) {
	init_message('Director could not process your images because it does not have the proper permissions on this album\'s directory. Make sure the following directory is writable by the web&nbsp;server:&nbsp;' + path, 3, false);
}

function album_process_failure_empty() {
	init_message('You have not added any images to this album yet.', 3, false);
}

function redirect_new_album(id) {
	location.href = base_url + 'albums/edit/' + id + '/upload';
}

function add_gallery(f) {
	if ($F('GalleryName') == '') {
		init_message("Please give the new gallery a name.", 3, false);
		Form.enable(f);
		return;
	} else {
		init_message('Adding gallery...', 1, false);
		Effect.BlindUp('add-gallery');
		var params = Form.serialize(f);
		var url = base_url + "galleries/create";
		var tgt = 'galleries';
		var myAjax = new Ajax.Updater(tgt, url, {
			method: 'post', 
			parameters: params, 
			onSuccess: function() {
				init_message('Adding gallery...done', 2, true);
				Form.enable(f);
				Form.reset(f);
			} 
		});
	}
}

function add_slideshow(form) {
	if ($F('SlideshowName') == '') {
		init_message('Please give the slide show a name.', 3, false);
		Form.enable(form);
		return false;
	}
	
	if ($F('SlideshowUrl') == '') {
		init_message('Please give the URL to the slide show.', 3, false);
		Form.enable(form);
		return false;
	}
	
	init_message('Adding slide show...', 1, false);
	Effect.BlindUp('add-show');	
	var allNodes = Form.serialize(form);
	var url = base_url + "slideshows/create";
	var tgt = 'slideshows';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post',
		parameters: allNodes, 
		onSuccess: function() {
			init_message('Adding slide show...done', 2, true);
			Form.enable(form);
			Form.reset(form);
			}                    
		});
}

function toggle_album_active(id, new_val) {
	if (new_val == 1)
		init_message('Activating album...', 1, false);
	else
		init_message('Inactivating album...', 1, false);
	var url = base_url + "albums/toggle/" + id;
	var params = 'value=' + new_val;
	var tgt = 'albums';
	var myAjax = new Ajax.Updater(tgt, url, {method: 'post', parameters: params,
		onComplete: function() {
			if (new_val == 1)
				init_message('Activating album...done', 2, true);
			else
				init_message('Inactivating album...done', 2, true); 
			window.setTimeout("albums_sort_init()", 500);
		}});
}

function init_message(msg, status, autokill, progress) {
	var progress = (progress == null) ? false : progress;
	var elem_p = $('messenger-span');
	var elem = $('messenger-wrap');
	if (msg != '') {    
		msg = widont(msg);
		clear_messenger_classes();
		switch(status) {
			case(1):
				Element.addClassName(elem_p, 'hourglass');
				break;    
			case(2):
				Element.addClassName(elem_p, 'accept');
				break;
			case(3):
				Element.addClassName(elem_p, 'exclamation');
				msg += '<br /><input type="button" value="Ok" onclick="kill_messenger_quick(\'\'); this.parentNode.removeChild(this);" />'
				break;
		}          
		if (progress) {
			Element.show("progress_wrap");
		} else {
			Element.hide("progress_wrap");
			$('progress').style.width = 0 + '%';
		}
		elem_p.innerHTML = msg;
	}
	Effect.Appear(elem, { duration: 0.1 });
	if (autokill)
		window.setTimeout("kill_messenger('')", 1000);
}

function kill_messenger(name) {
	if (name == '')
		name = 'messenger-wrap';
	Effect.Fade(name, { duration: 0.1, queue: 'end' });
}

function kill_messenger_quick(name) {
	if (name == '')
		name = 'messenger-wrap';
	Element.hide(name);
}

function _confirm(msg, action, arg) {
	clear_messenger_classes();
	Element.addClassName($('messenger-span'), 'stop');     
	if (isNaN(arg)) {
		pad = '\'';
	} else {
		pad = '';
	}
	msg += '<br /><input type="button" value="Ok" onclick="' + action + '(' + pad + arg + pad + ');" /> <input type="button" value="Cancel" onclick="kill_messenger_quick(\'\'); return false;" />';
	$('messenger-span').innerHTML = msg;
	Effect.Appear('messenger-wrap', { duration: 0.1 });   
}

function delete_album(id) {
	_confirm("This will delete the album from the database and from your server. Are you sure you want to do&nbsp;this?", 'delete_album_exe', id);
}                                                                                                                                             

function delete_album_exe(id) {
	init_message('Deleting...', 1, false);
	var url = base_url + "albums/delete";
	var params = 'data[Album][id]=' + id;
	var tgt = 'albums';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post', 
		parameters: params, 
		onSuccess: function() { init_message('Album deleted...', 2, true) },
		onComplete: function() { albums_sort_init(); }
	});
}

function delete_slideshow(id) {
	_confirm("Are you sure you want to delete the link to this&nbsp;slide&nbsp;show?", 'delete_slideshow_exe', id);
}

function delete_slideshow_exe(id) {
	init_message('Deleting...', 1, false);
	var url = base_url + "slideshows/delete";
	var params = 'id=' + id;
	var tgt = 'slideshows';
	var myAjax = new Ajax.Updater(tgt, url, {method: 'post', parameters: params, onComplete: function() { init_message('Slide show deleted...', 2, true) } });
}

function delete_dynamic_gallery(id, refer) {                                                                                               
	_confirm("This will delete this gallery and all of the links created within it. Are&nbsp;you&nbsp;sure?", 'delete_dynamic_gallery_exe', id);
}

function delete_dynamic_gallery_exe(id) {
	init_message('Deleting gallery...', 1, false)
	var params = 'id=' + id;
	var url = base_url + "galleries/delete";
	var tgt = 'galleries';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post', 
		parameters: params, 
		onSuccess: function() {     
			init_message('Deleting gallery...done', 2, true);
		} 
	});
}

function generate_thumbs(form) {
	var w = form.width.value;
	var h = form.height.value;

	if (w == '') {
		init_message('Please enter the maximum width for your thumbnails!', 3, false);
		return false;
	}
	
	if (h == '') {
		init_message('Please enter the maximum height for your thumbnails!', 3, false);
		return false;
	} 
	init_message('Generating thumbnails', 1, false, true);
	return true;
}

function process_images(form) {
	var w = form.width.value;
	var h = form.height.value;
	
	if (w == '') {
		init_message('Please enter the maximum width for your images!', 3, false);
		return false;
	}
	
	if (h == '') {
		init_message('Please enter the maximum height for your images!', 3, false);
		return false;
	}  
	
	init_message('Processing images', 1, false, true);
	return true;
}

function toggle_preview(tgt) { 
	if (tgt != '') {
		var elem = $(tgt);
	}
	var elems = ['preview-select', 'preview-edit']; 
	for (i=0; i< 2; i++) {
		if (Element.visible(elems[i])) {
			new Effect.Fade(elems[i], { duration: 0.4 });
			if (tgt != '' && tgt != elems[i]) { 
				new Effect.Appear(elem, { duration: 0.4, queue: 'end' }); 
			}
			return;
		}
	} 
	if (tgt != '') {
		new Effect.BlindDown(elem, { duration: 0.4, queue: 'end' }); 
	}
}

function designate_preview(img, aid) {
	init_message('Setting album preview...', 1, false);
	if (img == '') {
		toggle_preview('');
	}
	var url = base_url + "albums/update/" + aid + '/preview';
	var params = 'data[Album][aTn]=' + img;
    var tgt = 'preview_pane';
	var myAjax = new Ajax.Updater(tgt, url, { 
		method: 'post', 
		parameters: params,
		onSuccess: function () {
			init_message('Setting album preview...done', 2, true);
		} 
				
	});
}

function generate_preview(form) {
	var w = form.width.value;
	var h = form.height.value;

	if (w == '') {
		init_message('Please enter the maximum width for your preview!', 3, false);
		return false;
	}
	
	if (h == '') {
		init_message('Please enter the maximum height for your preview!', 3, false);
		return false;
	}
	
	init_message('Generating preview...', 1, false);

	var url = base_url + "albums/preview";
	var params = Form.serialize(form);
    var tgt = 'preview_pane';
	var myAjax = new Ajax.Updater(tgt, url, { 
		method: 'post', 
		parameters: params,
		onComplete: function() { init_message('Generating preview...done', 2, true); }
	});
}

function delete_image(id) {
	_confirm('This will delete the image from this album and from the server. Are you sure you want to continue?', 'delete_image_exe', id);
}

function delete_image_exe(id) {
	init_message('Deleting image...', 1, false)
	var url = base_url + "pics/delete";
	var params = 'data[Image][id]=' + id;
	var tgt = 'dummy';
	var myAjax = new Ajax.Updater(tgt, url, {
		method: 'post',
		parameters: params,
		onComplete: function() {
			Effect.Fade('image_' + id);
			Element.removeClassName($('counter_' + id), 'counter');
			Element.addClassName($('counter_' + id), 'counter-off');
			update_img_order();
			if (current_image_edit == id)
				hide_image_edit();
			init_message('Image deleted.', 2, false);
			window.setTimeout("kill_messenger('')", 2000);
		} 
		});
}

function update_preview(url) {
	var bg = '#242424';
	if (url != '') {
		bgImg = 'url(' + url + '?' + random_str(6) + ')';
		$('album-preview').style.backgroundImage = bgImg;
		$('album-preview').style.backgroundPosition = 'center';
		$('album-preview').style.backgroundRepeat = 'no-repeat';
	} else {
		$('album-preview').style.background = bg;
	}
	register_generate_helpers();
}

function random_str(length) {
   chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
   str = "";

   for(x=0;x<length;x++) {
      i = Math.floor(Math.random() * 62);
      str += chars.charAt(i);
   }

   return str;
}

slider_init = true;
sorting = false;

function img_sort_init() {
	if (slider_init) {
		var demoSlider = new Control.Slider('handle1','track1', {
			axis:'horizontal',
			minimum: 0,
			maximum:200,
		    alignX: -8,
			increment: 2,
			sliderValue: 200 }
			);               
			
		demoSlider.options.onSlide = function(value){
		  scaleIt(value);
		}

		demoSlider.options.onChange = function(value){
		  scaleIt(value);
		}
		v_cooked = getCookie('v');
		if (v_cooked == null) {
			v_cooked = 1;
	    }      
		demoSlider.setValue(v_cooked);
		slider_init = false;
		Effect.BlindDown($('image-view'), { queue: 'end' });
		kill_messenger(''); 
   	}   
		Position.includeScrollOffsets = true;
		if (sorting) {
	    	Sortable.create('image-view', {
			overlap:'horizontal',
			constraint: false, 
			handle: 'scale-image',
			scroll: window,
			 onUpdate:function() {
				update_img_order();
			 }     
			}); 
		}                           
}

function scaleIt(v) {
	setCookie('v', v);    
	var scalePhotos = document.getElementsByClassName('scale-image');
	floorSize = .7;
	ceilingSize = 1.0;
	v = floorSize + (v * (ceilingSize - floorSize)); 
	size = v*175;
	cur_size = size;
  	cur_v = v;
  	var len = scalePhotos.length;
    var elem;          
	size = size + 'px';
  	for (i=0; i < len; i++) {
		elem = scalePhotos[i];
		elem.style.width = size;
		if (browser != 'Safari')
			elem.getElementsByTagName('DIV')[0].style.height = size;
		elem.style.height = size;
		elem.parentNode.style.width = size;
	} 
}

function update_img_order() {
	renum_images();
	if (!sorting) {
		Sortable.create('image-view');
	}
	var keys = Sortable.serialize('image-view');
	var url = base_url + "pics/order";
	var myAjax = new Ajax.Request(url, { 
		method: 'post',
		parameters: keys
	});
	if (!sorting) {
		Sortable.destroy('image-view');
	}
}      

function renum_images() {
	var elem = document.getElementsByClassName('counter');
	var total = elem.length;
	$('img_count').innerHTML = total;
	for (i=0; i < total; i++) {
			elem[i].innerHTML = (i+1) + '/' + total;
	}
}

function setCookie(name, value, expires, path, domain, secure) {
    document.cookie= name + "=" + escape(value) +
        ((expires) ? "; expires=" + expires.toGMTString() : "") +
        ((path) ? "; path=" + path : "") +
        ((domain) ? "; domain=" + domain : "") +
        ((secure) ? "; secure" : "");
}

function getCookie(name) {
    var dc = document.cookie;
    var prefix = name + "=";
    var begin = dc.indexOf("; " + prefix);
    if (begin == -1) {
        begin = dc.indexOf(prefix);
        if (begin != 0) return null;
    } else {
        begin += 2;
    }
    var end = document.cookie.indexOf(";", begin);
    if (end == -1) {
        end = dc.length;
    }
    return unescape(dc.substring(begin + prefix.length, end));
}

function add_user(f) {
	if (validate_user_invite()) {
		var allNodes = Form.serialize(f);
		var url = base_url + "users/create";
		var tgt = 'fill';
		var myAjax = new Ajax.Updater(tgt, url, {
			method: 'post', 
			parameters: allNodes, 
			onSuccess: function() {
				Form.reset(f);
				init_message('User added (an email with instructions was sent as well)...', 2, false);
				window.setTimeout("kill_messenger('')", 3000);
			} 
		});
	}
}

function validate_user_invite() {
	
	if ($F('UserUsr') == '') {
		init_message("Please enter the recipient's email", 3, false);
		return false;
	}
	if ($F('from_email') == '') {
		init_message("Please enter your email for the 'from' address", 3, false);
		return false;
	}
	   
	return true;
}

function set_defaults_tn(theForm, id) {
	var w = theForm.width.value;
	var h = theForm.height.value;
	
	if (w == '') {
		init_message('Please enter the maximum width for your thumbnails!', 3, false);
		return false;
	}
	
	if (h == '') {
		init_message('Please enter the maximum height for your thumbnails!', 3, false);
		return false;
	}
	
	init_message('Setting thumbnail defaults...', 1, false);
	var allNodes = Form.serialize(theForm);
	var url = base_url + "accounts/update_defaults/" + id;
	var myAjax = new Ajax.Updater('defaults', url, {
		method: 'post', 
		parameters: allNodes, 
		onSuccess: function() { 
			init_message('Setting thumbnail defaults...done', 2, true);
		},
		onComplete: function() { register_generate_helpers(); } 
	});
	
}

function set_defaults_lg(theForm, id) {
	var w = theForm.width.value;
	var h = theForm.height.value;

	if (w == '') {
		init_message('Please enter the maximum width for your large images!', 3, false);
		return false;
	}
	
	if (h == '') {
		init_message('Please enter the maximum height for your large images!', 3, false);
		return false;
	}
	
	init_message('Setting large image defaults...', 1, false);
	var allNodes = Form.serialize(theForm);
	var url = base_url + "accounts/update_defaults/" + id;
	var myAjax = new Ajax.Updater('defaults', url, {
		method: 'post', 
		parameters: allNodes, 
		onSuccess: function() { 
			init_message('Setting large image defaults...done', 2, true);
		},
		onComplete: function() { register_generate_helpers(); }
	});
	
}

function update_director_options(val, param, id) {
	if (val)
		val = 1;
	else
		val = 0;
	var params = param + '=' + val;
	var url = base_url + "accounts/update/" + id;
	var myAjax = new Ajax.Request(url, {
		method: 'post',
		parameters: params 
	});
}

function update_audio(id) {
	$('save-button').disabled = true;
	$('audio-messenger').innerHTML = '<small>Saving...</small>';
	$('audio-messenger').style.display = 'inline';
	var allNodes = Form.serialize("theForm");
	var url = base_url +  "albums/update/" + id;
	var myAjax = new Ajax.Request(url, {
		method: 'post',
		parameters: allNodes, 
		onSuccess: function() {
			$('audio-messenger').innerHTML = '<small>Album audio updated!</small>';
			window.setTimeout("kill_messenger('audio-messenger')", 2000);
			$('save-button').disabled = false;
			} 
		});
}

function register_generate_helpers() {
	Event.observe('lg_wh_help', 'mouseover', function(e) { helper('Enter a maximum value for the width and height of your slide show images. How these values are used depends on the scale setting.', e)});
	Event.observe('lg_q_help', 'mouseover', function(e) { helper('Enter a quality setting (1-100) for your images.', e)});
	Event.observe('lg_scale_help', 'mouseover', function(e) { helper('Choose whether you would like your images to be scaled proportionally or scaled and cropped to the dimensions exactly.', e)});
	Event.observe('lg_wh_help', 'mouseout', kill_helper);
	Event.observe('lg_q_help', 'mouseout', kill_helper);
	Event.observe('lg_scale_help', 'mouseout', kill_helper);
	Event.observe('tn_wh_help', 'mouseover', function(e) { helper('Enter a maximum value for the width and height of your thumbnails. How these values are used depends on the scale setting.', e)});
	Event.observe('tn_q_help', 'mouseover', function(e) { helper('Enter a quality setting (1-100) for your thumbnails.', e)});
	Event.observe('tn_scale_help', 'mouseover', function(e) { helper('Choose whether you would like your thumbnails to be scaled proportionally or scaled and cropped to the dimensions exactly.', e)});
	Event.observe('tn_wh_help', 'mouseout', kill_helper);
	Event.observe('tn_q_help', 'mouseout', kill_helper);
	Event.observe('tn_scale_help', 'mouseout', kill_helper);
	Event.observe('prv_wh_help', 'mouseover', function(e) { helper('Enter a maximum value for the width and height of your preview. How these values are used depends on the scale setting.', e)});
	Event.observe('prv_q_help', 'mouseover', function(e) { helper('Enter a quality setting (1-100) for your preview.', e)});
	Event.observe('prv_scale_help', 'mouseover', function(e) { helper('Choose whether you would like your preview to be scaled proportionally or scaled and cropped to the dimensions exactly.', e)});
	Event.observe('prv_wh_help', 'mouseout', kill_helper);
	Event.observe('prv_q_help', 'mouseout', kill_helper);
	Event.observe('prv_scale_help', 'mouseout', kill_helper);
}

function helper(msg, e) {
	$('helper-p').innerHTML = msg;
	var posx = Event.pointerX(e);
	var posy = Event.pointerY(e);
	
	$('helper').style.top = posy + 10 + 'px';
	$('helper').style.left = posx + 'px';
	Element.show('helper');
}

function kill_helper() {
	Element.hide('helper');
}

function validate_install() {
	if ($F('dbServer') == '') {
		init_message("Please give the address to your MySQL host.", 3, false);
		return false;
	}
	if ($F('dbName') == '') {
		init_message("Please give the database that you want Director to be installed in.", 3, false);
		return false;
	}
	if ($F('dbUser') == '') {
		init_message("Please give the user that Director should use to login to your MySQL host.", 3, false);
		return false;
	}
	if ($F('dbPass') == '') {
		_confirm("You have not given a password so Director will try to login with no password. Is this correct?", 'submit_install_form', '');
		return false
	}                    
	return true;
}

function submit_install_form(str) {
	document.forms[0].submit();
}

function validate_register(){
	if ($F('UserUsr') == '') {
		init_message("Please enter a username.", 3, false);
		return false;
	}
	
	if ($F('UserEmail') == '') {
		init_message("Please enter an email address.", 3, false);
		return false;
	}
	
	if ($F('UserPwd') == '') {
		init_message("Please enter a password.", 3, false);
		return false;
	}
	
	if ($F('UserPwd') != $F('pwd2')) {
		init_message("Your passwords must match.", 3, false);
		return false;
	}
	return true;
}

function rotate_img(id, aid, r) {         
	Effect.BlindUp('the_img');
	init_message('Rotating...', 1, false);
	var url = base_url + "pics/rotate";
	var params = 'data[rotate][id]=' + id + '&data[rotate][deg]=' + r;
	var myAjax = new Ajax.Request(url, { 
		method: 'post', 
		parameters: params, 
		onSuccess: function() {			
			init_message('Rotating...done', 1, true);
			var the_img = $('image_' + id).getElementsByTagName('IMG')[0];
			var img_src = the_img.src;
			var rndNum = Math.random() 
			rndNum = parseInt(rndNum * 1000);
			the_img.src = img_src + '?' + rndNum;
			if (Element.hasClassName(the_img, 'tall')) {
				Element.removeClassName(the_img, 'tall');
				Element.addClassName(the_img, 'wide');
			} else {
				Element.removeClassName(the_img, 'wide');
				Element.addClassName(the_img, 'tall');	
			}
			var the_img = $('the_img').getElementsByTagName('IMG')[0];
			var img_src = the_img.src;
			var rndNum = Math.random() 
			rndNum = parseInt(rndNum * 1000);
			the_img.src = img_src + '?' + rndNum;
			if (Element.hasClassName(the_img, 'tall')) {
				Element.removeClassName(the_img, 'tall');
				Element.addClassName(the_img, 'wide');
			} else {
				Element.removeClassName(the_img, 'wide');
				Element.addClassName(the_img, 'tall');	
			}
			Effect.BlindDown('the_img', { queue: 'end' });
		}
	});
}

var memArgs = new Array();

function change_order_type(id, val, current) {
	memArgs = new Array(id, val);
	if (current == 'manual') {
		_confirm("You are about to automatically order your images.<br />You will lose any manual edits made to this album's&nbsp;image&nbsp;order.", 'change_order_exe', '');
	} else if (val == 'manual') {
		_confirm("You are about to turn off automatic image ordering.<br />Any new images added to this album will require&nbsp;manual&nbsp;ordering.", 'change_order_exe', '');
	} else {
		change_order_exe();
	}
}

function change_order_exe() {
	init_message('Setting album order type and reordering images...', 1, false);
	Effect.BlindUp('image-view');
	var id = memArgs[0];
	var val = memArgs[1];
	memArgs = new Array();
	var url = base_url + "albums/order_type/" + id;
	var params = 'data[Album][sort_type]=' + val;
    var tgt = 'rebuild';
	var myAjax = new Ajax.Updater(tgt, url, { 
		method: 'post', 
		evalScripts: true,
		parameters: params,
		onSuccess: function () {
			init_message('Setting album order type and reordering images...done', 2, true);
		} 
				
	});
}

function focusDelay(id, delay) {
	window.setTimeout(function() { _focus(id) }, delay)
}

function _focus(id) {
	$(id).focus();
}

function init_import() {
	if ($F('GalleryName') == '') {
		init_message('Please give the new gallery a name.', 3, false);
		return false;
	}
	_confirm("Are you sure you want to import this folder now?", 'do_import', '');
}

function do_import() {
	init_message("Importing slide show data...", 1, false);
	var url = base_url + "imports/vandelay";
	var params = Form.serialize('import_form');
	var myAjax = new Ajax.Request(url, {
		method: 'post',
		parameters: params,
		onComplete: function() {
			init_message('Gallery imported...redirecting...', 2, false);
			window.setTimeout(_redirect, 1000, base_url + 'dashboard');
		}
	});
}

function _redirect(url) {
	location.href = url;
}

function fetch_slideshow() {
	window.open($F('ss_select'), 'Slideshow');
}

function toggle_view_btn(val) {
	if (val == 0)
		$('view_ss_btn').disabled = true;
	else
		$('view_ss_btn').disabled = false;
}