var complete = false;
var list_count = 0;
var tn_count = 0;
var audio_count = 0;
var thumb_count = 0;

function browse_for_upload() {
	var opt = $F("upload_type");
	$("_uploader").js_browse(opt);
}

function upload() {
	init_message("Uploading new files...", 1, false, true);
	$("_uploader").js_upload();
	on_progress();
}

function on_select(list, tn_list, thumb_list, audio_list, rejects) {
	list_count = list.length;
	tn_count = tn_list.length;
	audio_count = audio_list.length;
	thumb_count = thumb_list.length;
	
	var tgt = $("file_list");
	if (list_count == 0 && tn_count == 0 && rejects.length == 0 && audio_count == 0 && thumb_count == 0) {
		Effect.BlindUp('files');
	} else if (list_count == 0 && tn_count == 0 && audio_count == 0 && thumb_count == 0 && rejects.length > 0) {
		Effect.BlindUp('files');
		init_message('All of the selected files exceed the maximum size allowed by the server.', 3, false);
	} else {
		var summary = new Array();
		str = '<table id="file_list" border="0" cellspacing="0" cellpadding="5"><tr><th class="left">Name</th><th>Size</th><th>Remove</th></tr>';
		if (list_count > 0) {
			summary.push(list_count + ' full size images');
			str += "<tr><td class=\"left error\" colspan=\"3\">Full size images:</td></tr>";
			for(i = 0; i < list_count; i++) 
			{
				str += "<tr><td class=\"left\">" + list[i].name + "</td><td>" + convert_bits(list[i].size) + "</td><td><a href=\"#\" onclick=\"rm_file('" + list[i].name + "', 1); return false;\">Remove</a></td></tr>";
	    	}
		}
		if (tn_count > 0) {
			summary.push(tn_count + ' thumbnails');
			str += "<tr><td class=\"left error\" colspan=\"3\">Thumbnails:</td></tr>";
			for(i = 0; i < tn_count; i++) 
			{
				str += "<tr><td class=\"left\">" + tn_list[i].name + "</td><td>" + convert_bits(tn_list[i].size) + "</td><td><a href=\"#\" onclick=\"rm_file('" + tn_list[i].name + "', 2); return false;\">Remove</a></td></tr>";
	    	}
		}
		if (thumb_count > 0) {
			summary.push(thumb_count + ' album thumbnail');
			str += "<tr><td class=\"left error\" colspan=\"3\">Album thumbnail:</td></tr>";
			for(i = 0; i < thumb_count; i++) 
			{
				str += "<tr><td class=\"left\">" + thumb_list[i].name + "</td><td>" + convert_bits(thumb_list[i].size) + "</td><td><a href=\"#\" onclick=\"rm_file('" + thumb_list[i].name + "', 3); return false;\">Remove</a></td></tr>";
	    	}
		}
		if (audio_count > 0) {
			summary.push(audio_count + ' audio file');
			str += "<tr><td class=\"left error\" colspan=\"3\">Audio:</td></tr>";
			for(i = 0; i < audio_count; i++) 
			{
				str += "<tr><td class=\"left\">" + audio_list[i].name + "</td><td>" + convert_bits(audio_list[i].size) + "</td><td><a href=\"#\" onclick=\"rm_file('" + audio_list[i].name + "', 4); return false;\">Remove</a></td></tr>";
	    	}
		}
		if (rejects.length > 0) { 
			str += "<tr><td class=\"left error\" colspan=\"3\">The following files exceed the maximum allowed size and will not be uploaded:</td></tr>";
			for(i = 0; i < rejects.length; i++) {
				str += "<tr><td class=\"left\">" + rejects[i].name + "</td><td>" + convert_bits(rejects[i].size) + "</td><td></td></tr>";
	    	}
		}
		str += '</table>';
		$('file_list').innerHTML = str;
		$('summary').innerHTML = summary.join(', ');
		if (!Element.visible('files')) {
			Effect.BlindDown('files');
		}
	}		
}

function on_progress() {
	var progress = $("_uploader").js_check_progress();
	$('progress').style.width = progress + '%';
	if (progress == 100) {
		on_complete();
	} else {
		window.setTimeout(on_progress, 100);
	}
}

function rm_file(file_name, t) {
	$("_uploader").js_remove_file(file_name, t);
}

function on_complete() {
	init_message("Files uploaded...redirecting...", 2, false);
	window.setTimeout(redirect, 2000);
}

function http_error() {
	init_message("An error occured when trying to upload your images. Please read the \"Troubleshooting: Errors when uploading\" portion of the of the user guide for how to fix this issue.", 3, false);
	Effect.BlindUp('files');
}

function redirect() {
	var redir = '';
	if (list_count > 0) {
		redir = "albums/reorder/" + aid + '/' + redir;
	} else if (tn_count > 0 || thumb_count > 0) {
		redir = 'albums/edit/' + aid + '/generate';
	} else {
		redir = 'albums/edit/' + aid + '/audio';
	}
	location.href = base_url + redir;
}

function convert_bits(bytes) {
	kb = bytes/1024;
	if (kb < 1024) {
		return Math.round(kb) + ' KB';
	} else {
		mb = kb/1024;
		return Math.round(mb*10)/10 + ' MB';
	}
	
}