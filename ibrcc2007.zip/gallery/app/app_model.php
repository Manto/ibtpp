<?php

////
// Needed for RSS parsing and shared cache clearing function
////
class AppModel extends Model {
	////
	// Clear cache
	////
	function clearCache($files) {
		umask(0);
		@chmod(XML_CACHE, 0777);
		foreach($files as $file) {
			@unlink(XML_CACHE . DS . $file . '.xml');
		}
	}
}

require_once APP . 'web_model.php';

?>