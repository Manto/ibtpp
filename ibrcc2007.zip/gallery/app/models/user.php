<?php

class User extends AppModel {
    var $name = 'User';
	var $useTable = 'usrs';
}

?>