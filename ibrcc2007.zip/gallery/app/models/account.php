<?php

class Account extends AppModel {
    var $name = 'Account';
	var $useTable = 'account';
}

?>