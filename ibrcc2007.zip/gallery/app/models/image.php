<?php

class Image extends AppModel {
    var $name = 'Image';

	var $belongsTo = array('Album' =>
                           array('className'  => 'Album',
                                 'foreignKey' => 'aid'
                           )
                     );

	////
	// callbacks to clear the cache
	////
	function afterSave() {
		$this->popCache();
		return true;
	}
	
	function beforeDelete() {
		$this->popCache(false);
		return true;
	}
	
	function popCache($save = true) {
		$id = $this->id;
		$image = $this->read();
		$album_id = $image['Album']['id'];
		$this->cacheQueries = false;
		$count = $this->findCount(aa('aid', $album_id));
		if (!$save) { $count -= 1; }
		$this->Album->id = $album_id;
		if ($this->Album->read()) {
			$this->Album->saveField('images_count', $count);
		}
	}
	
	function formTitle($title) {
		$image = $this->read();
		$set_to = str_replace('[img_name]', $image['Image']['src'], $title);
		$this->saveField('title', $set_to);
	}
	
	function formCaption($caption) {
		$image = $this->read();
		$set_to = str_replace('[img_name]', $image['Image']['src'], $caption);
		$this->saveField('caption', $set_to);
	}
	
	function formLink($action, $album) {
		$file_path = ALBUMS . DS . $album['Album']['path'];
		$path = DIR_HOST . '/albums/' . $album['Album']['path'];
		$i = $this->read();
		$src = $i['Image']['src'];
		
		switch($action) {
			// Clear all
			case(0):
				$this->saveField('link', '');
				$this->saveField('target', 0);
				break;
				
			// JS chromeless popup
			case(3):
				$this->log($file_path . DS . 'hr' . DS . $src);
				if (file_exists($file_path . DS . 'hr' . DS . $src)) {
					$url = $path . '/hr/' . $src;
					$specs = getimagesize($file_path . DS . 'hr' . DS . $src);
				} else {
					$url = $path . '/lg/' . $src;
					$specs = getimagesize($file_path . DS . 'lg' . DS . $src);
				}
				
				$full = DIR_HOST . '/popup.php?src=' . $url . '&w=' . $specs[0] . '&h=' . $specs[1] . '&title=' . $src;
				$this->data['Image']['link'] = "javascript:if (window.NewWindow) { NewWindow.close(); }; NewWindow=window.open('$full','myWindow','width={$specs[0]},height={$specs[1]},toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,titlebar=no');NewWindow.focus(); void(0);";
				$this->save($this->data);
				break;
			
			// Standard link to highest available rez
			default:
				$this->data['Image']['target'] = $action - 1;
				
				if (file_exists($file_path . DS . 'hr' . DS . $src)) {
					$this->data['Image']['link'] = $path . '/hr/' . $src;
				} else {
					$this->data['Image']['link'] = $path . '/lg/' . $src;
				}
				
				$this->save($this->data);
				break;
		}
	}
}

?>