<?php

class Tag extends AppModel {
    var $name = 'Tag';
	var $useTable = 'dynamic_links';

	var $belongsTo = array('Album' =>
                           array('className'  => 'Album',
                                 'foreignKey' => 'aid'
                           ),
						   'Gallery' =>
						   array('className'  => 'Gallery',
								 'foreignKey' => 'did'
						   )
                     );

	////
	// callbacks to clear the cache
	////
	function afterSave() {
		$this->popCache();
		return true;
	}
	
	function beforeDelete() {
		$this->popCache();
		return true;
	}
	
	function popCache() {
		$id = $this->id;
		$tag = $this->read();
		$targets = array("images_gid_{$tag['Tag']['did']}");
		$this->clearCache($targets);
	}
}

?>