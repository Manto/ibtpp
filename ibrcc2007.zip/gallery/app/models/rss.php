<?php

class Rss extends WebModel 
{
    var $name = 'Rss';
    var $cacheExpires = '+2 hours';
    var $cacheFolder = 'web/rss';    
    
    /**
     * The Lazy Mode is a way to optimize RSS parsing time by a factor of ~30x.
     * This is accomblished by assuming the stuff inside nodes that don't nest any other nodes, contain no line breaks
     * 
     * If you experience difficulties with a certain feed, set this mode to false.
     * But so far all feeds I've tested worked with the mode beeing set to true.
     *
     * @var unknown_type
     */
    var $lazyMode = true;
    
    function findAll($feedUrl, $limit = 10, $cacheExpires = null)
    {
        $feed = $this->__parseRSS($this->__getRawRSS($feedUrl, null, $cacheExpires));       
     
        if (count($feed['Items']>$limit))
        {                                
            $feed['Items'] = array_slice($feed['Items'], 0, $limit);
        }

        return $feed;
    }

    function __getRawRSS($feedUrl, $vars = array(), $cacheExpires = null)
    {
        $url = $feedUrl;
        
        $cachePath = $this->cacheFolder.$this->__createCacheHash('.rss', $url, $vars);

        if (empty($cacheExpires))
            $cacheExpires = $this->cacheExpires;
            
        if (empty($vars))
            $vars = array();
                    
        $rssData = cache($cachePath, null, $cacheExpires);
        
        if (empty($rssData))
        {
            $rssData = cache($cachePath, $this->httpGet($url, $vars));
        }
        
        return $rssData;
    }
    
    /**
     * A simple function for parsing RSS data. Only returns Items for now.
     *
     */
    function __parseRSS($data)
    {
        if (empty($data))
            return array();
    
        $regex = '/\<rss.+version="(.+)".*\>/iUs';
        
        preg_match($regex, $data, $match);
        list($raw, $version) = $match;
                
        if (empty($version))
            $version = '2.0';

        // Check if we have a valid version number
        if (!preg_match('/^[0-9.]+$/iUs', $version))
        {
            trigger_error('WebModel::__parseRSS(): "'.$version.'" is no valid RSS version.');
            return array();
        }
                    
        $rssFunction = '__parseRSS_'.str_replace('.', '_', $version);
                   
        if (method_exists($this, $rssFunction))
        {
            return call_user_func(array(&$this, $rssFunction), $data);
        }
        else 
        {
            trigger_error('WebModel::__parseRSS(): No function for parsing RSS feeds of version "'.$version.'" available.');
            return array();
        }
    }
    
    
    function __parseRSS_2_0($data)
    {       
        // First thing we need to do, is to identify all html/otherwise formated contents
        preg_match_all('/\<\!\[CDATA\[(.+)\]\]\>/iUs', $data, $cdata, PREG_SET_ORDER);


        // Create the md5 hash of the data to parse
        $dataHash = md5($data);
        
        // Now we have to replace them with something that won't confuse our parser, but still keep the array containing their original content
        // [[CDATA:$dataHash:$cdataNum]] should be pretty unique, so we don't have to deal with errors in an rss feed that talks about this replacment
        // method.
        foreach ($cdata as $cdataNum => $cdataItem)
        {
            $data = str_replace($cdataItem[0], '[[CDATA:'.$dataHash.':'.$cdataNum.']]', $data);
        }            
        
        
        // Let's get the information about the channel
        $regex = '/\<channel\>(.+)\<item\>/iUs';
        preg_match($regex, $data, $match);
        if (!empty($match))
        {
            list($raw, $channel) = $match;
            
            $channel = $this->__getNodeFields($channel, $cdata, $dataHash);
        }
        else 
            $channel = array();
        
        // This will get us a list with all Items contained in the feed
        $regex = '/\<item\>(.+)\<\/item\>/iUs';
        
        $matchCount = preg_match_all($regex, $data, $matches, PREG_SET_ORDER);                
        if (empty($matchCount))
        {
            // No items? Nothing to parse.
            $matches = array();        
        }
        else 
        {                            
            $items = array();
            
            // Loop through all Item Matches
            foreach ($matches as $itemNr => $item)
            {   
                // Find all fields in our Item           
                
                $items[$itemNr] = $this->__getNodeFields($item[1], $cdata, $dataHash);
            }
        }
    
        // Return everything
        return array('Channel' => $channel,
                     'Items' => $items);
    }    
    
    function __getNodeFields($rawFields, $cdata = null, $dataHash = null)
    {
        // Lazy Mode allows faster parsing of feeds, check the comment on top of this document for more information
        if ($this->lazyMode==false)
            $fieldRegex = '/\<(.+)(.*)\>(.*)\<\/\\1\>/s';
        else 
            $fieldRegex = '/\<(.+)(.*)\>(.*)\n?\<\/\\1\>/';    
    
        preg_match_all($fieldRegex, $rawFields, $fieldMatches, PREG_SET_ORDER);
        // Loop through those fields
        foreach ($fieldMatches as $fieldMatch)
        {
            // Assign the preg_match_all contents to a couple of variables
            list($raw, $field, $attributes, $value) = $fieldMatch;
            
            // Find CDATA replaced stuff and but it back in.
            preg_match_all('/\[\[CDATA:'.$dataHash.':([0-9]+)\]\]/iUs', $rawFields, $cdataDummies, PREG_SET_ORDER);
            foreach ($cdataDummies as $cdataDummy)
            {
                // Replace CDATA dummies with the actual contents of the cdata field
                $value = str_replace($cdataDummy[0], $cdata[($cdataDummy[1])][1], $value);
            }
            
            // Parse the attributes contained in our Node / ItemField
            $attributes = $this->__getXMLNodeAttributes($attributes);
        
            // Add our news Node to the list of Items.
            $fields[$field] = array('value' => $value,
                                    'attributes' => $attributes);
        }    
        
        return $fields;
    }
    
    function __getXMLNodeAttributes($attributesData)
    {
        if (empty($attributesData))
            return array();
    
        preg_match_all('/ (.+)=(["\'])(.+)\\2/iUs', $attributesData, $attributeMatches, PREG_SET_ORDER);
        
        if (empty($attributeMatches))
            return array();
            
        $attributes = array();
        
        foreach ($attributeMatches as $attribute)
        {
            list($raw, $attributeKey, $enclosure, $attributeValue) = $attribute;
            $attributes[] = array($attributeKey => $attributeValue);
        }
        
        return $attributes;
    }
}

?>