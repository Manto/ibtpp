<?php require("includes/header.php"); ?>

<div class="main">
	<div id="c1" class="column" style="float: left; width: 65%;">
		<div class="header">Asilomar Conference Grounds, Monterey, California</div>
		Asilomar Conference Grounds<sup>&reg;</sup>, known as Monterey Peninsula's "Refuge by the Sea" is located on 107 acres of protected beachfront land, within the quaint and scenic town of Pacific Grove. This year marks the landmark 50-year anniversary of Asilomar State Beach and Conference Grounds as a proud unit of the California State Park system. This special heritage inspires an ongoing commitment for the care and preservation of Asilomar�s flora and fauna � enabling our guests to truly enjoy the natural surroundings of this tranquil retreat.
		<br /><br />
		<div class="header">Accommodations</div>
		What began as a YWCA<sup>&reg;</sup> retreat in 1913 is now a charming ocean-side Monterey beach resort for travelers seeking respite and renewal, and for groups looking for the perfect setting for a productive conference. Asilomar Conference Grounds offers accommodations that are reminiscent of the cozy cabins and lodges of a seaside summer camp.   Our California resort's secluded guest rooms and suites offer tranquility and harmony - a wonderful escape from the demands of everyday life.
		For more information about room types, please visit the lodging page on Asilomar's website <a href="http://www.visitasilomar.com/lodging.aspx" class="redlink" target="_blank">here</a>.
		<br /><br />
		<div class="header">Places of Interest Around Asilomar</div>
<ul>
<li>
<a class="location" href="http://www.montereybayaquarium.org" target="_blank">Monterey Bay Aquarium</a><br />
One of the top aquariums in the United States.
</li>

<li>
<a class="location" href="http://www.carmelcalifornia.org" target="_blank">Carmel California Chamber of Commerce</a>
</li>

<li>
<a class="location" href="http://www.carmelmission.org" target="_blank">Carmel Mission</a><br />
Site of Carmel Mission Basilica and National Shrine of Blessed Junipero Serra
</li>

<li>
<a class="location" href="http://www.golfmonterey.org" target="_blank">Monterey Golf Association</a>
</li>

<li>
<a class="location" href="http://www.pebblebeach.com" target="_blank">Pebble Beach Golf Course</a>
</li>

<li>
<a class="location" href="http://www.oldmonterey.org" target="_blank">Old Monterey Business Association</a><br />
Find out upcoming food, music, and art festivals in the area.
</li>

<li>
<a class="location" href="http://www.montereywines.org" target="_blank">Monterey County Vinters and Growers Association</a><br />
Information on wineries and vineyards in the area.
</li>

<li>
<a class="location" href="http://www.montereyairport.com" target="_blank">Monterey Penisula Airport</a>
</li>

<li>
	<a class="location" href="http://www.montereyinfo.org" target="_blank">Monterey County Convention & Visitors Bureau</a>
</li>

<li>
<a class="location" href="http://www.bigsurcalifornia.org" target="_blank">Big Sur Chamber of Commerce</a><br />
Guide to all lodging, camping, restaurants, gift shops, and art galleries in Big Sur.
</li>

<li>
<a class="location" href="http://www.canneryrow.com" target="_blank">Cannery Row</a>
</li>

<li>
	<a class="location" href="http://www.montereywharf.com" target="_blank">Monterey Wharf</a>
</li>

<li>
<a class="location" href="http://www.steinbeck.org" target="_blank">National Steinbeck Center</a><br />
Located in Salinas, the boyhood hometown of a local Nobel Laureate in Literature.
</li>

<li>
	<a class="location" href="http://www.freemapsandguides.com/Monterey_California.html" target="_blank">Monterey Vacation Travel Guide</a>
</li>

<li>
	<a class="location" href="http://www.ccdaytripper.com" target="_blank">Central Coast Tours</a>
</li>

<li>
	<a class="location" href="http://www.www.adventuresbythesea.com.com" target="_blank">Monterey Kayaking and Bicycle Rentals</a>
</li>

</ul>
	</div>
	<div id="c2" class="column" style="float: left; width: 33%;">
			<div style="margin: 8px;">
			<script type="text/javascript">
				var fadeimages=new Array()
				//SET IMAGE PATHS. Extend or contract array as needed
				fadeimages[0]=["slideshows/main1.jpg", "", ""] //plain image syntax
				fadeimages[1]=["slideshows/main2.jpg", "", ""] //plain image syntax
				fadeimages[2]=["slideshows/main3.jpg", "", ""] //plain image syntax
				fadeimages[3]=["slideshows/main4.jpg", "", ""] //plain image syntax
			 
				new fadeshow(fadeimages, 250, 216, 0, 3000, 0);
			</script>
		</div>
		<div class="box1">
			<div class="header" style="color: #fff; padding:0px 0px 0px 15px;">
				<img src="images/icon_arrow.png" style="vertical-align: middle;"/> <a style="color: #fff;" href="directions.php" target="_blank">Directions</a><br />
				<img src="images/icon_arrow.png" style="vertical-align: middle;"/> <a style="color: #fff;" href="http://maps.google.com/maps?f=q&hl=en&q=Pacific+Grove,+CA+93950&ie=UTF8&ll=36.62283,-121.923952&spn=0.032721,0.075445&z=14&om=1" target="_blank">Area Map</a><br />
				<img src="images/icon_arrow.png" style="vertical-align: middle;"/> <a style="color: #fff;" href="http://www.visitasilomar.com/Files/AsilomarGroundsMap_1.pdf" target="_blank">Map of Grounds</a>
			</div>
		</div>
		<div class="box6">
			<div class="header" style="color: #fff; padding:0px 0px 0px 0px;">
				For more information, please visit the Asilomar website at <a style="color: #fff;" href="http://visitasilomar.com" target="_blank">www.visitasilomar.com</a>
			</div>
		</div>
			<div class="header" style="padding:0px 0px 0px 8px;">Weather and Surf Report</div>
<ul>
<li style="padding: 0px;"><a href="http://www.weather.com/weather/local/USCA0820?from=search_city" target="_blank">Weather.com<a/></li>
<li><a href="http://www.swellinfo.com/report.html?loc=enp_us_ca_monterey" target="_blank">Surf Forecast at SwellInfo.com</a></li>
<li><a href="http://www.planetsurf.net" target="_blank">PlanetSurf.net</a></li>
</ul>
	</div>
</div>
	
<?php require("includes/footer.php"); ?>
